from __future__ import annotations
from datetime import datetime, timezone
import json

def utc_now(): return datetime.now(timezone.utc).isoformat(timespec='seconds')

class QualityManager:
    def __init__(self, db):
        self.db=db
        with db.connect() as c:
            c.executescript('''
            CREATE TABLE IF NOT EXISTS quality_inspections(
              id INTEGER PRIMARY KEY AUTOINCREMENT, run_id INTEGER NOT NULL, result TEXT NOT NULL,
              sample_size INTEGER NOT NULL DEFAULT 0, defects INTEGER NOT NULL DEFAULT 0,
              defect_code TEXT NOT NULL DEFAULT '', notes TEXT NOT NULL DEFAULT '', inspector TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS rework_orders(
              id INTEGER PRIMARY KEY AUTOINCREMENT, run_id INTEGER NOT NULL, reason TEXT NOT NULL, quantity INTEGER NOT NULL DEFAULT 0,
              status TEXT NOT NULL DEFAULT 'open', created_at TEXT NOT NULL, closed_at TEXT NOT NULL DEFAULT '');
            ''')
    def inspect(self, run_id:int, *, result:str, sample_size:int=0, defects:int=0, defect_code:str='', notes:str='', inspector:str='') -> int:
        result=result.lower()
        if result not in {'pass','fail','hold'}: raise ValueError('result must be pass/fail/hold')
        with self.db.connect() as c:
            cur=c.execute('INSERT INTO quality_inspections(run_id,result,sample_size,defects,defect_code,notes,inspector,created_at) VALUES(?,?,?,?,?,?,?,?)',
                          (run_id,result,max(0,sample_size),max(0,defects),defect_code,notes,inspector,utc_now()))
            return int(cur.lastrowid)
    def create_rework(self, run_id:int, reason:str, quantity:int) -> int:
        with self.db.connect() as c:
            cur=c.execute('INSERT INTO rework_orders(run_id,reason,quantity,created_at) VALUES(?,?,?,?)',(run_id,reason,max(0,quantity),utc_now()))
            return int(cur.lastrowid)
    def close_rework(self, rework_id:int):
        with self.db.connect() as c:
            c.execute("UPDATE rework_orders SET status='closed',closed_at=? WHERE id=?",(utc_now(),rework_id))
