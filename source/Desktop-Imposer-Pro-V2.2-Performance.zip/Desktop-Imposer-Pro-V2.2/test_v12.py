from pathlib import Path
from tempfile import TemporaryDirectory
import xml.etree.ElementTree as ET

from reportlab.pdfgen import canvas
from reportlab.lib.colors import CMYKColorSep

from booklet import saddle_stitch, perfect_bound_sections
from press_geometry import PressGeometry, calculate_grid_for_press
from imposition import ImpositionSettings
from nesting import NestItem, nest_polygons_multi_sheet
from costing import CostInput, calculate_cost
from print_marks import MarkSettings, create_press_marks_pdf
from pypdf import PdfReader
from jdf import JDFJob, build_jdf, build_cip3_ppf_metadata
from dieline import extract_dielines


def test_booklet():
    spreads=saddle_stitch(8,0.15)
    assert [(s.left,s.right) for s in spreads[:4]] == [(8,1),(2,7),(6,3),(4,5)]
    assert spreads[2].creep_mm == 0.15
    sigs=perfect_bound_sections(36,16)
    assert len(sigs)==3
    assert sigs[-1][0].signature==3


def test_press_grid():
    s=ImpositionSettings(sheet_width_mm=450,sheet_height_mm=320,trim_width_mm=90,trim_height_mm=54,margin_x_mm=0,margin_y_mm=0,gap_x_mm=4,gap_y_mm=4)
    press=PressGeometry(450,320,gripper_mm=12,tail_mm=8,side_left_mm=6,side_right_mm=4)
    g,rect=calculate_grid_for_press(s,press)
    assert rect==(6,12,440,300)
    assert g.origin_x_mm>=6 and g.origin_y_mm>=12
    assert g.capacity>0


def test_multi_sheet_nesting():
    item=NestItem('L',[(0,0),(60,0),(60,20),(20,20),(20,60),(0,60)],quantity=8)
    plan=nest_polygons_multi_sheet([item],100,100,gap_mm=2,step_mm=2)
    assert plan.sheet_count>=2
    assert len(plan.placements)==8
    assert all(0<u<=1 for u in plan.utilization)


def test_costing():
    r=calculate_cost(CostInput(order_qty=1000,ups=10,paper_cost_per_sheet=1.0,press_setup_cost=100,finishing_cost_per_item=.05,packing_cost=20,delivery_cost=30,tax_rate=.06,target_margin_rate=.30))
    assert r.net_sheets==100
    assert r.total_cost>r.subtotal
    assert r.suggested_price>r.total_cost


def test_marks():
    raw=create_press_marks_pdf(450,320,MarkSettings(color_bar=True,density_bar=True,fold=True,fold_positions_mm=(225,)))
    with TemporaryDirectory() as td:
        p=Path(td)/'marks.pdf'; p.write_bytes(raw)
        reader=PdfReader(str(p)); assert len(reader.pages)==1
        assert p.stat().st_size>500


def test_jdf():
    job=JDFJob('JOB-001',customer='测试客户',amount=1000,media_name='250g铜版纸',sheet_width_mm=450,sheet_height_mm=320,output_pdf='out.pdf',device_id='PRESS-01')
    raw=build_jdf(job)
    root=ET.fromstring(raw)
    assert root.attrib['JobID']=='JOB-001'
    assert root.attrib['Version']=='1.6'
    ppf=build_cip3_ppf_metadata(job)
    assert 'CIP3-JobName: JOB-001' in ppf
    assert 'Metadata baseline only' in ppf


def test_dieline():
    with TemporaryDirectory() as td:
        p=Path(td)/'die.pdf'
        c=canvas.Canvas(str(p),pagesize=(300,300))
        spot=CMYKColorSep(0,1,0,0,spotName='CutContour')
        c.setStrokeColor(spot)
        c.setLineWidth(1)
        c.rect(50,50,120,80,stroke=1,fill=0)
        c.showPage(); c.save()
        result=extract_dielines(p)
        assert result and 'CutContour' in result[0].spot_name
        assert len(result[0].polygons)>=1


def main():
    for fn in [test_booklet,test_press_grid,test_multi_sheet_nesting,test_costing,test_marks,test_jdf,test_dieline]:
        fn(); print('PASS',fn.__name__)
    print('V1.2 PASS')

if __name__=='__main__': main()
