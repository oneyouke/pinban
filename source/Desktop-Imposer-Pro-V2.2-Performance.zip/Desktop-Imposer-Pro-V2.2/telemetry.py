from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from typing import Any, Protocol
import json, urllib.request


def utc_now(): return datetime.now(timezone.utc).isoformat(timespec='seconds')

@dataclass(frozen=True)
class TelemetrySample:
    device_id: str
    state: str = 'Unknown'
    speed_sph: float = 0.0
    total_counter: int = 0
    good_counter: int = 0
    waste_counter: int = 0
    alarm_code: str = ''
    alarm_text: str = ''
    job_id: str = ''
    collected_at: str = ''

    def normalized(self):
        return TelemetrySample(**{**asdict(self), 'collected_at': self.collected_at or utc_now()})

class TelemetryAdapter(Protocol):
    def collect(self, device_id: str) -> TelemetrySample: ...

class JsonHttpAdapter:
    def __init__(self, url: str, token: str = '', timeout: float = 4.0):
        self.url, self.token, self.timeout = url, token, timeout
    def collect(self, device_id: str) -> TelemetrySample:
        req = urllib.request.Request(self.url, headers={'Accept':'application/json'})
        if self.token: req.add_header('Authorization', f'Bearer {self.token}')
        with urllib.request.urlopen(req, timeout=self.timeout) as r:
            data = json.loads(r.read().decode('utf-8'))
        return TelemetrySample(
            device_id=device_id, state=str(data.get('state') or data.get('status') or 'Unknown'),
            speed_sph=float(data.get('speed_sph') or data.get('speed') or 0),
            total_counter=int(data.get('total_counter') or data.get('counter') or 0),
            good_counter=int(data.get('good_counter') or data.get('good') or 0),
            waste_counter=int(data.get('waste_counter') or data.get('waste') or 0),
            alarm_code=str(data.get('alarm_code') or ''), alarm_text=str(data.get('alarm_text') or data.get('alarm') or ''),
            job_id=str(data.get('job_id') or ''), collected_at=str(data.get('collected_at') or utc_now())
        )

class SimulatedAdapter:
    def __init__(self, sample: TelemetrySample): self.sample = sample
    def collect(self, device_id: str) -> TelemetrySample:
        return TelemetrySample(**{**asdict(self.sample), 'device_id':device_id, 'collected_at':utc_now()})

class TelemetryService:
    def __init__(self, db):
        self.db = db
        with db.connect() as c:
            c.executescript('''
            CREATE TABLE IF NOT EXISTS device_telemetry(
              id INTEGER PRIMARY KEY AUTOINCREMENT, device_id TEXT NOT NULL, state TEXT NOT NULL,
              speed_sph REAL NOT NULL DEFAULT 0, total_counter INTEGER NOT NULL DEFAULT 0,
              good_counter INTEGER NOT NULL DEFAULT 0, waste_counter INTEGER NOT NULL DEFAULT 0,
              alarm_code TEXT NOT NULL DEFAULT '', alarm_text TEXT NOT NULL DEFAULT '', job_id TEXT NOT NULL DEFAULT '',
              collected_at TEXT NOT NULL, payload_json TEXT NOT NULL DEFAULT '{}');
            CREATE INDEX IF NOT EXISTS idx_device_telemetry_device_time ON device_telemetry(device_id,id);
            ''')
    def ingest(self, sample: TelemetrySample) -> TelemetrySample:
        s = sample.normalized()
        with self.db.connect() as c:
            c.execute('''INSERT INTO device_telemetry(device_id,state,speed_sph,total_counter,good_counter,waste_counter,alarm_code,alarm_text,job_id,collected_at,payload_json)
                         VALUES(?,?,?,?,?,?,?,?,?,?,?)''',
                      (s.device_id,s.state,s.speed_sph,s.total_counter,s.good_counter,s.waste_counter,s.alarm_code,s.alarm_text,s.job_id,s.collected_at,json.dumps(asdict(s),ensure_ascii=False)))
        return s
    def latest(self, device_id: str):
        with self.db.connect() as c:
            r=c.execute('SELECT * FROM device_telemetry WHERE device_id=? ORDER BY id DESC LIMIT 1',(device_id,)).fetchone()
        return dict(r) if r else None
