from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from typing import Any, Iterable
import json
import sqlite3

from device_center import DeviceProfile, DeviceRegistry
from storage import ProductionDB


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


@dataclass(frozen=True)
class ScheduleRequirements:
    sheet_width_mm: float
    sheet_height_mm: float
    colors: int = 4
    duplex: bool = False
    preferred_kind: str = ""
    required_capabilities: tuple[str, ...] = ()


@dataclass(frozen=True)
class DeviceCandidate:
    device_id: str
    device_name: str
    score: float
    reasons: tuple[str, ...]
    compatible: bool
    queue_load: int = 0


@dataclass(frozen=True)
class ScheduledAssignment:
    queue_job_id: int
    device_id: str
    priority: int = 100
    planned_start: str = ""
    state: str = "planned"
    reason: str = ""


class ProductionScheduler:
    """Persistent scheduling layer placed above the existing production queue.

    It intentionally does not change the queue's PDF transaction semantics. The
    schedule table stores dispatch metadata (device, priority, planned state)
    while `production_jobs` remains the source of truth for file generation.
    """

    def __init__(self, db: ProductionDB, registry: DeviceRegistry):
        self.db = db
        self.registry = registry
        self._init_schema()

    def _init_schema(self) -> None:
        with self.db.connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS production_schedule (
                    queue_job_id INTEGER PRIMARY KEY,
                    device_id TEXT NOT NULL DEFAULT '',
                    priority INTEGER NOT NULL DEFAULT 100,
                    planned_start TEXT NOT NULL DEFAULT '',
                    state TEXT NOT NULL DEFAULT 'planned',
                    reason TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    FOREIGN KEY(queue_job_id) REFERENCES production_jobs(id) ON DELETE CASCADE
                );
                CREATE INDEX IF NOT EXISTS idx_schedule_device_state_priority
                    ON production_schedule(device_id, state, priority, queue_job_id);
                CREATE TABLE IF NOT EXISTS device_runtime_status (
                    device_id TEXT PRIMARY KEY,
                    device_status TEXT NOT NULL DEFAULT 'Unknown',
                    job_id TEXT NOT NULL DEFAULT '',
                    job_part_id TEXT NOT NULL DEFAULT '',
                    job_status TEXT NOT NULL DEFAULT 'Unknown',
                    percent_completed REAL,
                    message TEXT NOT NULL DEFAULT '',
                    checked_at TEXT NOT NULL
                );
                """
            )

    @staticmethod
    def requirements_from_snapshot(snapshot: dict[str, Any]) -> ScheduleRequirements:
        settings = snapshot.get("settings") or {}
        colors = int(snapshot.get("required_colors") or settings.get("required_colors") or 4)
        required_caps = snapshot.get("required_capabilities") or []
        if isinstance(required_caps, str):
            required_caps = [x.strip() for x in required_caps.split(",") if x.strip()]
        return ScheduleRequirements(
            sheet_width_mm=float(settings.get("sheet_width_mm") or 0),
            sheet_height_mm=float(settings.get("sheet_height_mm") or 0),
            colors=max(1, colors),
            duplex=bool(settings.get("duplex", False)),
            preferred_kind=str(snapshot.get("preferred_device_kind") or ""),
            required_capabilities=tuple(str(x) for x in required_caps),
        )

    def device_loads(self) -> dict[str, int]:
        with self.db.connect() as conn:
            rows = conn.execute(
                """
                SELECT s.device_id, COUNT(*) AS n
                  FROM production_schedule s
                  JOIN production_jobs j ON j.id=s.queue_job_id
                 WHERE s.device_id<>'' AND s.state IN ('planned','dispatched')
                   AND j.status IN ('queued','running')
                 GROUP BY s.device_id
                """
            ).fetchall()
        return {str(r["device_id"]): int(r["n"]) for r in rows}

    def rank_devices(self, requirements: ScheduleRequirements) -> list[DeviceCandidate]:
        loads = self.device_loads()
        runtime_map = self.device_runtime()
        results: list[DeviceCandidate] = []
        for device in self.registry.load():
            reasons: list[str] = []
            if not device.enabled:
                results.append(DeviceCandidate(device.id, device.name, -9999, ("设备已停用",), False, loads.get(device.id, 0)))
                continue

            sheet_issues = device.validate_sheet(requirements.sheet_width_mm, requirements.sheet_height_mm)
            if sheet_issues:
                results.append(DeviceCandidate(device.id, device.name, -5000, tuple(sheet_issues), False, loads.get(device.id, 0)))
                continue
            if device.colors < requirements.colors:
                results.append(DeviceCandidate(device.id, device.name, -4000, (f"需要 {requirements.colors} 色，设备仅 {device.colors} 色",), False, loads.get(device.id, 0)))
                continue
            if requirements.duplex and device.duplex_mode == "simplex":
                results.append(DeviceCandidate(device.id, device.name, -3500, ("订单要求双面，设备配置为单面",), False, loads.get(device.id, 0)))
                continue

            missing = [cap for cap in requirements.required_capabilities if not bool(device.capabilities.get(cap))]
            if missing:
                results.append(DeviceCandidate(device.id, device.name, -3000, ("缺少能力: " + ", ".join(missing),), False, loads.get(device.id, 0)))
                continue

            score = 1000.0
            runtime = runtime_map.get(device.id) or {}
            runtime_status = str(runtime.get("device_status") or "Unknown")
            if runtime_status.lower() in {"offline", "error", "failed", "down"}:
                results.append(DeviceCandidate(device.id, device.name, -2500, (f"设备状态 {runtime_status}",), False, loads.get(device.id, 0)))
                continue
            if runtime_status.lower() in {"running", "production", "setup"}:
                score -= 90
                reasons.append(f"当前状态 {runtime_status}")
            elif runtime_status not in {"", "Unknown", "Unconfigured", "Idle", "Stopped"}:
                reasons.append(f"设备状态 {runtime_status}")

            if requirements.preferred_kind:
                if device.kind == requirements.preferred_kind:
                    score += 200
                    reasons.append("设备类型匹配")
                else:
                    score -= 80
            elif device.kind in {"press", "digital"}:
                score += 50

            # Prefer a machine that fits the sheet with less excessive capacity.
            if device.max_sheet_width_mm and device.max_sheet_height_mm and requirements.sheet_width_mm and requirements.sheet_height_mm:
                device_area = device.max_sheet_width_mm * device.max_sheet_height_mm
                sheet_area = requirements.sheet_width_mm * requirements.sheet_height_mm
                if device_area > 0:
                    fit_ratio = min(1.0, sheet_area / device_area)
                    score += 150 * fit_ratio
                    reasons.append(f"纸张适配 {fit_ratio*100:.0f}%")

            load = loads.get(device.id, 0)
            score -= load * 70
            if load:
                reasons.append(f"当前待产 {load} 单")
            else:
                reasons.append("当前无待产任务")

            if device.production_speed_sph > 0:
                speed_bonus = min(120.0, device.production_speed_sph / 100.0)
                score += speed_bonus
                reasons.append(f"速度 {device.production_speed_sph:g} 张/小时")
            if device.setup_minutes > 0:
                score -= min(60.0, device.setup_minutes * 1.5)
            if device.hourly_cost > 0:
                score -= min(80.0, device.hourly_cost / 20.0)

            if device.jmf_url:
                score += 20
                reasons.append("支持 JMF 状态")
            if device.rip_hotfolder or device.jdf_hotfolder:
                score += 20
                reasons.append("已配置生产输出通道")

            results.append(DeviceCandidate(device.id, device.name, round(score, 2), tuple(reasons), True, load))

        return sorted(results, key=lambda x: (x.compatible, x.score), reverse=True)

    def assign_job(self, queue_job_id: int, device_id: str, *, priority: int = 100,
                   planned_start: str = "", reason: str = "") -> ScheduledAssignment:
        if device_id and not self.registry.get(device_id):
            raise ValueError(f"设备不存在: {device_id}")
        priority = max(1, min(9999, int(priority)))
        now = utc_now()
        with self.db.connect() as conn:
            exists = conn.execute("SELECT 1 FROM production_jobs WHERE id=?", (int(queue_job_id),)).fetchone()
            if not exists:
                raise ValueError(f"生产队列任务不存在: {queue_job_id}")
            conn.execute(
                """
                INSERT INTO production_schedule(queue_job_id,device_id,priority,planned_start,state,reason,created_at,updated_at)
                VALUES(?,?,?,?,?,?,?,?)
                ON CONFLICT(queue_job_id) DO UPDATE SET
                    device_id=excluded.device_id,priority=excluded.priority,planned_start=excluded.planned_start,
                    state='planned',reason=excluded.reason,updated_at=excluded.updated_at
                """,
                (int(queue_job_id), device_id, priority, planned_start, "planned", reason, now, now),
            )
        self.db.audit("schedule.assigned", {"job_id": queue_job_id, "device_id": device_id, "priority": priority, "reason": reason})
        return ScheduledAssignment(int(queue_job_id), device_id, priority, planned_start, "planned", reason)

    def auto_assign_job(self, queue_job_id: int) -> ScheduledAssignment:
        with self.db.connect() as conn:
            row = conn.execute("SELECT snapshot_json FROM production_jobs WHERE id=?", (int(queue_job_id),)).fetchone()
        if not row:
            raise ValueError(f"生产队列任务不存在: {queue_job_id}")
        snapshot = json.loads(row["snapshot_json"])
        requirements = self.requirements_from_snapshot(snapshot)
        candidates = self.rank_devices(requirements)
        preferred_id = str(snapshot.get("preferred_device_id") or "")
        if preferred_id:
            preferred = next((c for c in candidates if c.device_id == preferred_id and c.compatible), None)
            if preferred:
                return self.assign_job(queue_job_id, preferred.device_id, reason=f"ERP/项目指定设备 score={preferred.score:g}")
        best = next((c for c in candidates if c.compatible), None)
        if not best:
            reasons = "; ".join(f"{c.device_name}: {'/'.join(c.reasons)}" for c in candidates[:4])
            raise ValueError("没有兼容的生产设备" + (f"：{reasons}" if reasons else ""))
        return self.assign_job(queue_job_id, best.device_id, reason=f"自动派机 score={best.score:g}")

    def auto_assign_all(self) -> list[ScheduledAssignment]:
        with self.db.connect() as conn:
            rows = conn.execute(
                """
                SELECT j.id
                  FROM production_jobs j
             LEFT JOIN production_schedule s ON s.queue_job_id=j.id
                 WHERE j.status='queued' AND (s.device_id IS NULL OR s.device_id='')
                 ORDER BY j.id
                """
            ).fetchall()
        assignments: list[ScheduledAssignment] = []
        for row in rows:
            try:
                assignments.append(self.auto_assign_job(int(row["id"])))
            except ValueError:
                continue
        return assignments

    def set_priority(self, queue_job_id: int, priority: int) -> None:
        priority = max(1, min(9999, int(priority)))
        now = utc_now()
        with self.db.connect() as conn:
            cur = conn.execute(
                "UPDATE production_schedule SET priority=?,updated_at=? WHERE queue_job_id=?",
                (priority, now, int(queue_job_id)),
            )
            if cur.rowcount == 0:
                conn.execute(
                    "INSERT INTO production_schedule(queue_job_id,priority,created_at,updated_at) VALUES(?,?,?,?)",
                    (int(queue_job_id), priority, now, now),
                )
        self.db.audit("schedule.priority", {"job_id": queue_job_id, "priority": priority})

    def dispatchable_jobs(self, device_id: str = "") -> list[dict[str, Any]]:
        params: list[Any] = []
        device_clause = ""
        if device_id:
            device_clause = " AND s.device_id=?"
            params.append(device_id)
        with self.db.connect() as conn:
            rows = conn.execute(
                f"""
                SELECT j.id,j.title,j.status,j.output_path,j.created_at,
                       COALESCE(s.device_id,'') AS device_id,
                       COALESCE(s.priority,100) AS priority,
                       COALESCE(s.planned_start,'') AS planned_start,
                       COALESCE(s.state,'planned') AS schedule_state,
                       COALESCE(s.reason,'') AS schedule_reason
                  FROM production_jobs j
             LEFT JOIN production_schedule s ON s.queue_job_id=j.id
                 WHERE j.status IN ('queued','running') {device_clause}
                 ORDER BY CASE WHEN j.status='running' THEN 0 ELSE 1 END,
                          COALESCE(s.priority,100), j.id
                """,
                params,
            ).fetchall()
        return [dict(r) for r in rows]

    def next_job_for_device(self, device_id: str) -> dict[str, Any] | None:
        rows = self.dispatchable_jobs(device_id)
        return next((r for r in rows if r["status"] == "queued"), None)

    def update_device_runtime(self, device_id: str, *, device_status: str = "Unknown",
                              job_id: str = "", job_part_id: str = "", job_status: str = "Unknown",
                              percent_completed: float | None = None, message: str = "") -> None:
        now = utc_now()
        with self.db.connect() as conn:
            conn.execute(
                """
                INSERT INTO device_runtime_status(device_id,device_status,job_id,job_part_id,job_status,percent_completed,message,checked_at)
                VALUES(?,?,?,?,?,?,?,?)
                ON CONFLICT(device_id) DO UPDATE SET
                    device_status=excluded.device_status,job_id=excluded.job_id,job_part_id=excluded.job_part_id,
                    job_status=excluded.job_status,percent_completed=excluded.percent_completed,
                    message=excluded.message,checked_at=excluded.checked_at
                """,
                (device_id, device_status, job_id, job_part_id, job_status, percent_completed, message, now),
            )

    def device_runtime(self) -> dict[str, dict[str, Any]]:
        with self.db.connect() as conn:
            rows = conn.execute("SELECT * FROM device_runtime_status").fetchall()
        return {str(r["device_id"]): dict(r) for r in rows}



    def assignment_for_job(self, queue_job_id: int) -> dict[str, Any] | None:
        with self.db.connect() as conn:
            row = conn.execute(
                "SELECT * FROM production_schedule WHERE queue_job_id=?",
                (int(queue_job_id),),
            ).fetchone()
        return dict(row) if row else None

    def next_scheduled_job_id(self) -> int | None:
        """Return the next queued job honoring schedule priority.

        Assigned jobs come first, then unassigned jobs retain FIFO behavior.
        """
        with self.db.connect() as conn:
            row = conn.execute(
                """
                SELECT j.id
                  FROM production_jobs j
             LEFT JOIN production_schedule s ON s.queue_job_id=j.id
                 WHERE j.status='queued'
                 ORDER BY CASE WHEN COALESCE(s.device_id,'')<>'' THEN 0 ELSE 1 END,
                          COALESCE(s.priority,100), j.id
                 LIMIT 1
                """
            ).fetchone()
        return int(row["id"]) if row else None

    def mark_schedule_state(self, queue_job_id: int, state: str) -> None:
        if state not in {"planned", "dispatched", "completed", "failed", "canceled"}:
            raise ValueError("invalid schedule state")
        with self.db.connect() as conn:
            conn.execute(
                "UPDATE production_schedule SET state=?,updated_at=? WHERE queue_job_id=?",
                (state, utc_now(), int(queue_job_id)),
            )

    def dashboard_snapshot(self) -> dict[str, Any]:
        runtime = self.device_runtime()
        loads = self.device_loads()
        devices = []
        for p in self.registry.load():
            item = p.to_dict()
            item["queue_load"] = loads.get(p.id, 0)
            item["runtime"] = runtime.get(p.id, {})
            devices.append(item)
        return {"devices": devices, "jobs": self.dispatchable_jobs(), "generated_at": utc_now()}
