from __future__ import annotations
from dataclasses import dataclass
from io import BytesIO
from reportlab.pdfgen import canvas

PT_PER_MM=72/25.4

def mm(v): return float(v)*PT_PER_MM

@dataclass(frozen=True)
class MarkSettings:
    crop: bool=True
    registration: bool=True
    center: bool=True
    fold: bool=False
    color_bar: bool=False
    density_bar: bool=False
    mark_offset_mm: float=3.0
    mark_length_mm: float=5.0
    fold_positions_mm: tuple[float,...]=()


def create_press_marks_pdf(sheet_width_mm:float,sheet_height_mm:float,settings:MarkSettings)->bytes:
    """Create a vector overlay for press marks.

    Color/density bars are reference control patches, not a substitute for a
    press vendor's certified control strip.
    """
    if sheet_width_mm<=0 or sheet_height_mm<=0: raise ValueError('纸张尺寸无效')
    b=BytesIO(); c=canvas.Canvas(b,pagesize=(mm(sheet_width_mm),mm(sheet_height_mm)),pageCompression=1)
    c.setLineWidth(mm(0.15)); c.setStrokeColorCMYK(0,0,0,1)
    cx,cy=sheet_width_mm/2,sheet_height_mm/2
    L=settings.mark_length_mm; off=settings.mark_offset_mm
    if settings.center:
        for x1,y1,x2,y2 in ((cx-L,off,cx+L,off),(cx-L,sheet_height_mm-off,cx+L,sheet_height_mm-off),(off,cy-L,off,cy+L),(sheet_width_mm-off,cy-L,sheet_width_mm-off,cy+L)):
            c.line(mm(x1),mm(y1),mm(x2),mm(y2))
    if settings.registration:
        for x,y in ((off+L,off+L),(sheet_width_mm-off-L,off+L),(off+L,sheet_height_mm-off-L),(sheet_width_mm-off-L,sheet_height_mm-off-L)):
            c.circle(mm(x),mm(y),mm(2),stroke=1,fill=0); c.line(mm(x-3),mm(y),mm(x+3),mm(y)); c.line(mm(x),mm(y-3),mm(x),mm(y+3))
    if settings.fold:
        c.setDash(mm(1.5),mm(1.5))
        for x in settings.fold_positions_mm:
            if 0<x<sheet_width_mm: c.line(mm(x),mm(off),mm(x),mm(sheet_height_mm-off))
        c.setDash()
    if settings.color_bar:
        patches=((1,0,0,0),(0,1,0,0),(0,0,1,0),(0,0,0,1),(1,1,0,0),(1,0,1,0),(0,1,1,0))
        x=off; y=off+8
        for col in patches:
            c.setFillColorCMYK(*col); c.rect(mm(x),mm(y),mm(6),mm(6),stroke=0,fill=1); x+=6.5
    if settings.density_bar:
        x=off; y=off+16
        for k in (0.25,0.5,0.75,1.0):
            c.setFillColorCMYK(0,0,0,k); c.rect(mm(x),mm(y),mm(8),mm(6),stroke=0,fill=1); x+=8.5
    c.showPage(); c.save(); return b.getvalue()
