from pathlib import Path
from tempfile import TemporaryDirectory
from datetime import datetime, timezone, timedelta

from storage import ProductionDB
from telemetry import TelemetrySample, TelemetryService
from alerts import AlertManager
from quality import QualityManager
from traceability import TraceabilityManager
from maintenance import MaintenanceManager
from risk import delivery_risk
from telemetry_mes import TelemetryMESBridge

class StubMES:
    def __init__(self): self.run={'id':1,'device_id':'P1','completed_sheets':10,'good_count':9,'waste_count':1}; self.calls=[]
    def get_run(self, run_id): return dict(self.run) if run_id==1 else None
    def report_progress(self, run_id, **kw): self.run.update(kw); self.calls.append(kw)

def main():
  with TemporaryDirectory() as td:
    db=ProductionDB(Path(td)/'prod.sqlite')
    tel=TelemetryService(db); alerts=AlertManager(db); mes=StubMES(); bridge=TelemetryMESBridge(tel,mes,alerts)
    a=TelemetrySample('P1','Running',5000,100,95,5)
    b=TelemetrySample('P1','Running',5200,110,104,6)
    assert not bridge.process(1,a).updated
    r=bridge.process(1,b); assert r.updated and r.completed_sheets==20 and r.good_count==18 and r.waste_count==2
    bad=TelemetrySample('P1','Running',0,1,1,0); assert not bridge.process(1,bad).updated
    assert tel.latest('P1')['state']=='Running'

    q=QualityManager(db); iid=q.inspect(1,result='fail',sample_size=20,defects=2,defect_code='REGISTER',inspector='QC01'); assert iid>0
    rid=q.create_rework(1,'套印偏差',200); q.close_rework(rid)
    with db.connect() as c: assert c.execute('SELECT status FROM rework_orders WHERE id=?',(rid,)).fetchone()['status']=='closed'

    tr=TraceabilityManager(db); lot=tr.new_lot(1,1000,'LOT-TEST'); pal=tr.new_pallet(lot,500,'PALLET-A'); assert pal=='PALLET-A'

    mm=MaintenanceManager(db); task=mm.schedule('P1','更换橡皮布',meter_due=10000); assert not mm.due('P1',9999); assert mm.due('P1',10000)[0]['id']==task; mm.complete(task)

    now=datetime.now(timezone.utc); pe=(now+timedelta(hours=3)).isoformat(); due=(now+timedelta(hours=1)).isoformat()
    risk=delivery_risk('SO-001',pe,due,priority=10,margin_value=1500); assert risk.risk=='high' and risk.minutes_late>100
    print('V1.6 PASS')

if __name__=='__main__': main()
