# V2.1.4 PowerShell / OneDrive build fix

针对现场错误：

`程序“python.exe”无法运行: 索引超出了数组界限`

本版处理：

- 不再直接通过 PowerShell `& $venvPython ...` 执行复杂参数。
- 所有 Python/pip/PyInstaller 命令统一用 `Start-Process -ArgumentList`。
- 源码位于 OneDrive/中文桌面也没关系：
  安装器会复制到 `%LOCALAPPDATA%\DesktopImposerBuild\V2.1.4` 后构建。
- winget 如果返回“已经安装/没有升级”，会重新检测 Python，不再把它直接当安装失败。
- 不依赖 NSIS。
- 失败日志仍保存在原解压目录 `logs`。
