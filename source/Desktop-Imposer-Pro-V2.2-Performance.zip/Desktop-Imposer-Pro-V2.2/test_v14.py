from __future__ import annotations

from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from tempfile import TemporaryDirectory
from threading import Thread
import json

from device_center import DeviceProfile, DeviceRegistry
from device_monitor import DeviceMonitor
from erp_dispatch import ERPProductionDispatcher
from erp_server import ERPBridge
from integration import ProductionTicket
from production_scheduler import ProductionScheduler, ScheduleRequirements
from queue_service import PersistentQueue
from reportlab.pdfgen import canvas
from storage import ProductionDB


class _JMFHandler(BaseHTTPRequestHandler):
    def do_POST(self):
        body = b'''<?xml version="1.0" encoding="UTF-8"?>
        <JMF xmlns="http://www.CIP4.org/JDFSchema_1_1" SenderID="RIP-1" Version="1.6">
          <Response Type="Status"><DeviceInfo DeviceID="press-fast" DeviceStatus="Running">
            <JobPhase JobID="JOB-V14" JobPartID="P1" Status="InProgress" PercentCompleted="48.5" />
          </DeviceInfo></Response>
        </JMF>'''
        self.send_response(200); self.send_header("Content-Type", "application/vnd.cip4-jmf+xml")
        self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body)
    def log_message(self, fmt, *args): return


def test_scheduler(tmp: Path):
    db = ProductionDB(tmp / "prod.sqlite3")
    registry = DeviceRegistry(tmp / "devices.json")
    registry.save([
        DeviceProfile(id="too-small", name="小设备", max_sheet_width_mm=300, max_sheet_height_mm=220, colors=4),
        DeviceProfile(id="press-fast", name="高速机", max_sheet_width_mm=520, max_sheet_height_mm=380, colors=4,
                      production_speed_sph=12000, setup_minutes=8, hourly_cost=800),
        DeviceProfile(id="press-slow", name="备用机", max_sheet_width_mm=520, max_sheet_height_mm=380, colors=4,
                      production_speed_sph=5000, setup_minutes=20, hourly_cost=900),
    ])
    scheduler = ProductionScheduler(db, registry)
    req = ScheduleRequirements(450, 320, colors=4)
    ranked = scheduler.rank_devices(req)
    assert ranked[0].device_id == "press-fast" and ranked[0].compatible
    assert not next(c for c in ranked if c.device_id == "too-small").compatible

    snapshot = {"jobs": [], "settings": {"sheet_width_mm": 450, "sheet_height_mm": 320, "duplex": False}}
    j1 = db.enqueue("JOB-1", str(tmp / "a.pdf"), snapshot)
    j2 = db.enqueue("JOB-2", str(tmp / "b.pdf"), snapshot)
    a1 = scheduler.auto_assign_job(j1)
    assert a1.device_id == "press-fast"
    scheduler.assign_job(j2, "press-slow", priority=10, reason="急单")
    assert scheduler.next_scheduled_job_id() == j2
    scheduler.set_priority(j1, 5)
    assert scheduler.next_scheduled_job_id() == j1
    claimed = db.claim_job(j1)
    assert claimed and claimed["id"] == j1
    scheduler.mark_schedule_state(j1, "dispatched")
    snap = scheduler.dashboard_snapshot()
    assert len(snap["devices"]) == 3
    return db, registry, scheduler


def test_jmf_monitor(db, registry, scheduler):
    server = ThreadingHTTPServer(("127.0.0.1", 0), _JMFHandler)
    thread = Thread(target=server.serve_forever, daemon=True); thread.start()
    try:
        p = registry.get("press-fast")
        p.jmf_url = f"http://127.0.0.1:{server.server_address[1]}/jmf"
        registry.upsert(p)
        result = DeviceMonitor(scheduler, timeout=2).poll(p)
        assert result.ok and result.status and result.status.percent_completed == 48.5
        runtime = scheduler.device_runtime()["press-fast"]
        assert runtime["device_status"] == "Running" and runtime["job_id"] == "JOB-V14"
    finally:
        server.shutdown(); server.server_close(); thread.join(timeout=2)


def test_erp_dispatch(tmp: Path, db, scheduler):
    src = tmp / "erp-source.pdf"; src.write_bytes(b"dummy")
    bridge = ERPBridge()
    req = bridge.submit(ProductionTicket(
        order_id="ERP-V14", customer="客户甲", input_files=[str(src)], quantities=[250],
        product_width_mm=90, product_height_mm=54, sheet_width_mm=450, sheet_height_mm=320,
        device_kind="press", output_dir=str(tmp / "output"), required_colors=4,
    ).to_dict())
    dispatcher = ERPProductionDispatcher(db, scheduler)
    job_id = dispatcher.enqueue(req, auto_assign=True)
    rows = db.list_jobs(50)
    row = next(r for r in rows if r["id"] == job_id)
    assert row["status"] == "queued" and "ERP-V14" in row["title"]
    scheduled = next(j for j in scheduler.dispatchable_jobs() if j["id"] == job_id)
    assert scheduled["device_id"] in {"press-fast", "press-slow"}




def test_device_dispatch(tmp: Path):
    db = ProductionDB(tmp / "dispatch.sqlite3")
    registry = DeviceRegistry(tmp / "dispatch-devices.json")
    rip = tmp / "rip"; jdf = tmp / "jdf"
    registry.save([DeviceProfile(
        id="press-dispatch", name="投递机", max_sheet_width_mm=500, max_sheet_height_mm=400, colors=4,
        rip_hotfolder=str(rip), jdf_hotfolder=str(jdf),
    )])
    scheduler = ProductionScheduler(db, registry)
    src = tmp / "source-valid.pdf"
    c = canvas.Canvas(str(src), pagesize=(90*72/25.4, 54*72/25.4)); c.drawString(10, 20, "V14"); c.showPage(); c.save()
    snapshot = {
        "jobs": [{"path": str(src), "quantity": 2, "trim_width_mm": 90.0, "trim_height_mm": 54.0, "bleed_mm": 0.0, "name": "Card"}],
        "settings": {"sheet_width_mm": 450.0, "sheet_height_mm": 320.0, "trim_width_mm": 90.0, "trim_height_mm": 54.0,
                     "margin_x_mm": 10.0, "margin_y_mm": 10.0, "gap_x_mm": 4.0, "gap_y_mm": 4.0, "auto_grid": True,
                     "copies_per_page": 1, "order_no": "DISPATCH-1", "customer_name": "客户乙"},
        "layout": None,
    }
    out = tmp / "dispatch-output.pdf"
    job_id = db.enqueue("DISPATCH-1", str(out), snapshot)
    scheduler.assign_job(job_id, "press-dispatch", priority=1, reason="测试投递")
    result = PersistentQueue(db, scheduler=scheduler, registry=registry).process_next(job_id)
    assert result and result["status"] == "succeeded" and out.exists()
    assert (rip / out.name).exists()
    assert (rip / (out.name + ".ticket.json")).exists()
    assert (jdf / f"{out.stem}.jdf").exists()

def main():
    with TemporaryDirectory() as td:
        tmp = Path(td)
        db, registry, scheduler = test_scheduler(tmp)
        test_jmf_monitor(db, registry, scheduler)
        test_erp_dispatch(tmp, db, scheduler)
        test_device_dispatch(tmp)
    print("V1.4 PASS")


if __name__ == "__main__":
    main()
