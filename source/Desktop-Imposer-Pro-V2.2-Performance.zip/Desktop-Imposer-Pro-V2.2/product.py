from __future__ import annotations

APP_NAME = "桌面拼版软件 Pro"
APP_SHORT_NAME = "DesktopImposerPro"
APP_ID = "com.yourcompany.desktopimposer.pro"
APP_VERSION = "2.2.0"
PROJECT_SCHEMA_VERSION = 1
DATABASE_SCHEMA_VERSION = 3
LICENSE_SCHEMA_VERSION = 1
UPDATE_MANIFEST_SCHEMA_VERSION = 1
DEFAULT_TRIAL_DAYS = 14

# Set this before building a commercial release. The update manifest itself is
# signed, so HTTPS protects transport while the signature protects integrity.
UPDATE_MANIFEST_URL = ""

# Commercial distributions should replace this with their own product/company
# identity. It is intentionally not used as a cryptographic secret.
VENDOR_NAME = "Your Company"
SUPPORT_EMAIL = "support@example.com"
