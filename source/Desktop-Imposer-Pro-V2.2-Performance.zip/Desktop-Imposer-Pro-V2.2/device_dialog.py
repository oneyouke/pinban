from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QComboBox, QDialog, QDialogButtonBox, QDoubleSpinBox, QFormLayout,
    QHBoxLayout, QLabel, QLineEdit, QListWidget, QMessageBox, QPushButton,
    QSpinBox, QVBoxLayout, QWidget,
)

from device_center import DeviceProfile, DeviceRegistry


class DeviceCenterDialog(QDialog):
    def __init__(self, registry: DeviceRegistry, parent=None):
        super().__init__(parent)
        self.registry = registry
        self.setWindowTitle("设备配置中心")
        self.resize(820, 560)
        self.profiles = self.registry.load()
        self._build()
        self._reload_list()

    def _dspin(self, maxv=3000.0):
        s=QDoubleSpinBox(); s.setRange(0,maxv); s.setDecimals(2); return s

    def _build(self):
        root=QHBoxLayout(self)
        left=QVBoxLayout(); self.list=QListWidget(); left.addWidget(self.list,1)
        row=QHBoxLayout(); self.add_btn=QPushButton("新增"); self.del_btn=QPushButton("删除")
        row.addWidget(self.add_btn); row.addWidget(self.del_btn); left.addLayout(row); root.addLayout(left,1)

        pane=QWidget(); form=QFormLayout(pane)
        self.name=QLineEdit(); self.kind=QComboBox(); self.kind.addItems(["press","digital","ctp","rip"])
        self.vendor=QLineEdit(); self.model=QLineEdit(); self.colors=QSpinBox(); self.colors.setRange(1,16); self.colors.setValue(4)
        self.speed=self._dspin(100000); self.setup=self._dspin(1000); self.hourly=self._dspin(100000)
        self.minw=self._dspin(); self.minh=self._dspin(); self.maxw=self._dspin(); self.maxh=self._dspin()
        self.gripper=self._dspin(100); self.tail=self._dspin(100); self.leftlay=self._dspin(100); self.rightlay=self._dspin(100)
        self.duplex=QComboBox(); self.duplex.addItems(["long_edge","short_edge","simplex"])
        self.rip=QLineEdit(); self.jmf=QLineEdit(); self.jdf=QLineEdit(); self.notes=QLineEdit()
        fields=[("名称",self.name),("类型",self.kind),("厂商",self.vendor),("型号",self.model),("色数",self.colors),
                ("速度 张/小时",self.speed),("换单分钟",self.setup),("小时成本",self.hourly),
                ("最小纸宽 mm",self.minw),("最小纸高 mm",self.minh),("最大纸宽 mm",self.maxw),("最大纸高 mm",self.maxh),
                ("咬口 mm",self.gripper),("拖梢 mm",self.tail),("左规 mm",self.leftlay),("右规 mm",self.rightlay),
                ("双面方式",self.duplex),("RIP Hot Folder",self.rip),("JMF URL",self.jmf),("JDF Hot Folder",self.jdf),("备注",self.notes)]
        for label,widget in fields: form.addRow(label,widget)
        root.addWidget(pane,2)

        buttons=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Close)
        form.addRow(buttons)
        buttons.accepted.connect(self._save_all); buttons.rejected.connect(self.reject)
        self.add_btn.clicked.connect(self._add); self.del_btn.clicked.connect(self._delete); self.list.currentRowChanged.connect(self._load_current)

    def _reload_list(self):
        self.list.clear(); self.list.addItems([f"{p.name} · {p.kind}" for p in self.profiles])
        if self.profiles: self.list.setCurrentRow(0)

    def _apply_form(self, p: DeviceProfile):
        self.name.setText(p.name); self.kind.setCurrentText(p.kind); self.vendor.setText(p.vendor); self.model.setText(p.model); self.colors.setValue(p.colors)
        self.speed.setValue(p.production_speed_sph); self.setup.setValue(p.setup_minutes); self.hourly.setValue(p.hourly_cost)
        for widget,val in [(self.minw,p.min_sheet_width_mm),(self.minh,p.min_sheet_height_mm),(self.maxw,p.max_sheet_width_mm),(self.maxh,p.max_sheet_height_mm),
                           (self.gripper,p.gripper_mm),(self.tail,p.tail_mm),(self.leftlay,p.side_lay_left_mm),(self.rightlay,p.side_lay_right_mm)]: widget.setValue(val)
        self.duplex.setCurrentText(p.duplex_mode); self.rip.setText(p.rip_hotfolder); self.jmf.setText(p.jmf_url); self.jdf.setText(p.jdf_hotfolder); self.notes.setText(p.notes)

    def _store_current(self):
        row=self.list.currentRow()
        if row<0 or row>=len(self.profiles): return
        old=self.profiles[row]
        self.profiles[row]=DeviceProfile(
            id=old.id,name=self.name.text().strip() or old.name,kind=self.kind.currentText(),vendor=self.vendor.text().strip(),model=self.model.text().strip(),colors=self.colors.value(),
            production_speed_sph=self.speed.value(),setup_minutes=self.setup.value(),hourly_cost=self.hourly.value(),
            min_sheet_width_mm=self.minw.value(),min_sheet_height_mm=self.minh.value(),max_sheet_width_mm=self.maxw.value(),max_sheet_height_mm=self.maxh.value(),
            gripper_mm=self.gripper.value(),tail_mm=self.tail.value(),side_lay_left_mm=self.leftlay.value(),side_lay_right_mm=self.rightlay.value(),duplex_mode=self.duplex.currentText(),
            rip_hotfolder=self.rip.text().strip(),jmf_url=self.jmf.text().strip(),jdf_hotfolder=self.jdf.text().strip(),notes=self.notes.text().strip(),capabilities=old.capabilities,
        )

    def _load_current(self, row):
        if 0<=row<len(self.profiles): self._apply_form(self.profiles[row])

    def _add(self):
        self._store_current(); idx=len(self.profiles)+1
        self.profiles.append(DeviceProfile(id=f"device-{idx}",name=f"新设备 {idx}")); self._reload_list(); self.list.setCurrentRow(len(self.profiles)-1)

    def _delete(self):
        row=self.list.currentRow()
        if row>=0 and QMessageBox.question(self,"删除设备","确定删除当前设备配置？")==QMessageBox.Yes:
            self.profiles.pop(row); self._reload_list()

    def _save_all(self):
        self._store_current(); self.registry.save(self.profiles); self.accept()
