﻿param(
  [switch]$FullTests
)

$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

$logDir = Join-Path $PSScriptRoot "logs"
New-Item -ItemType Directory -Path $logDir -Force | Out-Null
$stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$logFile = Join-Path $logDir "install-$stamp.log"
Start-Transcript -Path $logFile -Force | Out-Null

function Step([string]$Text) {
    Write-Host "`n==> $Text" -ForegroundColor Cyan
}

function Invoke-ProcessChecked {
    param(
        [Parameter(Mandatory=$true)][string]$FilePath,
        [string[]]$Arguments = @(),
        [string]$Description = "命令"
    )

    $argLine = ($Arguments | ForEach-Object {
        if ($_ -match '[\s"]') { '"' + ($_ -replace '"','\"') + '"' } else { $_ }
    }) -join ' '

    Write-Host "运行: $FilePath $argLine"

    $proc = Start-Process `
        -FilePath $FilePath `
        -ArgumentList $Arguments `
        -Wait `
        -PassThru `
        -NoNewWindow

    if ($proc.ExitCode -ne 0) {
        throw "$Description 失败，退出码：$($proc.ExitCode)"
    }
}

function Test-Python([string]$Exe, [string[]]$Args) {
    try {
        $tmp = Join-Path $env:TEMP ("desktop-imposer-python-test-" + [Guid]::NewGuid().ToString("N") + ".txt")
        $allArgs = @()
        $allArgs += $Args
        $allArgs += @("-c", "import sys; print(sys.version_info.major, sys.version_info.minor); raise SystemExit(0 if sys.version_info >= (3,10) else 3)")
        $proc = Start-Process -FilePath $Exe -ArgumentList $allArgs -Wait -PassThru -NoNewWindow `
            -RedirectStandardOutput $tmp -RedirectStandardError ($tmp + ".err")
        $ok = ($proc.ExitCode -eq 0)
        Remove-Item $tmp, ($tmp + ".err") -Force -ErrorAction SilentlyContinue
        return $ok
    } catch {
        return $false
    }
}

function Find-CompatiblePython {
    # IMPORTANT: Path-first detection.
    # On some Windows/PowerShell/OneDrive environments, launching python just
    # to probe its version can itself fail. If an actual python.exe exists at
    # a standard install path, use it directly and validate later when venv is created.

    $directCandidates = @()

    if ($env:LOCALAPPDATA) {
        $directCandidates += @(
            (Join-Path $env:LOCALAPPDATA "Programs\Python\Python313\python.exe"),
            (Join-Path $env:LOCALAPPDATA "Programs\Python\Python312\python.exe"),
            (Join-Path $env:LOCALAPPDATA "Programs\Python\Python311\python.exe"),
            (Join-Path $env:LOCALAPPDATA "Programs\Python\Python310\python.exe")
        )
    }

    if ($env:ProgramFiles) {
        $directCandidates += @(
            (Join-Path $env:ProgramFiles "Python313\python.exe"),
            (Join-Path $env:ProgramFiles "Python312\python.exe"),
            (Join-Path $env:ProgramFiles "Python311\python.exe"),
            (Join-Path $env:ProgramFiles "Python310\python.exe")
        )
    }

    foreach ($candidate in ($directCandidates | Select-Object -Unique)) {
        if ($candidate -and (Test-Path -LiteralPath $candidate -PathType Leaf)) {
            return @{ Exe = $candidate; Args = @(); Source = "direct install path" }
        }
    }

    # Registry install locations. Again, trust an existing python.exe file.
    $registryRoots = @(
        "HKCU:\Software\Python\PythonCore",
        "HKLM:\Software\Python\PythonCore",
        "HKLM:\Software\WOW6432Node\Python\PythonCore"
    )
    foreach ($root in $registryRoots) {
        if (-not (Test-Path $root)) { continue }
        foreach ($versionKey in (Get-ChildItem $root -ErrorAction SilentlyContinue | Sort-Object PSChildName -Descending)) {
            $installKey = Join-Path $versionKey.PSPath "InstallPath"
            if (-not (Test-Path $installKey)) { continue }
            try {
                $installDir = (Get-Item $installKey).GetValue("")
                if ($installDir) {
                    $candidate = Join-Path $installDir "python.exe"
                    if (Test-Path -LiteralPath $candidate -PathType Leaf) {
                        return @{ Exe = $candidate; Args = @(); Source = "registry install path" }
                    }
                }
            } catch {}
        }
    }

    # PATH / launcher are fallbacks.
    foreach ($name in @("python.exe", "python3.exe")) {
        $cmd = Get-Command $name -ErrorAction SilentlyContinue
        if ($cmd -and (Test-Path -LiteralPath $cmd.Source -PathType Leaf)) {
            return @{ Exe = $cmd.Source; Args = @(); Source = "PATH" }
        }
    }

    $py = Get-Command py.exe -ErrorAction SilentlyContinue
    if ($py) {
        # Do not probe py selectors here. Just use launcher default Python 3.
        return @{ Exe = "py.exe"; Args = @("-3"); Source = "py launcher" }
    }

    return $null
}

function Install-Python {
    $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
    if (-not $winget) {
        throw "没有找到 Python 3.10+，并且系统没有 winget。请先安装 64 位 Python 3.12/3.13。"
    }

    Step "安装/确认 Python 3.12 x64"
    $proc = Start-Process -FilePath "winget.exe" -ArgumentList @(
        "install","--id","Python.Python.3.12","--exact","--scope","user",
        "--accept-package-agreements","--accept-source-agreements","--silent"
    ) -Wait -PassThru -NoNewWindow

    # winget returns non-zero for "already installed/no upgrade available".
    # That is NOT a failure for us. Search actual filesystem paths instead.
    for ($i = 0; $i -lt 15; $i++) {
        $detected = Find-CompatiblePython
        if ($detected) { return $detected }
        Start-Sleep -Seconds 1
    }

    $expected = Join-Path $env:LOCALAPPDATA "Programs\Python\Python312\python.exe"
    throw "winget 已完成，但仍未找到 python.exe。请检查：$expected"
}

try {
    if (-not [Environment]::Is64BitOperatingSystem) {
        throw "Desktop Imposer Pro 需要 64 位 Windows 10/11。"
    }

    Step "查找可用 Python 3.10+"
    $python = Find-CompatiblePython
    if (-not $python) {
        $python = Install-Python
    }
    if (-not $python) {
        throw "找不到 Python 3.10+。"
    }

    Write-Host "Python: $($python.Exe)"
    Write-Host "来源: $($python.Source)"

    Write-Host "Python 文件存在: $(Test-Path -LiteralPath $python.Exe)"
    if ($python.Exe -ne "py.exe" -and -not (Test-Path -LiteralPath $python.Exe -PathType Leaf)) {
        throw "检测到的 Python 路径不存在：$($python.Exe)"
    }

    # Build outside OneDrive/Desktop to avoid sync locks and path edge cases.
    Step "准备本机构建目录"
    $buildRoot = Join-Path $env:LOCALAPPDATA "DesktopImposerBuild\V2.1.6"
    if (Test-Path $buildRoot) {
        Remove-Item -Recurse -Force $buildRoot -ErrorAction SilentlyContinue
    }
    New-Item -ItemType Directory -Path $buildRoot -Force | Out-Null

    # Copy source, but skip build artifacts and local venv/logs.
    $excludeDirs = @(".venv-desktop","build","dist","logs","release")
    Get-ChildItem -Path $PSScriptRoot -Force | ForEach-Object {
        if ($excludeDirs -contains $_.Name) { return }
        if ($_.Name -like "*.zip") { return }
        Copy-Item -Path $_.FullName -Destination $buildRoot -Recurse -Force
    }

    Set-Location $buildRoot

    $venv = Join-Path $buildRoot ".venv"
    $venvPython = Join-Path $venv "Scripts\python.exe"

    Step "创建独立运行环境"
    if (-not (Test-Path $venvPython)) {
        $venvArgs = @()
        $venvArgs += $python.Args
        $venvArgs += @("-m", "venv", $venv)
        Invoke-ProcessChecked -FilePath $python.Exe -Arguments $venvArgs -Description "创建虚拟环境"
    }

    Step "安装桌面软件依赖"
    Invoke-ProcessChecked -FilePath $venvPython -Arguments @(
        "-m","pip","install","--disable-pip-version-check","--upgrade","pip","setuptools","wheel"
    ) -Description "升级 pip"

    Invoke-ProcessChecked -FilePath $venvPython -Arguments @(
        "-m","pip","install","--disable-pip-version-check","-r","requirements-build.txt"
    ) -Description "安装依赖"

    Step "运行安装级最小自检"
    Invoke-ProcessChecked -FilePath $venvPython -Arguments @(
        "-m","compileall","-q","."
    ) -Description "Python 编译检查"

    Invoke-ProcessChecked -FilePath $venvPython -Arguments @(
        "install_smoke_test.py"
    ) -Description "安装级运行自检"

    if ($FullTests) {
        foreach ($t in @(
            "test_commercial.py","test_v11.py","test_v12.py","test_v13.py",
            "test_v14.py","test_v15.py","test_v16.py","test_v17.py",
            "test_v18.py","test_v19.py","test_v20.py","test_v21.py"
        )) {
            Invoke-ProcessChecked -FilePath $venvPython -Arguments @($t) -Description "完整回归 $t"
        }
    }

    Step "封装 Windows EXE"
    Remove-Item -Recurse -Force (Join-Path $buildRoot "build") -ErrorAction SilentlyContinue
    Remove-Item -Recurse -Force (Join-Path $buildRoot "dist") -ErrorAction SilentlyContinue

    Invoke-ProcessChecked -FilePath $venvPython -Arguments @(
        "-m","PyInstaller","--noconfirm","--clean","DesktopImposer.spec"
    ) -Description "PyInstaller 封装"

    $sourceDir = Join-Path $buildRoot "dist\DesktopImposerPro"
    $sourceExe = Join-Path $sourceDir "DesktopImposerPro.exe"
    if (-not (Test-Path $sourceExe)) {
        throw "PyInstaller 没有生成 DesktopImposerPro.exe。"
    }

    Step "运行封装后 Qt/PDF 自检"
    $selfTest = Join-Path $env:TEMP ("desktop-imposer-selftest-" + [Guid]::NewGuid().ToString("N") + ".json")
    $env:QT_QPA_PLATFORM = "offscreen"
    $env:DESKTOP_IMPOSER_SELFTEST_FILE = $selfTest
    try {
        $proc = Start-Process -FilePath $sourceExe -ArgumentList @("--packaging-self-test") -Wait -PassThru
    } finally {
        Remove-Item Env:DESKTOP_IMPOSER_SELFTEST_FILE -ErrorAction SilentlyContinue
        Remove-Item Env:QT_QPA_PLATFORM -ErrorAction SilentlyContinue
    }

    if ($proc.ExitCode -ne 0 -or -not (Test-Path $selfTest)) {
        throw "封装后的 Qt/PDF 自检失败。"
    }

    $testResult = Get-Content $selfTest -Raw | ConvertFrom-Json
    Remove-Item $selfTest -Force -ErrorAction SilentlyContinue
    if (-not $testResult.ok) {
        throw "封装后的程序自检未通过。"
    }

    Step "安装到当前用户"
    $baseDir = Join-Path $env:LOCALAPPDATA "Programs"
    $installDir = Join-Path $baseDir "DesktopImposerPro"
    $stageDir = Join-Path $baseDir ("DesktopImposerPro.new-" + [Guid]::NewGuid().ToString("N"))
    $oldDir = Join-Path $baseDir ("DesktopImposerPro.old-" + [Guid]::NewGuid().ToString("N"))

    New-Item -ItemType Directory -Path $baseDir -Force | Out-Null
    Copy-Item -Path $sourceDir -Destination $stageDir -Recurse -Force

    if (Test-Path $installDir) {
        try {
            Rename-Item -Path $installDir -NewName (Split-Path $oldDir -Leaf)
        } catch {
            throw "旧版软件可能仍在运行。请关闭 Desktop Imposer Pro 后重试。"
        }
    }
    Rename-Item -Path $stageDir -NewName (Split-Path $installDir -Leaf)
    Remove-Item -Recurse -Force $oldDir -ErrorAction SilentlyContinue

    $exe = Join-Path $installDir "DesktopImposerPro.exe"

    Step "创建桌面启动入口"
    $desktop = [Environment]::GetFolderPath("Desktop")
    $desktopCmd = Join-Path $desktop "桌面拼版软件 Pro.cmd"
    [IO.File]::WriteAllText(
        $desktopCmd,
        "@echo off`r`nstart `"`" `"$exe`"`r`n",
        [Text.Encoding]::Default
    )

    try {
        $shell = New-Object -ComObject WScript.Shell
        $lnk = Join-Path $desktop "桌面拼版软件 Pro.lnk"
        $shortcut = $shell.CreateShortcut($lnk)
        $shortcut.TargetPath = $exe
        $shortcut.WorkingDirectory = $installDir
        $shortcut.IconLocation = "$exe,0"
        $shortcut.Description = "Desktop Imposer Pro"
        $shortcut.Save()
    } catch {
        Write-Warning "系统策略阻止创建 .lnk，但 .cmd 启动器已创建。"
    }

    Step "启动软件"
    Start-Process -FilePath $exe

    Write-Host "`n=============================================" -ForegroundColor Green
    Write-Host " 安装完成" -ForegroundColor Green
    Write-Host "=============================================" -ForegroundColor Green
    Write-Host "程序目录：$installDir"
    Write-Host "构建目录：$buildRoot"
    Write-Host "日志文件：$logFile"
}
catch {
    Write-Host "`n[FAILED] $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "请把这个日志文件直接发给我：" -ForegroundColor Yellow
    Write-Host $logFile -ForegroundColor Yellow
    exit 1
}
finally {
    try { Stop-Transcript | Out-Null } catch {}
}
