from __future__ import annotations

import json
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from licensing import verify_payload
from product import APP_VERSION, UPDATE_MANIFEST_URL, UPDATE_MANIFEST_SCHEMA_VERSION


def _version_tuple(value: str) -> tuple[int, ...]:
    parts = []
    for piece in value.split("."):
        digits = "".join(ch for ch in piece if ch.isdigit())
        parts.append(int(digits or 0))
    return tuple(parts)


@dataclass(frozen=True)
class UpdateInfo:
    available: bool
    current_version: str
    latest_version: str = ""
    download_url: str = ""
    sha256: str = ""
    notes: str = ""
    message: str = ""


def check_for_update(public_key_path: str | Path, manifest_url: str = "") -> UpdateInfo:
    url = manifest_url.strip() or UPDATE_MANIFEST_URL.strip()
    if not url:
        return UpdateInfo(False, APP_VERSION, message="尚未配置更新清单地址")
    if not url.lower().startswith("https://"):
        return UpdateInfo(False, APP_VERSION, message="更新地址必须使用 HTTPS")
    req = urllib.request.Request(url, headers={"User-Agent": f"DesktopImposer/{APP_VERSION}"})
    with urllib.request.urlopen(req, timeout=8) as resp:
        raw = resp.read(2_000_000)
    doc = json.loads(raw.decode("utf-8"))
    payload = doc.get("payload")
    signature = doc.get("signature")
    if not isinstance(payload, dict) or not isinstance(signature, str):
        raise ValueError("更新清单结构无效")
    if int(payload.get("schema_version", 0)) != UPDATE_MANIFEST_SCHEMA_VERSION:
        raise ValueError("不支持的更新清单版本")
    public = Path(public_key_path).read_bytes()
    if not verify_payload(payload, signature, public):
        raise ValueError("更新清单签名校验失败")
    latest = str(payload.get("version") or "")
    available = bool(latest) and _version_tuple(latest) > _version_tuple(APP_VERSION)
    return UpdateInfo(
        available, APP_VERSION, latest_version=latest,
        download_url=str(payload.get("download_url") or ""),
        sha256=str(payload.get("sha256") or ""),
        notes=str(payload.get("notes") or ""),
        message="发现新版本" if available else "当前已经是最新版本",
    )
