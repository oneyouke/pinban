from __future__ import annotations

from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from typing import Any
import json
import urllib.request

from mes import MESManager
from storage import ProductionDB


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


@dataclass(frozen=True)
class WorkflowStatus:
    queue_job_id: int
    order_id: str
    state: str
    message: str
    device_id: str = ""
    run_id: int | None = None
    good_count: int = 0
    waste_count: int = 0
    completed_sheets: int = 0
    updated_at: str = ""


class ProductionWorkflow:
    """Resolve one durable status across ERP -> prepress -> RIP -> press -> complete."""

    def __init__(self, db: ProductionDB, mes: MESManager):
        self.db = db
        self.mes = mes

    def status(self, queue_job_id: int) -> WorkflowStatus:
        with self.db.connect() as conn:
            job = conn.execute("SELECT * FROM production_jobs WHERE id=?", (int(queue_job_id),)).fetchone()
            run = conn.execute("SELECT * FROM mes_runs WHERE queue_job_id=?", (int(queue_job_id),)).fetchone()
        if not job:
            raise ValueError("生产任务不存在")
        try:
            snapshot = json.loads(job["snapshot_json"] or "{}")
        except Exception:
            snapshot = {}
        erp = snapshot.get("erp") or {}; ticket = erp.get("ticket") or {}
        order_id = str(ticket.get("order_id") or job["title"] or queue_job_id)
        status = str(job["status"])
        state, message = "accepted", "订单已接收"
        if status == "queued": state, message = "prepress_queued", "等待拼版/印前生产"
        elif status == "running": state, message = "prepress_running", "正在生成生产文件"
        elif status == "failed": state, message = "prepress_failed", str(job["error"] or "拼版失败")
        elif status == "succeeded": state, message = "prepress_completed", "生产 PDF 已生成并完成设备投递阶段"
        if run:
            rs = str(run["status"])
            if rs == "planned": state, message = "press_scheduled", "已进入印刷排程"
            elif rs == "running": state, message = "press_running", "印刷生产中"
            elif rs == "paused": state, message = "press_paused", "印刷暂停"
            elif rs == "completed": state, message = "completed", "生产完工"
            elif rs == "canceled": state, message = "canceled", "生产取消"
        return WorkflowStatus(
            queue_job_id=int(queue_job_id), order_id=order_id, state=state, message=message,
            device_id=str(run["device_id"]) if run else "", run_id=int(run["id"]) if run else None,
            good_count=int(run["good_count"] or 0) if run else 0,
            waste_count=int(run["waste_count"] or 0) if run else 0,
            completed_sheets=int(run["completed_sheets"] or 0) if run else 0,
            updated_at=str((run["updated_at"] if run else job["updated_at"]) or utc_now()),
        )

    def callback_url(self, queue_job_id: int) -> tuple[str, str]:
        with self.db.connect() as conn:
            job = conn.execute("SELECT snapshot_json FROM production_jobs WHERE id=?", (int(queue_job_id),)).fetchone()
        if not job: return "", ""
        try: snapshot = json.loads(job["snapshot_json"] or "{}")
        except Exception: return "", ""
        metadata = (((snapshot.get("erp") or {}).get("ticket") or {}).get("metadata") or {})
        return str(metadata.get("status_callback_url") or ""), str(metadata.get("status_callback_token") or "")

    def publish_to_erp(self, queue_job_id: int, url: str = "", token: str = "", timeout: float = 5.0) -> dict[str, Any]:
        status = self.status(queue_job_id)
        if not url:
            url, configured_token = self.callback_url(queue_job_id)
            token = token or configured_token
        if not url:
            raise ValueError("未配置 ERP 状态回写 URL")
        payload = asdict(status)
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        headers = {"Content-Type": "application/json; charset=utf-8"}
        if token: headers["Authorization"] = f"Bearer {token}"
        req = urllib.request.Request(url, data=body, headers=headers, method="POST")
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            result = {"status": int(resp.status), "body": resp.read().decode("utf-8", "replace")}
        self.db.audit("erp.status_published", {"job_id": queue_job_id, "state": status.state, "url": url, "http_status": result["status"]})
        return result
