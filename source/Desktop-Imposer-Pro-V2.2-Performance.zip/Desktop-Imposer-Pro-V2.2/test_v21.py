from __future__ import annotations

import io
import json
import os
import sqlite3
import tempfile
from pathlib import Path
from unittest.mock import patch


def main():
    with tempfile.TemporaryDirectory(prefix="imposer_v21_") as td:
        root = Path(td)
        os.environ["XDG_DATA_HOME"] = str(root / "data")
        os.environ["XDG_CONFIG_HOME"] = str(root / "config")

        from app_paths import database_path
        from runtime_resilience import CrashMarker, AuditTrail
        from backup_scheduler import BackupPolicy, ScheduledBackupService
        from backup_restore import inspect_backup
        from update_staging import stage_signed_update
        from health_check import run_health_checks

        # Crash marker must detect an unclean previous launch and clear on clean exit.
        marker = CrashMarker(root / "running.json")
        first = marker.begin(); assert not first.previous_unclean_shutdown
        second = marker.begin(); assert second.previous_unclean_shutdown
        marker.clean_shutdown(); assert not (root / "running.json").exists()

        # Create a tiny production database and a chained audit log.
        dbp = database_path()
        with sqlite3.connect(dbp) as db:
            db.execute("CREATE TABLE IF NOT EXISTS sample(id INTEGER PRIMARY KEY, value TEXT)")
            db.execute("INSERT INTO sample(value) VALUES('ok')")
        audit = AuditTrail(dbp)
        audit.append("admin", "login.success")
        audit.append("admin", "backup.manual", "sample.dibackup", {"files": 1})
        verified = audit.verify(); assert verified["ok"] and verified["checked"] == 2

        # Scheduled backup creates a verifiable .dibackup and rotates by policy.
        svc = ScheduledBackupService(root / "backup_policy.json", root / "backups")
        policy = BackupPolicy(enabled=True, interval_hours=1, keep_last=2)
        svc.save_policy(policy)
        result = svc.run_if_due(policy)
        assert result["created"] and Path(result["path"]).exists()
        manifest = inspect_backup(result["path"])
        assert manifest["backup_format"] == 1

        # Update staging: mock HTTPS transport, but still require SHA-256 match.
        payload = b"signed installer bytes for v2.1"
        import hashlib
        digest = hashlib.sha256(payload).hexdigest()
        class FakeResponse(io.BytesIO):
            def __enter__(self): return self
            def __exit__(self, *args): self.close()
        with patch("urllib.request.urlopen", return_value=FakeResponse(payload)):
            staged = stage_signed_update("2.1.1", "https://updates.example.com/DesktopImposer-2.1.1.exe", digest, root / "staging")
        assert Path(staged.path).read_bytes() == payload
        assert json.loads(Path(staged.metadata_path).read_text(encoding="utf-8"))["ready"] is True

        health = run_health_checks(min_free_mb=1)
        assert health["overall"] in {"ok", "warning"}
        assert any(c["name"] == "audit_chain" and c["status"] == "ok" for c in health["checks"])

        print("V2.1 PASS")
        print(json.dumps({"audit": verified, "backup": result["path"], "health": health["overall"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
