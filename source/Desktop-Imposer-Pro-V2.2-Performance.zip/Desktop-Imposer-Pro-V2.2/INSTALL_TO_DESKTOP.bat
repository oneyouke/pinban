@echo off
setlocal
cd /d "%~dp0"

title Desktop Imposer Pro V2.1.6 Installer

echo =====================================================
echo   Desktop Imposer Pro V2.1.6 - Install Smoke Test Fix
echo =====================================================
echo.
echo Build will run outside OneDrive/Desktop.
echo No NSIS is required.
echo.

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0install_to_desktop.ps1"
set "ERR=%ERRORLEVEL%"

if not "%ERR%"=="0" (
  echo.
  echo [FAILED] Install failed.
  echo Please send the newest log from:
  echo   %~dp0logs
  echo.
  pause
  exit /b %ERR%
)

echo.
echo [OK] Installed successfully.
pause
endlocal
