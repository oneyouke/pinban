from __future__ import annotations

from pathlib import Path
from tempfile import TemporaryDirectory

from PIL import Image
from PySide6.QtCore import QT_VERSION_STR
from PySide6.QtPdf import QPdfDocument
from pypdf import PdfReader
from reportlab.pdfgen import canvas

from imposition import ImpositionSettings, impose, mm


def main() -> None:
    with TemporaryDirectory() as td:
        root = Path(td)
        src = root / "source.pdf"
        out = root / "output.pdf"

        c = canvas.Canvas(str(src), pagesize=(mm(90), mm(54)))
        c.drawString(mm(5), mm(25), "Desktop Imposer Smoke Test")
        c.showPage()
        c.save()

        settings = ImpositionSettings(copies_per_page=1)
        result = impose([src], out, settings)

        reader = PdfReader(str(out))
        assert len(reader.pages) >= 1
        assert result["total_items"] == 1
        assert out.stat().st_size > 0

        # Import/construct Qt PDF class without opening a GUI.
        doc = QPdfDocument()
        assert doc is not None

        # Pillow sanity.
        img = Image.new("RGB", (10, 10), "white")
        assert img.size == (10, 10)

        print("INSTALL_SMOKE_PASS")
        print("Qt", QT_VERSION_STR)
        print("Output", out.stat().st_size)


if __name__ == "__main__":
    main()
