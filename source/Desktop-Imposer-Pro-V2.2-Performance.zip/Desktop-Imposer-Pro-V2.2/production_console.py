from __future__ import annotations

from pathlib import Path
import queue

from PySide6.QtCore import QThread, Signal, QTimer
from PySide6.QtWidgets import (
    QAbstractItemView, QComboBox, QDialog, QFileDialog, QHBoxLayout, QLabel,
    QLineEdit, QMessageBox, QPushButton, QProgressBar, QSpinBox, QTabWidget,
    QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
)

from app_paths import die_library_dir
from cip3_ink import calculate_zones_from_grayscale, rasterize_separations_with_ghostscript
from device_center import DeviceRegistry
from device_monitor import DeviceMonitor
from die_library import DieLibrary
from erp_dispatch import ERPProductionDispatcher
from erp_server import ERPApiServer
from production_scheduler import ProductionScheduler
from storage import ProductionDB


class StatusPollWorker(QThread):
    done = Signal(list)

    def __init__(self, monitor: DeviceMonitor, devices, parent=None):
        super().__init__(parent)
        self.monitor = monitor
        self.devices = list(devices)

    def run(self):
        self.done.emit(self.monitor.poll_all(self.devices))




class ScheduleTable(QTableWidget):
    order_changed = Signal()

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.setDragEnabled(True)
        self.setAcceptDrops(True)
        self.setDropIndicatorShown(True)
        self.setDragDropMode(QAbstractItemView.InternalMove)
        self.setDragDropOverwriteMode(False)

    def dropEvent(self, event):
        super().dropEvent(event)
        self.order_changed.emit()


class ProductionConsoleDialog(QDialog):
    """V1.5 production console for scheduling, device status and automation."""

    def __init__(self, db: ProductionDB, registry: DeviceRegistry, parent=None):
        super().__init__(parent)
        self.db = db
        self.registry = registry
        self.scheduler = ProductionScheduler(db, registry)
        self.monitor = DeviceMonitor(self.scheduler, timeout=3.0)
        self.dies = DieLibrary(die_library_dir())
        self.erp_server = ERPApiServer()
        self.erp_dispatcher = ERPProductionDispatcher(db, self.scheduler)
        self.poll_worker: StatusPollWorker | None = None
        self.setWindowTitle("生产控制台 · V1.5")
        self.resize(1180, 720)
        self._build()
        self.refresh_all()
        self.timer = QTimer(self)
        self.timer.setInterval(5000)
        self.timer.timeout.connect(self._tick)
        self.timer.start()
        self.jmf_timer = QTimer(self)
        self.jmf_timer.setInterval(30000)
        self.jmf_timer.timeout.connect(self.poll_devices)
        self.jmf_timer.start()

    def _build(self):
        root = QVBoxLayout(self)
        head = QHBoxLayout()
        self.summary = QLabel("生产状态")
        head.addWidget(self.summary)
        head.addStretch()
        self.refresh_btn = QPushButton("刷新")
        self.poll_btn = QPushButton("刷新 JMF")
        self.auto_btn = QPushButton("自动派机")
        head.addWidget(self.refresh_btn); head.addWidget(self.poll_btn); head.addWidget(self.auto_btn)
        root.addLayout(head)

        self.tabs = QTabWidget()
        root.addWidget(self.tabs, 1)
        self._build_devices_tab()
        self._build_schedule_tab()
        self._build_ink_tab()
        self._build_die_tab()
        self._build_erp_tab()

        self.refresh_btn.clicked.connect(self.refresh_all)
        self.poll_btn.clicked.connect(self.poll_devices)
        self.auto_btn.clicked.connect(self.auto_assign)

    def _build_devices_tab(self):
        page = QWidget(); layout = QVBoxLayout(page)
        layout.addWidget(QLabel("设备状态来自本地设备配置与 JMF 查询。未配置 JMF 的设备仍可参与本地排程。"))
        self.device_table = QTableWidget(0, 8)
        self.device_table.setHorizontalHeaderLabels(["设备", "类型", "状态", "当前工单", "进度", "待产", "JMF", "备注"])
        self.device_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        layout.addWidget(self.device_table, 1)
        self.tabs.addTab(page, "设备看板")

    def _build_schedule_tab(self):
        page = QWidget(); layout = QVBoxLayout(page)
        row = QHBoxLayout()
        row.addWidget(QLabel("选中任务："))
        self.device_combo = QComboBox()
        row.addWidget(self.device_combo)
        self.priority = QSpinBox(); self.priority.setRange(1, 9999); self.priority.setValue(100)
        row.addWidget(QLabel("优先级（越小越先）")); row.addWidget(self.priority)
        self.assign_btn = QPushButton("派到设备")
        self.priority_btn = QPushButton("更新优先级")
        row.addWidget(self.assign_btn); row.addWidget(self.priority_btn); row.addStretch()
        layout.addLayout(row)
        self.schedule_table = ScheduleTable(0, 9)
        self.schedule_table.setHorizontalHeaderLabels(["ID", "队列状态", "订单", "设备", "优先级", "计划状态", "输出", "创建时间", "派机原因"])
        self.schedule_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.schedule_table.setSelectionMode(QAbstractItemView.SingleSelection)
        layout.addWidget(self.schedule_table, 1)
        self.assign_btn.clicked.connect(self.assign_selected)
        self.priority_btn.clicked.connect(self.update_priority)
        self.schedule_table.order_changed.connect(self.persist_drag_order)
        self.tabs.addTab(page, "生产排程")

    def _build_ink_tab(self):
        page = QWidget(); layout = QVBoxLayout(page)
        row = QHBoxLayout()
        self.ink_pdf = QLineEdit(); self.ink_pdf.setPlaceholderText("选择已拼版生产 PDF")
        self.ink_zones = QSpinBox(); self.ink_zones.setRange(2, 64); self.ink_zones.setValue(32)
        choose = QPushButton("选择 PDF")
        calc = QPushButton("计算墨键")
        row.addWidget(self.ink_pdf, 1); row.addWidget(choose); row.addWidget(QLabel("墨键区")); row.addWidget(self.ink_zones); row.addWidget(calc)
        layout.addLayout(row)
        layout.addWidget(QLabel("以下是基于 Ghostscript CMYK 分色预览计算的区域覆盖率。正式上机必须按具体 RIP/印刷机校准。"))
        self.ink_table = QTableWidget(0, 4)
        self.ink_table.setHorizontalHeaderLabels(["分色", "平均覆盖率", "最小", "最大"])
        layout.addWidget(self.ink_table)
        self.ink_bars = QVBoxLayout(); layout.addLayout(self.ink_bars); layout.addStretch()
        choose.clicked.connect(self.choose_ink_pdf); calc.clicked.connect(self.calculate_ink)
        self.tabs.addTab(page, "CIP3 墨键")

    def _build_die_tab(self):
        page = QWidget(); layout = QVBoxLayout(page)
        row = QHBoxLayout(); self.die_search = QLineEdit(); self.die_search.setPlaceholderText("客户 / 产品编码 / 刀版名")
        search_btn = QPushButton("搜索"); add_btn = QPushButton("导入刀版")
        row.addWidget(self.die_search,1); row.addWidget(search_btn); row.addWidget(add_btn); layout.addLayout(row)
        self.die_table = QTableWidget(0, 7)
        self.die_table.setHorizontalHeaderLabels(["刀版", "客户", "产品编码", "尺寸", "专色", "文件", "SHA-256"])
        layout.addWidget(self.die_table,1)
        search_btn.clicked.connect(self.refresh_dies); add_btn.clicked.connect(self.add_die)
        self.tabs.addTab(page, "刀版库")

    def _build_erp_tab(self):
        page = QWidget(); layout = QVBoxLayout(page)
        layout.addWidget(QLabel("ERP API 默认仅监听 127.0.0.1。局域网部署建议由 HTTPS 反向代理暴露，并设置 Bearer Token。"))
        row = QHBoxLayout()
        self.erp_port = QSpinBox(); self.erp_port.setRange(0, 65535); self.erp_port.setValue(8765)
        self.erp_token = QLineEdit(); self.erp_token.setEchoMode(QLineEdit.Password); self.erp_token.setPlaceholderText("Bearer Token（可选）")
        self.erp_toggle = QPushButton("启动 ERP 接口")
        row.addWidget(QLabel("端口")); row.addWidget(self.erp_port); row.addWidget(self.erp_token,1); row.addWidget(self.erp_toggle)
        layout.addLayout(row)
        self.erp_status = QLabel("未启动")
        layout.addWidget(self.erp_status)
        layout.addWidget(QLabel("收到的 ERP 工单会自动转换成持久生产队列任务，并尝试按设备能力自动派机。"))
        layout.addStretch()
        self.erp_toggle.clicked.connect(self.toggle_erp)
        self.tabs.addTab(page, "ERP 自动接单")

    def _selected_job_id(self) -> int | None:
        row = self.schedule_table.currentRow()
        if row < 0 or not self.schedule_table.item(row, 0):
            return None
        return int(self.schedule_table.item(row, 0).text())

    def refresh_all(self):
        snap = self.scheduler.dashboard_snapshot()
        devices = snap["devices"]
        jobs = snap["jobs"]
        running = sum(1 for d in devices if (d.get("runtime") or {}).get("device_status") in {"Running", "Production", "Setup"})
        self.summary.setText(f"设备 {len(devices)} · 运行 {running} · 待产/生产中 {len(jobs)}")

        self.device_combo.clear()
        self.device_combo.addItem("未指定", "")
        for d in devices:
            self.device_combo.addItem(d["name"], d["id"])

        self.device_table.setRowCount(0)
        for d in devices:
            r = self.device_table.rowCount(); self.device_table.insertRow(r)
            rt = d.get("runtime") or {}
            pct = rt.get("percent_completed")
            values = [
                d["name"], d["kind"], rt.get("device_status") or "Unknown",
                rt.get("job_id") or "-", "-" if pct is None else f"{float(pct):.1f}%",
                d.get("queue_load", 0), "已配置" if d.get("jmf_url") else "-", rt.get("message") or d.get("notes") or "",
            ]
            for c, v in enumerate(values): self.device_table.setItem(r, c, QTableWidgetItem(str(v)))
        self.device_table.resizeColumnsToContents()

        self.schedule_table.setRowCount(0)
        device_names = {d["id"]: d["name"] for d in devices}
        for j in jobs:
            r = self.schedule_table.rowCount(); self.schedule_table.insertRow(r)
            values = [j["id"], j["status"], j["title"], device_names.get(j.get("device_id"), j.get("device_id") or "未派机"), j.get("priority", 100), j.get("schedule_state", "planned"), j["output_path"], j["created_at"], j.get("schedule_reason", "")]
            for c, v in enumerate(values): self.schedule_table.setItem(r, c, QTableWidgetItem(str(v)))
        self.schedule_table.resizeColumnsToContents()
        self.refresh_dies()

    def poll_devices(self):
        if self.poll_worker and self.poll_worker.isRunning(): return
        self.poll_btn.setEnabled(False)
        self.poll_worker = StatusPollWorker(self.monitor, self.registry.load(), self)
        self.poll_worker.done.connect(self._poll_done)
        self.poll_worker.start()

    def _poll_done(self, results):
        self.poll_btn.setEnabled(True)
        failures = sum(1 for r in results if not r.ok and r.error != "未配置 JMF URL")
        self.refresh_all()
        if failures:
            self.summary.setText(self.summary.text() + f" · JMF异常 {failures}")

    def auto_assign(self):
        assigned = self.scheduler.auto_assign_all()
        self.refresh_all()
        QMessageBox.information(self, "自动派机", f"已自动分配 {len(assigned)} 个待产任务。")

    def assign_selected(self):
        job_id = self._selected_job_id()
        if job_id is None: return
        try:
            device_id = str(self.device_combo.currentData() or "")
            if not device_id:
                self.scheduler.auto_assign_job(job_id)
            else:
                self.scheduler.assign_job(job_id, device_id, priority=self.priority.value(), reason="生产控制台人工派机")
            self.refresh_all()
        except Exception as exc:
            QMessageBox.warning(self, "派机失败", str(exc))


    def persist_drag_order(self):
        """Persist drag/drop row order as scheduling priority."""
        try:
            for row in range(self.schedule_table.rowCount()):
                item = self.schedule_table.item(row, 0)
                if item:
                    self.scheduler.set_priority(int(item.text()), (row + 1) * 10)
            self.refresh_all()
        except Exception as exc:
            QMessageBox.warning(self, "更新排程失败", str(exc))

    def update_priority(self):
        job_id = self._selected_job_id()
        if job_id is None: return
        self.scheduler.set_priority(job_id, self.priority.value()); self.refresh_all()

    def choose_ink_pdf(self):
        path, _ = QFileDialog.getOpenFileName(self, "选择生产 PDF", "", "PDF (*.pdf)")
        if path: self.ink_pdf.setText(path)

    def _clear_bars(self):
        while self.ink_bars.count():
            item = self.ink_bars.takeAt(0)
            widget = item.widget()
            if widget: widget.deleteLater()

    def calculate_ink(self):
        path = self.ink_pdf.text().strip()
        if not path: return
        try:
            seps = rasterize_separations_with_ghostscript(path, dpi=72, page=1)
            results = [calculate_zones_from_grayscale(img, self.ink_zones.value(), ch) for ch, img in sorted(seps.items())]
            self.ink_table.setRowCount(0); self._clear_bars()
            for result in results:
                r = self.ink_table.rowCount(); self.ink_table.insertRow(r)
                vals = [result.channel, f"{result.average:.2f}%", f"{min(result.zones):.2f}%", f"{max(result.zones):.2f}%"]
                for c,v in enumerate(vals): self.ink_table.setItem(r,c,QTableWidgetItem(v))
                label = QLabel(result.channel + "  " + " | ".join(f"{v:.0f}" for v in result.zones))
                label.setWordWrap(True); self.ink_bars.addWidget(label)
            self.ink_table.resizeColumnsToContents()
        except Exception as exc:
            QMessageBox.warning(self, "墨键计算失败", str(exc))

    def refresh_dies(self):
        if not hasattr(self, "die_table"): return
        rows = self.dies.list(self.die_search.text().strip() if hasattr(self, "die_search") else "")
        self.die_table.setRowCount(0)
        for a in rows:
            r=self.die_table.rowCount(); self.die_table.insertRow(r)
            values=[a.name,a.customer,a.product_code,f"{a.width_mm:g}×{a.height_mm:g}",a.spot_name,a.source_file,a.sha256[:16]]
            for c,v in enumerate(values): self.die_table.setItem(r,c,QTableWidgetItem(str(v)))
        self.die_table.resizeColumnsToContents()

    def add_die(self):
        path, _ = QFileDialog.getOpenFileName(self, "导入刀版", "", "印刷文件 (*.pdf *.ai *.eps *.svg);;所有文件 (*)")
        if not path: return
        try:
            self.dies.add(path); self.refresh_dies()
        except Exception as exc:
            QMessageBox.warning(self, "刀版导入失败", str(exc))

    def toggle_erp(self):
        if self.erp_server.server:
            self.erp_server.stop(); self.erp_toggle.setText("启动 ERP 接口"); self.erp_status.setText("未启动"); return
        try:
            host, port = self.erp_server.start(host="127.0.0.1", port=self.erp_port.value(), api_token=self.erp_token.text())
            self.erp_toggle.setText("停止 ERP 接口")
            self.erp_status.setText(f"已启动：http://{host}:{port} · POST /v1/jobs")
        except Exception as exc:
            QMessageBox.warning(self, "ERP 接口启动失败", str(exc))

    def _drain_erp(self):
        count = 0
        while True:
            try:
                request = self.erp_server.bridge.queue.get_nowait()
            except queue.Empty:
                break
            try:
                self.erp_dispatcher.enqueue(request, auto_assign=True); count += 1
            except Exception as exc:
                self.db.audit("erp.dispatch_failed", {"request_id": request.request_id, "error": str(exc)}, "error")
        if count: self.refresh_all()

    def _tick(self):
        self._drain_erp()
        self.refresh_all()

    def closeEvent(self, event):
        try: self.erp_server.stop()
        except Exception: pass
        super().closeEvent(event)
