from __future__ import annotations
from pathlib import Path
from help_center import search_help
try:
    from PySide6.QtWidgets import QDialog, QHBoxLayout, QLineEdit, QListWidget, QListWidgetItem, QPushButton, QTextBrowser, QVBoxLayout
except ImportError:
    QDialog = object
if QDialog is not object:
    class HelpCenterDialog(QDialog):
        def __init__(self, root: str | Path, parent=None):
            super().__init__(parent); self.root = Path(root); self.setWindowTitle("帮助中心"); self.resize(980, 650)
            outer = QVBoxLayout(self); top = QHBoxLayout(); self.query = QLineEdit(); self.query.setPlaceholderText("搜索拼版、PDF/X、设备、MES、报价……")
            btn = QPushButton("搜索"); btn.clicked.connect(self.refresh); top.addWidget(self.query); top.addWidget(btn); outer.addLayout(top)
            body = QHBoxLayout(); self.list = QListWidget(); self.text = QTextBrowser(); self.list.currentRowChanged.connect(self._open)
            body.addWidget(self.list, 1); body.addWidget(self.text, 3); outer.addLayout(body); self.articles=[]; self.refresh()
        def refresh(self):
            self.articles = search_help(self.root, self.query.text(), 50); self.list.clear()
            for art in self.articles: self.list.addItem(QListWidgetItem(art.title))
            if self.articles: self.list.setCurrentRow(0)
        def _open(self, row):
            if row < 0 or row >= len(self.articles): return
            art = self.articles[row]; self.text.setMarkdown(art.path.read_text(encoding="utf-8", errors="ignore"))
