# V2.1.3 Windows Python detection fix

针对已确认的现场错误：

- winget 成功安装 Python 3.12.10；
- 当前 PowerShell 会话尚未刷新 `PATH` / `py.exe`；
- V2.1.2 因此误报“Python 安装后仍未被识别”。

V2.1.3 的查找顺序：

1. `py.exe`
2. `python.exe` / `python3.exe`
3. Python 注册表 `PythonCore`
4. `%LOCALAPPDATA%\Programs\Python\Python313/312/311/310\python.exe`
5. `%ProgramFiles%\Python313/312/311/310\python.exe`

winget 安装后最多轮询 10 秒，并直接使用绝对路径，不需要重启 Windows。
