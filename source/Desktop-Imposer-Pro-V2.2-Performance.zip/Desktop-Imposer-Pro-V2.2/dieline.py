from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import re
from pypdf import PdfReader
from pypdf.generic import ContentStream, ArrayObject, NameObject

DEFAULT_NAMES=('cutcontour','diecut','dieline','cut','knife','刀线','模切')

@dataclass(frozen=True)
class DielineResult:
    page:int
    spot_name:str
    polygons:list[list[tuple[float,float]]]
    warnings:list[str]


def _spot_map(page):
    out={}
    res=page.get('/Resources') or {}
    spaces=res.get('/ColorSpace') or {}
    try: spaces=spaces.get_object()
    except Exception: pass
    for key,val in spaces.items():
        try: obj=val.get_object()
        except Exception: obj=val
        if isinstance(obj,ArrayObject) and len(obj)>=2 and str(obj[0]) in ('/Separation','/DeviceN'):
            if str(obj[0])=='/Separation': names=[str(obj[1]).lstrip('/')]
            else:
                try: names=[str(x).lstrip('/') for x in obj[1]]
                except Exception: names=[]
            out[str(key)]=names
    return out


def extract_dielines(pdf_path:str|Path, keywords=DEFAULT_NAMES)->list[DielineResult]:
    """Extract simple closed stroked spot-color line polygons from PDF pages.

    Supports m/l/re/h + stroke operators. Bezier curves, clipping transforms,
    form XObjects and complex graphics-state nesting are reported as warnings
    rather than silently approximated.
    """
    reader=PdfReader(str(pdf_path)); results=[]
    keys=[k.casefold() for k in keywords]
    for pno,page in enumerate(reader.pages,1):
        smap=_spot_map(page); target_resources={res:n for res,names in smap.items() for n in names if any(k in n.casefold() for k in keys)}
        if not target_resources: continue
        try: cs=ContentStream(page.get_contents(),reader)
        except Exception as e:
            results.append(DielineResult(pno,','.join(target_resources.values()),[],[f'内容流无法解析: {e}'])); continue
        current_spot=None; sub=[]; polys=[]; warnings=[]
        for operands,op in cs.operations:
            op=op.decode('latin1') if isinstance(op,bytes) else str(op)
            if op=='CS' and operands:
                current_spot=target_resources.get(str(operands[0]))
            elif current_spot and op=='m' and len(operands)>=2:
                sub=[(float(operands[0]),float(operands[1]))]
            elif current_spot and op=='l' and len(operands)>=2 and sub:
                sub.append((float(operands[0]),float(operands[1])))
            elif current_spot and op=='re' and len(operands)>=4:
                x,y,w,h=map(float,operands[:4]); sub=[(x,y),(x+w,y),(x+w,y+h),(x,y+h),(x,y)]
            elif current_spot and op in ('c','v','y'):
                warnings.append('检测到贝塞尔刀线路径：当前基础提取器不自动离散曲线')
            elif current_spot and op=='h' and sub and sub[0]!=sub[-1]:
                sub.append(sub[0])
            elif current_spot and op in ('S','s','B','B*','b','b*'):
                if len(sub)>=4 and sub[0]==sub[-1]: polys.append(sub)
                sub=[]
        results.append(DielineResult(pno,','.join(sorted(set(target_resources.values()))),polys,sorted(set(warnings))))
    return results
