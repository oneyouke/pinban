from __future__ import annotations

try:
    from PySide6.QtCore import Qt, Signal
    from PySide6.QtWidgets import QDialog, QGridLayout, QGroupBox, QLabel, QPushButton, QVBoxLayout
except ImportError:  # allows non-GUI CI/tests
    QDialog = object

from access_control import UserSession
from branding import BrandConfig
from localization import Translator

MODULES = [
    ("prepress", "app.prepress", "imposition.edit"),
    ("production", "app.production", "queue.read"),
    ("mes", "app.mes", "mes.read"),
    ("factory", "app.factory", "inventory.read"),
    ("commercial", "app.commercial", "order.read"),
    ("admin", "app.admin", "users.manage"),
]

if QDialog is not object:
    class ProductWorkspaceDialog(QDialog):
        moduleRequested = Signal(str)
        def __init__(self, brand: BrandConfig, translator: Translator, session: UserSession | None, parent=None):
            super().__init__(parent)
            self.setWindowTitle(f"{brand.product_name} · {translator.tr('app.home')}")
            self.resize(840, 560)
            outer = QVBoxLayout(self)
            title = QLabel(brand.product_name)
            title.setStyleSheet("font-size:24px;font-weight:700")
            outer.addWidget(title)
            who = session.display_name if session else "未登录"
            outer.addWidget(QLabel(f"{brand.company_name} · {who}"))
            grid = QGridLayout()
            row = col = 0
            for key, label_key, perm in MODULES:
                allowed = session is not None and (session.can(perm) or session.can("*"))
                box = QGroupBox(translator.tr(label_key))
                lay = QVBoxLayout(box)
                btn = QPushButton("打开" if translator.locale == "zh_CN" else "Open")
                btn.setEnabled(allowed)
                btn.clicked.connect(lambda _=False, k=key: self.moduleRequested.emit(k))
                lay.addWidget(btn)
                if not allowed:
                    lay.addWidget(QLabel("无权限" if translator.locale == "zh_CN" else "No permission"))
                grid.addWidget(box, row, col)
                col += 1
                if col >= 3:
                    row += 1; col = 0
            outer.addLayout(grid)
