Desktop Imposer Pro V2.1 - Windows Desktop Installation
=======================================================

Fastest path:
1. Extract this ZIP to a normal local folder (do not run directly inside the ZIP).
2. Double-click: INSTALL_TO_DESKTOP.bat
3. The script will check/install Python 3.12 and NSIS when winget is available.
4. It runs the full regression suite, builds the Windows app, creates Setup.exe,
   silently installs it for the current Windows user, creates a desktop shortcut,
   and launches the application.

Outputs:
- release\\DesktopImposerPro-*-Setup-x64.exe
- release\\DesktopImposerPro-*-Portable.zip
- Desktop shortcut: 桌面拼版软件 Pro

Offline build:
- Preinstall Python 3.12 x64 and NSIS, then double-click INSTALL_TO_DESKTOP.bat.

Commercial release:
- Replace company/brand placeholders and EULA.
- Use BUILD_SIGNED_COMMERCIAL_RELEASE.bat with a valid Windows code-signing certificate.
