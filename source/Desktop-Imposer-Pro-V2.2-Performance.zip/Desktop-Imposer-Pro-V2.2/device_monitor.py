from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Iterable

from device_center import DeviceProfile
from jmf import build_status_query, parse_status_response, post_jmf, JMFStatus
from production_scheduler import ProductionScheduler


@dataclass(frozen=True)
class PollResult:
    device_id: str
    ok: bool
    status: JMFStatus | None = None
    error: str = ""


class DeviceMonitor:
    """Synchronous JMF poller designed to be called from a worker/timer thread."""

    def __init__(self, scheduler: ProductionScheduler, timeout: float = 5.0):
        self.scheduler = scheduler
        self.timeout = float(timeout)

    def poll(self, device: DeviceProfile) -> PollResult:
        if not device.jmf_url:
            self.scheduler.update_device_runtime(device.id, device_status="Unconfigured", message="未配置 JMF URL")
            return PollResult(device.id, False, error="未配置 JMF URL")
        try:
            code, body = post_jmf(device.jmf_url, build_status_query(device.id), timeout=self.timeout)
            if not (200 <= code < 300):
                raise RuntimeError(f"HTTP {code}")
            status = parse_status_response(body)
            self.scheduler.update_device_runtime(
                device.id,
                device_status=status.device_status,
                job_id=status.job_id,
                job_part_id=status.job_part_id,
                job_status=status.job_status,
                percent_completed=status.percent_completed,
                message="JMF 状态更新成功",
            )
            return PollResult(device.id, True, status=status)
        except Exception as exc:
            self.scheduler.update_device_runtime(device.id, device_status="Offline", message=str(exc))
            return PollResult(device.id, False, error=str(exc))

    def poll_all(self, devices: Iterable[DeviceProfile]) -> list[PollResult]:
        return [self.poll(d) for d in devices if d.enabled]
