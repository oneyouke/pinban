from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

@dataclass(frozen=True)
class HelpArticle:
    title: str
    path: Path
    excerpt: str

DEFAULT_DOCS = [
    "README.md", "AUTO_PACKAGING.md", "PROFESSIONAL_PREFLIGHT_PROTOCOL.md", "V13_DEVICE_INTEGRATION.md",
    "V14_PRODUCTION_CONSOLE.md", "V15_MES.md", "V16_SMART_PRODUCTION.md", "V17_SMART_FACTORY.md",
    "V18_COMMERCIAL_OPERATIONS.md", "V19_SALES_FINANCE.md", "V20_PRODUCTIZATION.md",
]

def search_help(root: str | Path, query: str, limit: int = 20) -> list[HelpArticle]:
    root = Path(root)
    terms = [t.lower() for t in query.split() if t.strip()]
    results: list[tuple[int, HelpArticle]] = []
    for name in DEFAULT_DOCS:
        path = root / name
        if not path.exists():
            continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        hay = text.lower()
        score = sum(hay.count(t) for t in terms) if terms else 1
        if score <= 0:
            continue
        first = next((line.strip("# ") for line in text.splitlines() if line.startswith("#")), path.stem)
        compact = " ".join(line.strip() for line in text.splitlines() if line.strip() and not line.startswith("#"))
        results.append((score, HelpArticle(first, path, compact[:240])))
    results.sort(key=lambda x: (-x[0], x[1].title))
    return [item for _, item in results[:limit]]
