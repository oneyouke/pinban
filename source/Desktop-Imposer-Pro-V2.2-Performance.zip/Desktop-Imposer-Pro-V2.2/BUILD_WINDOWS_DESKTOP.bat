@echo off
setlocal
cd /d "%~dp0"

echo =====================================================
echo   Desktop Imposer Pro V2.1 - Windows Build
echo =====================================================
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0auto_package_windows.ps1"
set "ERR=%ERRORLEVEL%"

if not "%ERR%"=="0" (
  echo.
  echo [FAILED] Build failed. Error code: %ERR%
  pause
  exit /b %ERR%
)

echo.
echo [OK] Build completed.
echo Output: %~dp0release
explorer.exe "%~dp0release"
pause
endlocal
