from __future__ import annotations

import hashlib
import json
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Sequence

from pypdf import PdfReader

from imposition import InputJob, ImpositionSettings, impose_jobs
from preflight_provider import run_preflight
from product import APP_NAME, APP_VERSION
from storage import ProductionDB


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def sha256_file(path: str | Path, chunk: int = 1024 * 1024) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        while True:
            block = f.read(chunk)
            if not block:
                break
            h.update(block)
    return h.hexdigest()


def input_manifest(jobs: Sequence[InputJob]) -> list[dict[str, Any]]:
    result = []
    seen: dict[str, str] = {}
    for job in jobs:
        path = str(Path(job.path).resolve())
        digest = seen.get(path)
        if digest is None:
            digest = sha256_file(path)
            seen[path] = digest
        result.append({
            "path": path,
            "sha256": digest,
            "quantity": int(job.quantity),
            "trim_width_mm": float(job.trim_width_mm) if job.trim_width_mm is not None else None,
            "trim_height_mm": float(job.trim_height_mm) if job.trim_height_mm is not None else None,
            "bleed_mm": float(job.bleed_mm) if job.bleed_mm is not None else None,
            "name": str(job.name or Path(job.path).stem),
        })
    return result


def validate_pdf_output(path: str | Path, expected_pages: int | None = None) -> dict[str, Any]:
    src = Path(path)
    if not src.exists() or src.stat().st_size < 100:
        raise RuntimeError("输出 PDF 不存在或大小异常")
    reader = PdfReader(str(src), strict=False)
    page_count = len(reader.pages)
    if page_count < 1:
        raise RuntimeError("输出 PDF 没有页面")
    if expected_pages is not None and page_count != expected_pages:
        raise RuntimeError(f"输出 PDF 页数校验失败：期望 {expected_pages}，实际 {page_count}")
    # Touch every page's media box so broken xrefs/page dictionaries surface now.
    for page in reader.pages:
        _ = float(page.mediabox.width), float(page.mediabox.height)
    return {"page_count": page_count, "size_bytes": src.stat().st_size}


def atomic_production_export(jobs: Sequence[InputJob], output_path: str | Path, settings: ImpositionSettings,
                             layout_override: dict | None = None, db: ProductionDB | None = None,
                             write_manifest: bool = True, preflight_report: dict[str, Any] | None = None) -> dict[str, Any]:
    if not jobs:
        raise ValueError("没有生产任务")
    dst = Path(output_path)
    if dst.suffix.lower() != ".pdf":
        dst = dst.with_suffix(".pdf")
    dst.parent.mkdir(parents=True, exist_ok=True)

    preflight = preflight_report or run_preflight(jobs, settings)
    if preflight.get("errors"):
        if db:
            try:
                db.audit("production.preflight_blocked", {"output": str(dst), "errors": preflight["errors"]}, "error")
            except Exception:
                pass
        raise ValueError("印前检查未通过：\n" + "\n".join(preflight["errors"][:12]))

    inputs = input_manifest(jobs)
    fd, tmp_name = tempfile.mkstemp(prefix=f".{dst.stem}.", suffix=".partial.pdf", dir=str(dst.parent))
    os.close(fd)
    tmp = Path(tmp_name)
    committed = False
    try:
        summary = impose_jobs(jobs, tmp, settings, layout_override=layout_override)
        check = validate_pdf_output(tmp, expected_pages=int(summary.get("output_pages") or 0) or None)
        digest = sha256_file(tmp)
        with tmp.open("rb") as f:
            os.fsync(f.fileno())
        os.replace(tmp, dst)
        committed = True

        manifest = {
            "schema_version": 1,
            "app": APP_NAME,
            "app_version": APP_VERSION,
            "created_at": utc_now(),
            "output": str(dst.resolve()),
            "output_sha256": digest,
            "output_size_bytes": check["size_bytes"],
            "output_pages": check["page_count"],
            "inputs": inputs,
            "summary": summary,
            "preflight": preflight,
            "settings": settings.to_dict(),
            "manual_layout": bool(layout_override),
            "record_warnings": [],
        }

        if write_manifest:
            try:
                sidecar = dst.with_suffix(dst.suffix + ".production.json")
                side_tmp = sidecar.with_suffix(sidecar.suffix + ".tmp")
                side_tmp.write_text(json.dumps(manifest, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
                os.replace(side_tmp, sidecar)
                manifest["manifest_path"] = str(sidecar)
            except Exception as exc:
                manifest["record_warnings"].append(f"生产清单写入失败：{exc}")
                if db:
                    try:
                        db.audit("production.manifest_write_failed", {"output": str(dst), "error": str(exc)}, "warning")
                    except Exception:
                        pass

        if db:
            try:
                db.audit("production.export_succeeded", {
                    "output": str(dst), "sha256": digest, "pages": check["page_count"],
                    "items": summary.get("total_items"), "warnings": len(preflight.get("warnings") or []),
                    "record_warnings": manifest["record_warnings"],
                })
            except Exception as exc:
                manifest["record_warnings"].append(f"审计数据库写入失败：{exc}")
        return manifest
    except Exception as exc:
        try:
            tmp.unlink(missing_ok=True)
        except Exception:
            pass
        # Only call the PDF production itself failed when final output was never committed.
        if not committed and db:
            try:
                db.audit("production.export_failed", {"output": str(dst), "error": str(exc)}, "error")
            except Exception:
                pass
        if committed:
            # Defensive path: a post-commit bookkeeping exception should not be reported as a failed PDF export.
            return {
                "schema_version": 1, "app": APP_NAME, "app_version": APP_VERSION,
                "created_at": utc_now(), "output": str(dst.resolve()),
                "output_sha256": sha256_file(dst), "output_size_bytes": dst.stat().st_size,
                "output_pages": validate_pdf_output(dst)["page_count"],
                "inputs": inputs, "summary": summary, "preflight": preflight,
                "settings": settings.to_dict(), "manual_layout": bool(layout_override),
                "record_warnings": [f"生产 PDF 已提交，但后续记录步骤发生错误：{exc}"],
            }
        raise
