from __future__ import annotations

import os
import sys
from pathlib import Path
from product import APP_SHORT_NAME


def _home() -> Path:
    return Path.home()


def data_dir() -> Path:
    if sys.platform.startswith("win"):
        base = Path(os.environ.get("LOCALAPPDATA") or os.environ.get("APPDATA") or _home())
        path = base / APP_SHORT_NAME
    elif sys.platform == "darwin":
        path = _home() / "Library" / "Application Support" / APP_SHORT_NAME
    else:
        base = Path(os.environ.get("XDG_DATA_HOME") or (_home() / ".local" / "share"))
        path = base / APP_SHORT_NAME
    path.mkdir(parents=True, exist_ok=True)
    return path


def config_dir() -> Path:
    if sys.platform.startswith("win"):
        base = Path(os.environ.get("APPDATA") or os.environ.get("LOCALAPPDATA") or _home())
        path = base / APP_SHORT_NAME
    elif sys.platform == "darwin":
        path = _home() / "Library" / "Preferences" / APP_SHORT_NAME
    else:
        base = Path(os.environ.get("XDG_CONFIG_HOME") or (_home() / ".config"))
        path = base / APP_SHORT_NAME
    path.mkdir(parents=True, exist_ok=True)
    return path


def log_dir() -> Path:
    path = data_dir() / "logs"
    path.mkdir(parents=True, exist_ok=True)
    return path


def autosave_dir() -> Path:
    path = data_dir() / "autosave"
    path.mkdir(parents=True, exist_ok=True)
    return path


def database_path() -> Path:
    return data_dir() / "production.sqlite3"


def license_path() -> Path:
    return config_dir() / "license.json"


def state_path() -> Path:
    return config_dir() / "state.json"


def devices_path() -> Path:
    return config_dir() / "devices.json"


def die_library_dir() -> Path:
    path = data_dir() / "die_library"
    path.mkdir(parents=True, exist_ok=True)
    return path


def backup_dir() -> Path:
    path = data_dir() / "backups"
    path.mkdir(parents=True, exist_ok=True)
    return path
