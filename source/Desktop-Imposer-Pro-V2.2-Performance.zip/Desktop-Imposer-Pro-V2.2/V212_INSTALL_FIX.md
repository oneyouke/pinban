# V2.1.2 快速桌面安装修复版

优先双击 `INSTALL_TO_DESKTOP.bat`。

本版修复：
- 不再强制要求 Python 3.12；自动选择任意可用 Python 3.10+。
- 默认不跑 V1.0～V2.1 全量历史回归，只跑核心自检。
- 不依赖 NSIS。
- 封装后使用 offscreen Qt/PDF 自检。
- 桌面同时创建 `.cmd` 启动器；即使公司策略禁止创建 `.lnk`，仍可启动。
- 全程写入 `logs/install-*.log`。

如果失败：
1. 先运行 `RUN_DIAGNOSTIC.bat`。
2. 把 `diagnostic.txt` 和 `logs` 目录最新的 `install-*.log` 发给技术支持。
