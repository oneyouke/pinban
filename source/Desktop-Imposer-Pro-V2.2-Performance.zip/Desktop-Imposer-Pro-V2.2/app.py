from __future__ import annotations

import csv
import json
import os
import sys
import tempfile
from pathlib import Path

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QAction, QFont
from PySide6.QtPdf import QPdfDocument
from PySide6.QtPdfWidgets import QPdfView
from PySide6.QtWidgets import (
    QApplication, QCheckBox, QComboBox, QDoubleSpinBox, QFileDialog,
    QDialog, QFormLayout, QFrame, QHBoxLayout, QLabel, QLineEdit, QMainWindow,
    QMessageBox, QPushButton, QScrollArea, QSpinBox, QSplitter, QStatusBar,
    QTabWidget, QTableWidget, QTableWidgetItem, QHeaderView, QToolBar, QVBoxLayout, QWidget,
)

from imposition import (
    InputJob, ImpositionSettings, calculate_grid, estimate_smart_layout, impose_jobs,
    inspect_source, plan_smart_layout, validate_manual_layout,
)
from layout_editor import LayoutEditorDialog, DuplexOverlayDialog
from hotfolder import HotFolderProcessor
from app_paths import autosave_dir, devices_path
from licensing import LicenseManager, machine_fingerprint
from product import APP_NAME, APP_VERSION, SUPPORT_EMAIL, VENDOR_NAME
from production_service import atomic_production_export
from preflight_provider import run_preflight
from project_file import build_project_snapshot, load_project, save_project as write_project_file
from queue_dialog import ProductionQueueDialog, QueueWorker
from queue_service import PersistentQueue
from storage import ProductionDB
from support import configure_logging, create_support_bundle, install_exception_hook
from updates import check_for_update
from update_staging import stage_signed_update
from device_center import DeviceRegistry
from device_dialog import DeviceCenterDialog
from production_scheduler import ProductionScheduler
from production_console import ProductionConsoleDialog
from mes_console import MESConsoleDialog
from smart_factory_console import SmartFactoryConsoleDialog
from commercial_console import CommercialConsoleDialog
from access_control import UserStore, require, AccessDenied
from backup_restore import create_backup, restore_backup, inspect_backup
from branding import load_brand
from localization import Translator
from product_workspace import ProductWorkspaceDialog
from security_dialog import LoginDialog, FirstAdminDialog, UserManagementDialog
from help_dialog import HelpCenterDialog
from runtime_resilience import CrashMarker, AuditTrail
from backup_scheduler import ScheduledBackupService, BackupPolicy
from health_check import run_health_checks



PAPER_PRESETS = {
    "SRA3 450 × 320 mm": (450.0, 320.0),
    "A3 420 × 297 mm": (420.0, 297.0),
    "A4 297 × 210 mm": (297.0, 210.0),
    "大度 889 × 1194 mm": (889.0, 1194.0),
    "正度 787 × 1092 mm": (787.0, 1092.0),
    "自定义": None,
}

SOURCE_BOX_LABELS = {
    "裁切/CropBox": "crop",
    "媒体/MediaBox": "media",
    "成品/TrimBox": "trim",
    "出血/BleedBox": "bleed",
}

SCALE_MODE_LABELS = {
    "适配缩放（保持比例）": "fit",
    "1:1 原尺寸（生产推荐）": "actual",
}

APP_STYLE = """
QMainWindow, QWidget { background: #f3f5f7; color: #17212b; font-size: 13px; }
QFrame#Panel { background: white; border: 1px solid #dfe5eb; border-radius: 10px; }
QLabel#Title { font-size: 19px; font-weight: 700; }
QLabel#Section { font-size: 13px; font-weight: 700; color: #425466; margin-top: 4px; }
QPushButton { min-height: 32px; padding: 0 12px; border: 1px solid #cfd8e3; border-radius: 7px; background: white; }
QPushButton:hover { background: #f6f8fa; }
QPushButton#Primary { background: #1f6feb; color: white; border: none; font-weight: 700; }
QPushButton#Primary:hover { background: #195fc9; }
QListWidget, QComboBox, QSpinBox, QDoubleSpinBox { background: white; border: 1px solid #cfd8e3; border-radius: 6px; min-height: 28px; }
QPdfView { background: #cfd5dc; border: 1px solid #c7d0da; border-radius: 10px; }
QTabWidget::pane { border: 1px solid #e1e6eb; border-radius: 8px; background: white; }
QTabBar::tab { padding: 7px 11px; }
"""


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"{APP_NAME} · V{APP_VERSION}")
        self.resize(1450, 900)
        self.logger = configure_logging()
        self._crash_marker = CrashMarker()
        self._runtime_recovery = self._crash_marker.begin()
        self.db = ProductionDB()
        self._previous_clean_shutdown = bool(self.db.get_setting("session.clean_shutdown", True))
        self.db.set_setting("session.clean_shutdown", False)
        self.license_manager = LicenseManager()
        self._current_project_path: str | None = None
        self._preview_path: str | None = None
        self._layout_override: dict | None = None
        self._pdf_doc = QPdfDocument(self)
        self._hot_processor = HotFolderProcessor()
        self._hot_timer = QTimer(self)
        self._hot_timer.setInterval(3000)
        self._autosave_timer = QTimer(self)
        self._autosave_timer.setInterval(60000)
        self._autosave_timer.timeout.connect(self._autosave_project)
        self._device_registry = DeviceRegistry(devices_path())
        self._scheduler = ProductionScheduler(self.db, self._device_registry)
        self._persistent_queue = PersistentQueue(self.db, scheduler=self._scheduler, registry=self._device_registry)
        self._queue_worker: QueueWorker | None = None
        self._active_scheduled_job_id: int | None = None
        self._queue_timer = QTimer(self)
        self._queue_timer.setInterval(2000)
        self._queue_timer.timeout.connect(self._process_queue_tick)
        self._user_store = UserStore(self.db.path)
        self._session = None
        self._brand = load_brand()
        self._translator = Translator(self.db.get_setting("ui.locale", "zh_CN"))
        self._security_audit = AuditTrail(self.db.path)
        self._backup_service = ScheduledBackupService()
        self._backup_timer = QTimer(self)
        self._backup_timer.setInterval(60 * 60 * 1000)
        self._backup_timer.timeout.connect(self._automatic_backup_tick)

        self._build_ui()
        self._connect_signals()
        self._apply_preset()
        self._toggle_grid_mode(self.auto_grid.isChecked())
        self._toggle_smart_mixed(self.smart_mixed_sizes.isChecked())
        self._toggle_mark_controls(self.crop_marks.isChecked())
        self._toggle_duplex(self.duplex.isChecked())
        self._refresh_grid_info()
        self._autosave_timer.start()
        self._queue_timer.start()
        self._backup_timer.start()
        QTimer.singleShot(3000, self._automatic_backup_tick)
        self._refresh_license_badge()
        QTimer.singleShot(0, self._security_bootstrap)
        QTimer.singleShot(50, self._offer_recovery)

    def _build_ui(self):
        toolbar = QToolBar("主工具栏")
        toolbar.setMovable(False)
        self.addToolBar(toolbar)

        for title, handler in [
            ("工作台", self.show_workspace),
            ("新建项目", self.new_project),
            ("打开项目", self.open_project),
            ("保存项目", self.save_project),
            ("添加文件", self.add_files),
            ("导入订单表", self.import_order_sheet),
            ("编辑版位", self.edit_layout),
            ("生成预览", self.generate_preview),
            ("正反叠加", self.show_duplex_overlay),
            ("导出生产 PDF", self.export_pdf),
            ("加入生产队列", self.enqueue_current),
            ("生产队列", self.show_queue),
            ("导出版面清单", self.export_layout_manifest),
            ("印前检查", self.run_preflight),
            ("Hot Folder", self.toggle_hotfolder_from_toolbar),
            ("生产控制台", self.show_production_console),
            ("车间 MES", self.show_mes_console),
            ("智能工厂", self.show_smart_factory_console),
            ("商业运营", self.show_commercial_console),
            ("设备中心", self.show_device_center),
            ("许可证", self.show_license),
        ]:
            action = QAction(title, self)
            action.triggered.connect(handler)
            toolbar.addAction(action)

        file_menu = self.menuBar().addMenu("文件")
        for title, handler in [("新建项目", self.new_project), ("打开项目…", self.open_project), ("保存项目", self.save_project)]:
            act = QAction(title, self); act.triggered.connect(handler); file_menu.addAction(act)
        production_menu = self.menuBar().addMenu("生产")
        for title, handler in [("导出生产 PDF…", self.export_pdf), ("加入生产队列…", self.enqueue_current), ("生产队列…", self.show_queue)]:
            act = QAction(title, self); act.triggered.connect(handler); production_menu.addAction(act)
        device_menu = self.menuBar().addMenu("设备")
        act = QAction("生产控制台…", self); act.triggered.connect(self.show_production_console); device_menu.addAction(act)
        act = QAction("车间 MES 控制台…", self); act.triggered.connect(self.show_mes_console); device_menu.addAction(act)
        act = QAction("智能工厂控制台…", self); act.triggered.connect(self.show_smart_factory_console); device_menu.addAction(act)
        act = QAction("商业运营控制台…", self); act.triggered.connect(self.show_commercial_console); device_menu.addAction(act)
        act = QAction("设备配置中心…", self); act.triggered.connect(self.show_device_center); device_menu.addAction(act)
        system_menu = self.menuBar().addMenu("系统")
        for title, handler in [("工作台…", self.show_workspace), ("用户与权限…", self.show_users), ("创建备份…", self.create_backup_ui), ("恢复备份…", self.restore_backup_ui), ("自动备份设置…", self.configure_automatic_backup), ("系统健康检查…", self.show_health_check)]:
            act = QAction(title, self); act.triggered.connect(handler); system_menu.addAction(act)

        help_menu = self.menuBar().addMenu("帮助")
        for title, handler in [("帮助中心…", self.show_help_center), ("许可证…", self.show_license), ("检查更新…", self.check_updates_ui), ("生成支持包", self.create_support_bundle_ui), ("关于", self.about_commercial)]:
            act = QAction(title, self); act.triggered.connect(handler); help_menu.addAction(act)

        root = QWidget()
        self.setCentralWidget(root)
        root_layout = QVBoxLayout(root)
        root_layout.setContentsMargins(14, 14, 14, 14)

        title = QLabel(APP_NAME)
        title.setObjectName("Title")
        subtitle = QLabel("V2.1 商业发布强化版 · 权限/备份/审计/更新/恢复 · 生产全链路")
        subtitle.setStyleSheet("color:#667788;")
        root_layout.addWidget(title)
        root_layout.addWidget(subtitle)

        splitter = QSplitter(Qt.Horizontal)
        splitter.setChildrenCollapsible(False)
        root_layout.addWidget(splitter, 1)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setMinimumWidth(420)
        scroll.setMaximumWidth(500)

        left = QFrame()
        left.setObjectName("Panel")
        left_layout = QVBoxLayout(left)
        left_layout.setContentsMargins(16, 16, 16, 16)
        scroll.setWidget(left)

        left_layout.addWidget(self._section("1. 文件"))
        self.file_table = QTableWidget(0, 6)
        self.file_table.setHorizontalHeaderLabels(["文件", "页数", "数量", "宽 mm", "高 mm", "出血"] )
        self.file_table.setMinimumHeight(135)
        self.file_table.setSelectionBehavior(QTableWidget.SelectRows)
        self.file_table.setSelectionMode(QTableWidget.ExtendedSelection)
        self.file_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.file_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeToContents)
        self.file_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeToContents)
        self.file_table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeToContents)
        self.file_table.horizontalHeader().setSectionResizeMode(4, QHeaderView.ResizeToContents)
        self.file_table.horizontalHeader().setSectionResizeMode(5, QHeaderView.ResizeToContents)
        left_layout.addWidget(self.file_table)

        file_btns = QHBoxLayout()
        self.add_btn = QPushButton("添加印刷文件")
        self.remove_btn = QPushButton("移除")
        self.read_size_btn = QPushButton("读取第一页尺寸")
        file_btns.addWidget(self.add_btn)
        file_btns.addWidget(self.remove_btn)
        file_btns.addWidget(self.read_size_btn)
        left_layout.addLayout(file_btns)

        qty_row = QHBoxLayout()
        qty_row.addWidget(QLabel("新文件默认数量"))
        self.default_quantity = self._ispin(1, 1, 1000000)
        qty_row.addWidget(self.default_quantity)
        qty_row.addStretch()
        left_layout.addLayout(qty_row)

        left_layout.addWidget(self._section("2. 纸张与成品"))
        form = QFormLayout()
        form.setLabelAlignment(Qt.AlignRight)
        self.paper_combo = QComboBox(); self.paper_combo.addItems(PAPER_PRESETS.keys())
        self.sheet_w = self._dspin(450.0, 20, 2000)
        self.sheet_h = self._dspin(320.0, 20, 2000)
        self.trim_w = self._dspin(90.0, 1, 2000)
        self.trim_h = self._dspin(54.0, 1, 2000)
        self.bleed = self._dspin(0.0, 0, 50)
        form.addRow("纸张预设", self.paper_combo)
        form.addRow("纸张宽 mm", self.sheet_w)
        form.addRow("纸张高 mm", self.sheet_h)
        form.addRow("成品宽 mm", self.trim_w)
        form.addRow("成品高 mm", self.trim_h)
        form.addRow("出血 mm", self.bleed)
        left_layout.addLayout(form)

        tabs = QTabWidget()
        left_layout.addWidget(tabs)

        # Basic tab
        basic = QWidget(); basic_form = QFormLayout(basic); basic_form.setLabelAlignment(Qt.AlignRight)
        self.margin_x = self._dspin(10.0, 0, 200)
        self.margin_y = self._dspin(10.0, 0, 200)
        self.gap_x = self._dspin(4.0, 0, 200)
        self.gap_y = self._dspin(4.0, 0, 200)
        self.smart_mixed_sizes = QCheckBox("启用异尺寸智能混拼（每款独立尺寸）")
        self.auto_grid = QCheckBox("自动计算最大行列"); self.auto_grid.setChecked(True)
        self.cols = self._ispin(1, 1, 100)
        self.rows = self._ispin(1, 1, 100)
        self.rotation = QComboBox(); self.rotation.addItems(["0°", "90°", "180°", "270°"])
        self.auto_rotate = QCheckBox("允许 90° 旋转，提高纸张利用率")
        self.center_grid = QCheckBox("整版居中"); self.center_grid.setChecked(True)
        basic_form.addRow("", self.smart_mixed_sizes)
        basic_form.addRow("", self.auto_grid)
        basic_form.addRow("列数", self.cols)
        basic_form.addRow("行数", self.rows)
        basic_form.addRow("横向边距 mm", self.margin_x)
        basic_form.addRow("纵向边距 mm", self.margin_y)
        basic_form.addRow("横向间距 mm", self.gap_x)
        basic_form.addRow("纵向间距 mm", self.gap_y)
        basic_form.addRow("旋转", self.rotation)
        basic_form.addRow("", self.auto_rotate)
        basic_form.addRow("", self.center_grid)
        tabs.addTab(basic, "基础排版")

        # Production tab
        production = QWidget(); prod_form = QFormLayout(production); prod_form.setLabelAlignment(Qt.AlignRight)
        self.source_box = QComboBox(); self.source_box.addItems(SOURCE_BOX_LABELS.keys())
        self.scale_mode = QComboBox(); self.scale_mode.addItems(SCALE_MODE_LABELS.keys())
        self.actual_tolerance = self._dspin(0.5, 0.01, 10)
        self.crop_marks = QCheckBox("添加裁切线"); self.crop_marks.setChecked(True)
        self.mark_len = self._dspin(4.0, 0, 50)
        self.mark_offset = self._dspin(2.0, 0, 50)
        self.registration_marks = QCheckBox("添加四角套准标")
        self.center_marks = QCheckBox("添加纸张中心标")
        self.preflight_fonts = QCheckBox("印前检查字体嵌入"); self.preflight_fonts.setChecked(True)
        self.preflight_colors = QCheckBox("印前检查 RGB / CMYK / 专色"); self.preflight_colors.setChecked(True)
        self.preflight_images = QCheckBox("印前检查图片有效 DPI"); self.preflight_images.setChecked(True)
        self.preflight_pdfx = QCheckBox("识别 PDF/X / OutputIntent"); self.preflight_pdfx.setChecked(True)
        self.require_pdfx = QCheckBox("生产必须为 PDF/X（未声明则阻止导出）")
        self.preflight_graphics = QCheckBox("检查刀线/白墨/光油/Overprint/透明度"); self.preflight_graphics.setChecked(True)
        self.min_image_dpi = self._ispin(200, 36, 2400)
        prod_form.addRow("读取页面框", self.source_box)
        prod_form.addRow("缩放模式", self.scale_mode)
        prod_form.addRow("1:1 允许误差 mm", self.actual_tolerance)
        prod_form.addRow("", self.crop_marks)
        prod_form.addRow("裁切线长度 mm", self.mark_len)
        prod_form.addRow("裁切线偏移 mm", self.mark_offset)
        prod_form.addRow("", self.registration_marks)
        prod_form.addRow("", self.center_marks)
        prod_form.addRow("", self.preflight_fonts)
        prod_form.addRow("", self.preflight_colors)
        prod_form.addRow("", self.preflight_images)
        prod_form.addRow("", self.preflight_pdfx)
        prod_form.addRow("", self.require_pdfx)
        prod_form.addRow("", self.preflight_graphics)
        prod_form.addRow("最低图片 DPI", self.min_image_dpi)
        tabs.addTab(production, "生产/印前")

        # Work order tab
        work_tab = QWidget(); work_form = QFormLayout(work_tab); work_form.setLabelAlignment(Qt.AlignRight)
        self.order_no = QLineEdit(); self.order_no.setPlaceholderText("例如 SO-2026-001")
        self.customer_name = QLineEdit(); self.customer_name.setPlaceholderText("客户名 / 工单简称")
        self.sheet_info = QCheckBox("在每张版底部打印工单/版次/利用率/流水号")
        self.barcode_enabled = QCheckBox("按订单号生成 Code128 条码")
        self.qr_enabled = QCheckBox("生成含订单/版次/流水号的版级二维码")
        self.item_qr_enabled = QCheckBox("逐件生成可变二维码（覆盖成品右下角）")
        self.item_serial_enabled = QCheckBox("逐件打印流水号（覆盖成品左下角）")
        self.item_code_size = self._dspin(8.0, 3.0, 30.0)
        self.serial_prefix = QLineEdit(); self.serial_prefix.setPlaceholderText("例如 P-")
        self.serial_start = self._ispin(1, 0, 99999999)
        self.variable_data = QLineEdit(); self.variable_data.setPlaceholderText("CSV / XLSX，每行对应最终一个成品")
        self.variable_data_btn = QPushButton("选择…")
        variable_row = QWidget(); variable_layout = QHBoxLayout(variable_row); variable_layout.setContentsMargins(0,0,0,0); variable_layout.addWidget(self.variable_data); variable_layout.addWidget(self.variable_data_btn)
        self.item_qr_template = QLineEdit(); self.item_qr_template.setPlaceholderText("例如 {sku}|{name}|{serial}")
        self.item_text_template = QLineEdit(); self.item_text_template.setPlaceholderText("例如 {name} {serial}")
        self.variable_data_strict = QCheckBox("变量数据不足时阻止生产"); self.variable_data_strict.setChecked(True)
        work_form.addRow("订单号", self.order_no)
        work_form.addRow("客户", self.customer_name)
        work_form.addRow("流水号前缀", self.serial_prefix)
        work_form.addRow("流水起始", self.serial_start)
        work_form.addRow("", self.sheet_info)
        work_form.addRow("", self.barcode_enabled)
        work_form.addRow("", self.qr_enabled)
        work_form.addRow("", self.item_qr_enabled)
        work_form.addRow("", self.item_serial_enabled)
        work_form.addRow("逐件码尺寸 mm", self.item_code_size)
        work_form.addRow("变量数据", variable_row)
        work_form.addRow("二维码模板", self.item_qr_template)
        work_form.addRow("可变文字模板", self.item_text_template)
        work_form.addRow("", self.variable_data_strict)
        tabs.addTab(work_tab, "工单/可变码")

        # Duplex tab
        duplex_tab = QWidget(); duplex_form = QFormLayout(duplex_tab); duplex_form.setLabelAlignment(Qt.AlignRight)
        self.duplex = QCheckBox("启用双面拼版（每 2 页=正面+反面）")
        self.duplex_flip = QComboBox(); self.duplex_flip.addItems(["翻长边", "翻短边"])
        duplex_note = QLabel("适合 2 页名片/吊牌/卡片 PDF。输出页顺序为：第1版正面、第1版反面、第2版正面、第2版反面……")
        duplex_note.setWordWrap(True); duplex_note.setStyleSheet("color:#667788;")
        duplex_form.addRow("", self.duplex)
        duplex_form.addRow("翻转方式", self.duplex_flip)
        duplex_form.addRow("", duplex_note)
        tabs.addTab(duplex_tab, "双面套版")

        # Automation / Hot Folder tab
        auto_tab = QWidget(); auto_form = QFormLayout(auto_tab); auto_form.setLabelAlignment(Qt.AlignRight)
        self.hot_input = QLineEdit(); self.hot_input.setPlaceholderText("监听输入文件夹")
        self.hot_output = QLineEdit(); self.hot_output.setPlaceholderText("自动输出拼版 PDF 的文件夹")
        self.hot_archive = QLineEdit(); self.hot_archive.setPlaceholderText("成功原稿归档目录（留空=输出目录/_archive）")
        self.hot_failed = QLineEdit(); self.hot_failed.setPlaceholderText("失败原稿隔离目录（留空=输出目录/_failed）")
        self.hot_log = QLineEdit(); self.hot_log.setPlaceholderText("任务 JSONL 日志（留空=输出目录/hotfolder-tasks.jsonl）")
        self.hot_input_btn = QPushButton("选择…")
        self.hot_output_btn = QPushButton("选择…")
        self.hot_archive_btn = QPushButton("选择…")
        self.hot_failed_btn = QPushButton("选择…")
        self.hot_log_btn = QPushButton("选择…")
        in_row = QWidget(); in_layout = QHBoxLayout(in_row); in_layout.setContentsMargins(0,0,0,0); in_layout.addWidget(self.hot_input); in_layout.addWidget(self.hot_input_btn)
        out_row = QWidget(); out_layout = QHBoxLayout(out_row); out_layout.setContentsMargins(0,0,0,0); out_layout.addWidget(self.hot_output); out_layout.addWidget(self.hot_output_btn)
        archive_row = QWidget(); archive_layout = QHBoxLayout(archive_row); archive_layout.setContentsMargins(0,0,0,0); archive_layout.addWidget(self.hot_archive); archive_layout.addWidget(self.hot_archive_btn)
        failed_row = QWidget(); failed_layout = QHBoxLayout(failed_row); failed_layout.setContentsMargins(0,0,0,0); failed_layout.addWidget(self.hot_failed); failed_layout.addWidget(self.hot_failed_btn)
        log_row = QWidget(); log_layout = QHBoxLayout(log_row); log_layout.setContentsMargins(0,0,0,0); log_layout.addWidget(self.hot_log); log_layout.addWidget(self.hot_log_btn)
        self.hot_settle = self._ispin(5, 1, 120)
        self.hot_move_success = QCheckBox("成功后移动原稿到归档目录")
        self.hot_move_failure = QCheckBox("失败后移动原稿到隔离目录")
        self.hot_enabled = QCheckBox("启用 Hot Folder 自动拼版")
        self.hot_status = QLabel("未启用"); self.hot_status.setWordWrap(True); self.hot_status.setStyleSheet("color:#667788;")
        auto_note = QLabel("检测稳定文件后先印前检查再拼版。可选成功归档/失败隔离；JSONL 日志按任务持续追加，可用于无人值守追溯。")
        auto_note.setWordWrap(True); auto_note.setStyleSheet("color:#667788;")
        auto_form.addRow("输入目录", in_row)
        auto_form.addRow("输出目录", out_row)
        auto_form.addRow("成功归档", archive_row)
        auto_form.addRow("失败隔离", failed_row)
        auto_form.addRow("任务日志", log_row)
        auto_form.addRow("文件稳定等待 秒", self.hot_settle)
        auto_form.addRow("", self.hot_move_success)
        auto_form.addRow("", self.hot_move_failure)
        auto_form.addRow("", self.hot_enabled)
        auto_form.addRow("状态", self.hot_status)
        auto_form.addRow("", auto_note)
        tabs.addTab(auto_tab, "Hot Folder")

        self.grid_info = QLabel(); self.grid_info.setWordWrap(True)
        self.grid_info.setStyleSheet("background:#f6f9fc;border:1px solid #dfe8f1;border-radius:7px;padding:9px;color:#35506b;")
        left_layout.addWidget(self.grid_info)

        template_row = QHBoxLayout()
        self.save_template_btn = QPushButton("保存参数模板")
        self.load_template_btn = QPushButton("加载模板")
        template_row.addWidget(self.save_template_btn); template_row.addWidget(self.load_template_btn)
        left_layout.addLayout(template_row)

        layout_row = QHBoxLayout()
        self.import_orders_btn = QPushButton("导入 CSV / Excel")
        self.edit_layout_btn = QPushButton("可视化编辑版位")
        self.export_manifest_btn = QPushButton("版面清单")
        layout_row.addWidget(self.import_orders_btn); layout_row.addWidget(self.edit_layout_btn); layout_row.addWidget(self.export_manifest_btn)
        left_layout.addLayout(layout_row)

        action_row = QHBoxLayout()
        self.preflight_btn = QPushButton("印前检查")
        self.preview_btn = QPushButton("生成预览")
        self.overlay_btn = QPushButton("正反叠加")
        self.export_btn = QPushButton("导出生产 PDF"); self.export_btn.setObjectName("Primary")
        action_row.addWidget(self.preflight_btn); action_row.addWidget(self.preview_btn); action_row.addWidget(self.overlay_btn); action_row.addWidget(self.export_btn)
        left_layout.addLayout(action_row)
        left_layout.addStretch(1)
        splitter.addWidget(scroll)

        right = QFrame(); right.setObjectName("Panel")
        right_layout = QVBoxLayout(right); right_layout.setContentsMargins(14, 14, 14, 14)
        preview_header = QHBoxLayout()
        preview_title = QLabel("拼版预览"); preview_title.setObjectName("Section")
        preview_header.addWidget(preview_title); preview_header.addStretch()
        self.preview_status = QLabel("尚未生成"); self.preview_status.setStyleSheet("color:#667788;")
        preview_header.addWidget(self.preview_status)
        right_layout.addLayout(preview_header)
        self.pdf_view = QPdfView(); self.pdf_view.setDocument(self._pdf_doc)
        self.pdf_view.setPageMode(QPdfView.PageMode.MultiPage)
        self.pdf_view.setZoomMode(QPdfView.ZoomMode.FitToWidth)
        right_layout.addWidget(self.pdf_view, 1)
        splitter.addWidget(right)
        splitter.setStretchFactor(0, 0); splitter.setStretchFactor(1, 1); splitter.setSizes([450, 1000])

        self.setStatusBar(QStatusBar()); self.statusBar().showMessage("就绪")
        self.license_badge = QLabel("")
        self.license_badge.setStyleSheet("color:#536273;padding:0 8px;")
        self.statusBar().addPermanentWidget(self.license_badge)

    @staticmethod
    def _section(text: str) -> QLabel:
        label = QLabel(text); label.setObjectName("Section"); return label

    @staticmethod
    def _dspin(value: float, minimum: float, maximum: float) -> QDoubleSpinBox:
        spin = QDoubleSpinBox(); spin.setRange(minimum, maximum); spin.setDecimals(2); spin.setSingleStep(1.0); spin.setValue(value); return spin

    @staticmethod
    def _ispin(value: int, minimum: int, maximum: int) -> QSpinBox:
        spin = QSpinBox(); spin.setRange(minimum, maximum); spin.setValue(value); return spin

    def _connect_signals(self):
        self.add_btn.clicked.connect(self.add_files)
        self.remove_btn.clicked.connect(self.remove_selected)
        self.read_size_btn.clicked.connect(self.read_first_page_size)
        self.import_orders_btn.clicked.connect(self.import_order_sheet)
        self.edit_layout_btn.clicked.connect(self.edit_layout)
        self.export_manifest_btn.clicked.connect(self.export_layout_manifest)
        self.overlay_btn.clicked.connect(self.show_duplex_overlay)
        self.preflight_btn.clicked.connect(self.run_preflight)
        self.preview_btn.clicked.connect(self.generate_preview)
        self.export_btn.clicked.connect(self.export_pdf)
        self.save_template_btn.clicked.connect(self.save_template)
        self.load_template_btn.clicked.connect(self.load_template)
        self.variable_data_btn.clicked.connect(self.choose_variable_data)
        self.hot_input_btn.clicked.connect(self.choose_hot_input)
        self.hot_output_btn.clicked.connect(self.choose_hot_output)
        self.hot_archive_btn.clicked.connect(self.choose_hot_archive)
        self.hot_failed_btn.clicked.connect(self.choose_hot_failed)
        self.hot_log_btn.clicked.connect(self.choose_hot_log)
        self.hot_enabled.toggled.connect(self._toggle_hotfolder)
        self._hot_timer.timeout.connect(self._poll_hotfolder)
        self.paper_combo.currentTextChanged.connect(self._apply_preset)
        self.auto_grid.toggled.connect(self._toggle_grid_mode)
        self.smart_mixed_sizes.toggled.connect(self._toggle_smart_mixed)
        self.crop_marks.toggled.connect(self._toggle_mark_controls)
        self.duplex.toggled.connect(self._toggle_duplex)

        for widget in [
            self.sheet_w, self.sheet_h, self.trim_w, self.trim_h, self.bleed,
            self.margin_x, self.margin_y, self.gap_x, self.gap_y, self.cols,
            self.rows, self.mark_len, self.mark_offset, self.actual_tolerance,
        ]:
            widget.valueChanged.connect(self._refresh_grid_info)
        for widget in [self.rotation, self.source_box, self.scale_mode, self.duplex_flip]:
            widget.currentIndexChanged.connect(self._refresh_grid_info)
        for widget in [self.center_grid, self.auto_grid, self.auto_rotate, self.duplex, self.smart_mixed_sizes]:
            widget.toggled.connect(self._refresh_grid_info)

        # Any geometry change invalidates a previously hand-edited layout.
        for widget in [self.sheet_w, self.sheet_h, self.margin_x, self.margin_y, self.gap_x, self.gap_y]:
            widget.valueChanged.connect(self._invalidate_layout)
        for widget in [self.rotation, self.duplex_flip]:
            widget.currentIndexChanged.connect(self._invalidate_layout)
        for widget in [self.auto_rotate, self.duplex, self.smart_mixed_sizes]:
            widget.toggled.connect(self._invalidate_layout)

    def _apply_preset(self):
        preset = PAPER_PRESETS[self.paper_combo.currentText()]
        if preset:
            self.sheet_w.setValue(preset[0]); self.sheet_h.setValue(preset[1])
            self.sheet_w.setEnabled(False); self.sheet_h.setEnabled(False)
        else:
            self.sheet_w.setEnabled(True); self.sheet_h.setEnabled(True)
        self._refresh_grid_info()

    def _toggle_grid_mode(self, checked: bool):
        smart = self.smart_mixed_sizes.isChecked()
        self.cols.setEnabled((not checked) and (not smart)); self.rows.setEnabled((not checked) and (not smart))
        self.auto_rotate.setEnabled(checked or smart)

    def _toggle_smart_mixed(self, checked: bool):
        self.auto_grid.setEnabled(not checked)
        self.cols.setEnabled((not checked) and (not self.auto_grid.isChecked()))
        self.rows.setEnabled((not checked) and (not self.auto_grid.isChecked()))
        self.center_grid.setEnabled(not checked)
        self.auto_rotate.setEnabled(True)
        self._refresh_grid_info()

    def _toggle_mark_controls(self, checked: bool):
        self.mark_len.setEnabled(checked); self.mark_offset.setEnabled(checked)

    def _toggle_duplex(self, checked: bool):
        self.duplex_flip.setEnabled(checked)

    def _settings(self) -> ImpositionSettings:
        return ImpositionSettings(
            sheet_width_mm=self.sheet_w.value(), sheet_height_mm=self.sheet_h.value(),
            trim_width_mm=self.trim_w.value(), trim_height_mm=self.trim_h.value(), bleed_mm=self.bleed.value(),
            margin_x_mm=self.margin_x.value(), margin_y_mm=self.margin_y.value(), gap_x_mm=self.gap_x.value(), gap_y_mm=self.gap_y.value(),
            rows=self.rows.value(), cols=self.cols.value(), auto_grid=self.auto_grid.isChecked(), copies_per_page=1,
            rotation=int(self.rotation.currentText().replace("°", "")), auto_rotate=self.auto_rotate.isChecked(), center_grid=self.center_grid.isChecked(),
            smart_mixed_sizes=self.smart_mixed_sizes.isChecked(),
            source_box=SOURCE_BOX_LABELS[self.source_box.currentText()], scale_mode=SCALE_MODE_LABELS[self.scale_mode.currentText()],
            actual_size_tolerance_mm=self.actual_tolerance.value(), crop_marks=self.crop_marks.isChecked(),
            crop_mark_length_mm=self.mark_len.value(), crop_mark_offset_mm=self.mark_offset.value(),
            registration_marks=self.registration_marks.isChecked(), center_marks=self.center_marks.isChecked(),
            duplex=self.duplex.isChecked(), duplex_flip="long" if self.duplex_flip.currentText() == "翻长边" else "short",
            order_no=self.order_no.text().strip(), customer_name=self.customer_name.text().strip(),
            sheet_info=self.sheet_info.isChecked(), barcode_enabled=self.barcode_enabled.isChecked(),
            qr_enabled=self.qr_enabled.isChecked(), serial_prefix=self.serial_prefix.text().strip(), serial_start=self.serial_start.value(),
            item_qr_enabled=self.item_qr_enabled.isChecked(), item_serial_enabled=self.item_serial_enabled.isChecked(), item_code_size_mm=self.item_code_size.value(),
            preflight_fonts=self.preflight_fonts.isChecked(), preflight_colors=self.preflight_colors.isChecked(),
            preflight_images=self.preflight_images.isChecked(), preflight_pdfx=self.preflight_pdfx.isChecked(),
            require_pdfx=self.require_pdfx.isChecked(), preflight_graphics=self.preflight_graphics.isChecked(), min_image_dpi=self.min_image_dpi.value(),
            variable_data_path=self.variable_data.text().strip(), item_qr_template=self.item_qr_template.text(),
            item_text_template=self.item_text_template.text(), variable_data_strict=self.variable_data_strict.isChecked(),
        )

    def _apply_settings_dict(self, data: dict):
        def set_if(name, widget, setter="setValue"):
            if name in data: getattr(widget, setter)(data[name])

        set_if("sheet_width_mm", self.sheet_w); set_if("sheet_height_mm", self.sheet_h)
        set_if("trim_width_mm", self.trim_w); set_if("trim_height_mm", self.trim_h); set_if("bleed_mm", self.bleed)
        set_if("margin_x_mm", self.margin_x); set_if("margin_y_mm", self.margin_y); set_if("gap_x_mm", self.gap_x); set_if("gap_y_mm", self.gap_y)
        set_if("rows", self.rows); set_if("cols", self.cols)
        set_if("auto_grid", self.auto_grid, "setChecked"); set_if("auto_rotate", self.auto_rotate, "setChecked"); set_if("center_grid", self.center_grid, "setChecked")
        set_if("smart_mixed_sizes", self.smart_mixed_sizes, "setChecked")
        set_if("actual_size_tolerance_mm", self.actual_tolerance)
        set_if("crop_marks", self.crop_marks, "setChecked"); set_if("registration_marks", self.registration_marks, "setChecked"); set_if("center_marks", self.center_marks, "setChecked")
        set_if("duplex", self.duplex, "setChecked")
        set_if("sheet_info", self.sheet_info, "setChecked"); set_if("barcode_enabled", self.barcode_enabled, "setChecked")
        set_if("qr_enabled", self.qr_enabled, "setChecked"); set_if("serial_start", self.serial_start)
        set_if("item_qr_enabled", self.item_qr_enabled, "setChecked"); set_if("item_serial_enabled", self.item_serial_enabled, "setChecked")
        set_if("item_code_size_mm", self.item_code_size)
        set_if("preflight_fonts", self.preflight_fonts, "setChecked"); set_if("preflight_colors", self.preflight_colors, "setChecked"); set_if("preflight_images", self.preflight_images, "setChecked")
        set_if("preflight_pdfx", self.preflight_pdfx, "setChecked"); set_if("require_pdfx", self.require_pdfx, "setChecked"); set_if("preflight_graphics", self.preflight_graphics, "setChecked")
        set_if("min_image_dpi", self.min_image_dpi)
        set_if("variable_data_strict", self.variable_data_strict, "setChecked")
        if "variable_data_path" in data: self.variable_data.setText(str(data.get("variable_data_path", "")))
        if "item_qr_template" in data: self.item_qr_template.setText(str(data.get("item_qr_template", "")))
        if "item_text_template" in data: self.item_text_template.setText(str(data.get("item_text_template", "")))
        if "order_no" in data: self.order_no.setText(str(data.get("order_no", "")))
        if "customer_name" in data: self.customer_name.setText(str(data.get("customer_name", "")))
        if "serial_prefix" in data: self.serial_prefix.setText(str(data.get("serial_prefix", "")))

        rotation = str(data.get("rotation", 0)) + "°"
        idx = self.rotation.findText(rotation)
        if idx >= 0: self.rotation.setCurrentIndex(idx)
        reverse_source = {v:k for k,v in SOURCE_BOX_LABELS.items()}
        if data.get("source_box") in reverse_source: self.source_box.setCurrentText(reverse_source[data["source_box"]])
        reverse_scale = {v:k for k,v in SCALE_MODE_LABELS.items()}
        if data.get("scale_mode") in reverse_scale: self.scale_mode.setCurrentText(reverse_scale[data["scale_mode"]])
        self.duplex_flip.setCurrentText("翻长边" if data.get("duplex_flip", "long") == "long" else "翻短边")
        set_if("crop_mark_length_mm", self.mark_len); set_if("crop_mark_offset_mm", self.mark_offset)

        self.paper_combo.setCurrentText("自定义")
        self._refresh_grid_info()

    def _page_counts(self) -> list[int]:
        counts = []
        for row in range(self.file_table.rowCount()):
            item = self.file_table.item(row, 1)
            try:
                counts.append(int(item.text()))
            except Exception:
                path_item = self.file_table.item(row, 0)
                if not path_item:
                    counts.append(0)
                    continue
                info = inspect_source(path_item.data(Qt.UserRole), SOURCE_BOX_LABELS[self.source_box.currentText()])
                counts.append(int(info["pages"]))
        return counts

    def _refresh_grid_info(self, *_):
        try:
            settings = self._settings()
            duplex_text = "双面" if settings.duplex else "单面"
            scale_text = "1:1" if settings.scale_mode == "actual" else "适配"
            if settings.smart_mixed_sizes:
                jobs = self.input_jobs()
                if not jobs:
                    self.grid_info.setText(
                        f"异尺寸智能混拼已启用；{duplex_text}；{scale_text}。\n"
                        "添加文件后，软件会按每款独立宽高/出血自动装箱并计算利用率。"
                    )
                else:
                    estimate = estimate_smart_layout(jobs, settings, self._page_counts())
                    self.grid_info.setText(
                        f"异尺寸智能混拼：{estimate['total_items']} 件 → 预计 {estimate['sheet_count']} 张纸；"
                        f"平均有效面积利用率 {estimate['utilization_percent']:.1f}%；{duplex_text}；{scale_text}。\n"
                        f"单张最多放 {estimate['max_items_on_sheet']} 件；允许旋转：{'是' if settings.auto_rotate else '否'}。"
                    )
            else:
                grid = calculate_grid(settings)
                if self.auto_grid.isChecked():
                    self.cols.blockSignals(True); self.rows.blockSignals(True)
                    self.cols.setValue(grid.cols); self.rows.setValue(grid.rows)
                    self.cols.blockSignals(False); self.rows.blockSignals(False)
                self.grid_info.setText(
                    f"当前：{grid.rows} 行 × {grid.cols} 列 = {grid.capacity} 模/张；"
                    f"有效旋转 {grid.effective_rotation}°；{duplex_text}；{scale_text}。\n"
                    f"含出血占位：{grid.footprint_width_mm:.1f} × {grid.footprint_height_mm:.1f} mm；"
                    f"整版占用：{grid.used_width_mm:.1f} × {grid.used_height_mm:.1f} mm"
                )
            self.grid_info.setStyleSheet("background:#f6f9fc;border:1px solid #dfe8f1;border-radius:7px;padding:9px;color:#35506b;")
        except Exception as exc:
            self.grid_info.setText(f"参数不可用：{exc}")
            self.grid_info.setStyleSheet("background:#fff5f5;border:1px solid #f0caca;border-radius:7px;padding:9px;color:#a33;")

    def input_jobs(self) -> list[InputJob]:
        jobs = []
        for row in range(self.file_table.rowCount()):
            item = self.file_table.item(row, 0)
            qty_widget = self.file_table.cellWidget(row, 2)
            w_widget = self.file_table.cellWidget(row, 3)
            h_widget = self.file_table.cellWidget(row, 4)
            bleed_widget = self.file_table.cellWidget(row, 5)
            if item and qty_widget:
                jobs.append(InputJob(
                    path=item.data(Qt.UserRole),
                    quantity=qty_widget.value(),
                    trim_width_mm=w_widget.value() if w_widget else self.trim_w.value(),
                    trim_height_mm=h_widget.value() if h_widget else self.trim_h.value(),
                    bleed_mm=bleed_widget.value() if bleed_widget else self.bleed.value(),
                    name=str(item.data(Qt.UserRole + 1) or Path(item.data(Qt.UserRole)).stem),
                ))
        return jobs

    def input_paths(self) -> list[str]:
        return [str(job.path) for job in self.input_jobs()]

    def add_files(self):
        paths, _ = QFileDialog.getOpenFileNames(self, "添加印刷文件", "", "支持文件 (*.pdf *.ai *.eps *.ps *.png *.jpg *.jpeg *.tif *.tiff *.webp *.bmp);;PDF/AI/EPS (*.pdf *.ai *.eps *.ps);;图片 (*.png *.jpg *.jpeg *.tif *.tiff *.webp *.bmp)")
        for path in paths:
            self._append_job_row(path, self.default_quantity.value())
        if paths:
            self._invalidate_layout()
            self.statusBar().showMessage(f"已添加 {len(paths)} 个文件；异尺寸模式下可直接编辑每款宽、高、出血和数量")
            self._refresh_grid_info()

    def _invalidate_layout(self, *_):
        if self._layout_override is not None:
            self._layout_override = None
            self.statusBar().showMessage("排版参数已变化，手工版位已自动失效，请重新编辑", 5000)

    def _append_job_row(self, path: str, quantity: int = 1, width_mm: float | None = None, height_mm: float | None = None, bleed_mm: float | None = None, name: str | None = None):
        pages = "?"
        source_w = width_mm if width_mm is not None else self.trim_w.value()
        source_h = height_mm if height_mm is not None else self.trim_h.value()
        try:
            info = inspect_source(path, SOURCE_BOX_LABELS[self.source_box.currentText()])
            pages = info["pages"]
            if width_mm is None: source_w = info["width_mm"]
            if height_mm is None: source_h = info["height_mm"]
        except Exception:
            pass
        row = self.file_table.rowCount()
        self.file_table.insertRow(row)
        file_item = QTableWidgetItem(Path(path).name)
        file_item.setData(Qt.UserRole, path)
        file_item.setData(Qt.UserRole + 1, name or Path(path).stem)
        file_item.setToolTip(path)
        self.file_table.setItem(row, 0, file_item)
        pages_item = QTableWidgetItem(str(pages)); pages_item.setTextAlignment(Qt.AlignCenter)
        pages_item.setFlags(pages_item.flags() & ~Qt.ItemIsEditable)
        self.file_table.setItem(row, 1, pages_item)
        qty = self._ispin(max(1, int(quantity)), 1, 1000000)
        w = self._dspin(float(source_w), 1, 2000)
        h = self._dspin(float(source_h), 1, 2000)
        bleed = self._dspin(float(self.bleed.value() if bleed_mm is None else bleed_mm), 0, 50)
        self.file_table.setCellWidget(row, 2, qty); self.file_table.setCellWidget(row, 3, w)
        self.file_table.setCellWidget(row, 4, h); self.file_table.setCellWidget(row, 5, bleed)
        for widget in (qty, w, h, bleed):
            widget.valueChanged.connect(self._refresh_grid_info)
            widget.valueChanged.connect(self._invalidate_layout)

    def import_order_sheet(self):
        path, _ = QFileDialog.getOpenFileName(self, "导入订单表", "", "订单表 (*.csv *.xlsx);;CSV (*.csv);;Excel (*.xlsx)")
        if not path:
            return
        try:
            rows = []
            suffix = Path(path).suffix.lower()
            if suffix == ".csv":
                with open(path, "r", encoding="utf-8-sig", newline="") as f:
                    rows = list(csv.DictReader(f))
            elif suffix == ".xlsx":
                try:
                    from openpyxl import load_workbook
                except Exception as exc:
                    raise RuntimeError("导入 Excel 需要 openpyxl，请先重新安装 requirements.txt") from exc
                wb = load_workbook(path, read_only=True, data_only=True)
                ws = wb.active
                values = list(ws.iter_rows(values_only=True))
                if not values:
                    raise ValueError("Excel 没有数据")
                headers = [str(x or "").strip() for x in values[0]]
                rows = [dict(zip(headers, row)) for row in values[1:] if any(v is not None for v in row)]
            else:
                raise ValueError("仅支持 CSV / XLSX")

            def pick(row, *names, default=None):
                for name in names:
                    if name in row and row[name] not in (None, ""):
                        return row[name]
                return default

            base = Path(path).parent
            imported = 0
            missing = []
            for row in rows:
                raw = pick(row, "file", "path", "文件", "文件路径", "PDF")
                if not raw:
                    continue
                file_path = Path(str(raw).strip())
                if not file_path.is_absolute():
                    file_path = base / file_path
                if not file_path.exists():
                    missing.append(str(file_path))
                    continue
                qty = int(float(pick(row, "quantity", "qty", "数量", default=1)))
                w = pick(row, "width_mm", "width", "宽", "成品宽", default=None)
                h = pick(row, "height_mm", "height", "高", "成品高", default=None)
                bleed = pick(row, "bleed_mm", "bleed", "出血", default=self.bleed.value())
                name = str(pick(row, "name", "款名", "名称", default=file_path.stem))
                self._append_job_row(str(file_path), qty, float(w) if w not in (None, "") else None, float(h) if h not in (None, "") else None, float(bleed), name)
                imported += 1
            self._invalidate_layout()
            self._refresh_grid_info()
            msg = f"已导入 {imported} 款"
            if missing:
                msg += f"；{len(missing)} 个文件未找到"
            QMessageBox.information(self, "订单导入完成", msg)
        except Exception as exc:
            QMessageBox.critical(self, "导入订单失败", str(exc))

    def edit_layout(self):
        try:
            settings = self._settings()
            if not settings.smart_mixed_sizes:
                raise ValueError("请先启用“异尺寸智能混拼”")
            jobs = self.input_jobs()
            if not jobs:
                raise ValueError("请先添加文件")
            layout = self._layout_override or plan_smart_layout(jobs, settings, self._page_counts())
            names = [job.name or Path(job.path).stem for job in jobs]
            dialog = LayoutEditorDialog(layout, settings, names, self)
            if dialog.exec() == QDialog.Accepted:
                self._layout_override = dialog.layout
                self.statusBar().showMessage("手工版位已保存，将用于预览和生产 PDF", 6000)
                self._refresh_grid_info()
        except Exception as exc:
            QMessageBox.critical(self, "编辑版位失败", str(exc))

    def save_manual_layout(self, path: str):
        payload = {
            "app": "DesktopImposer",
            "version": APP_VERSION,
            "settings": self._settings().to_dict(),
            "layout": self._layout_override,
        }
        Path(path).write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    def export_layout_manifest(self):
        try:
            settings = self._settings()
            if not settings.smart_mixed_sizes:
                raise ValueError("版面清单目前用于异尺寸智能混拼模式")
            jobs = self.input_jobs()
            if not jobs:
                raise ValueError("请先添加文件")
            layout = self._layout_override or plan_smart_layout(jobs, settings, self._page_counts())
            check = validate_manual_layout(layout, settings)
            if check["errors"]:
                raise ValueError("版位无效：" + "；".join(check["errors"][:6]))
            path, _ = QFileDialog.getSaveFileName(self, "导出版面清单", "版面清单.csv", "CSV (*.csv)")
            if not path: return
            if not path.lower().endswith(".csv"): path += ".csv"
            with open(path, "w", encoding="utf-8-sig", newline="") as f:
                writer = csv.writer(f)
                writer.writerow(["sheet", "item", "job_index", "name", "unit_index", "x_mm", "y_mm", "width_mm", "height_mm", "rotation"])
                for sheet_no, sheet in enumerate(layout["sheets"], 1):
                    for item_no, p in enumerate(sheet, 1):
                        j = int(p["job_index"])
                        name = jobs[j].name or Path(jobs[j].path).stem
                        writer.writerow([sheet_no, item_no, j + 1, name, int(p["unit_index"]) + 1, p["x_mm"], p["y_mm"], p["footprint_width_mm"], p["footprint_height_mm"], p["rotation"]])
            self.statusBar().showMessage(f"版面清单已导出：{path}", 6000)
        except Exception as exc:
            QMessageBox.critical(self, "导出版面清单失败", str(exc))

    def show_duplex_overlay(self):
        try:
            if not self.duplex.isChecked():
                raise ValueError("请先启用双面拼版")
            if not self._preview_path or not Path(self._preview_path).exists():
                self.generate_preview()
            if not self._preview_path or not Path(self._preview_path).exists():
                return
            dialog = DuplexOverlayDialog(self._preview_path, self._settings(), self)
            dialog.exec()
        except Exception as exc:
            QMessageBox.critical(self, "正反叠加失败", str(exc))

    def remove_selected(self):
        rows = sorted({index.row() for index in self.file_table.selectedIndexes()}, reverse=True)
        for row in rows:
            self.file_table.removeRow(row)
        self._invalidate_layout()
        self._refresh_grid_info()

    def read_first_page_size(self):
        jobs = self.input_jobs()
        if not jobs:
            QMessageBox.information(self, "读取尺寸", "请先添加文件")
            return
        try:
            box = SOURCE_BOX_LABELS[self.source_box.currentText()]
            info = inspect_source(jobs[0].path, box)
            self.trim_w.setValue(info["width_mm"]); self.trim_h.setValue(info["height_mm"])
            self.bleed.setValue(0.0)
            QMessageBox.information(self, "已读取", f"第一页：{info['width_mm']:.2f} × {info['height_mm']:.2f} mm\n页数：{info['pages']}\n读取框：{box}")
        except Exception as exc:
            QMessageBox.critical(self, "读取失败", str(exc))

    def run_preflight(self):
        jobs = self.input_jobs()
        if not jobs:
            QMessageBox.information(self, "印前检查", "请先添加文件")
            return None
        try:
            report = run_preflight(jobs, self._settings())
            errors = report.get("errors", [])
            warnings = report.get("warnings", [])
            infos = report.get("infos", [])
            if errors:
                title = f"印前检查：发现 {len(errors)} 个错误"
                icon = QMessageBox.Critical
            elif warnings:
                title = f"印前检查：通过，但有 {len(warnings)} 个提醒"
                icon = QMessageBox.Warning
            else:
                title = "印前检查：通过"
                icon = QMessageBox.Information

            box = QMessageBox(self)
            box.setIcon(icon)
            box.setWindowTitle("印前检查")
            box.setText(title)
            brief = []
            brief.extend([f"错误：{x}" for x in errors[:3]])
            brief.extend([f"提醒：{x}" for x in warnings[:3]])
            if not brief:
                brief.append("未发现阻止生产的尺寸、页数或页面框问题。")
            box.setInformativeText("\n".join(brief))
            details = [f"【检查引擎】{report.get('provider','未知')} · " + ("标准认证结果" if report.get('certified') else "风险筛查（非标准认证）")]
            if errors:
                details.append("【错误】\n" + "\n".join(errors))
            if warnings:
                details.append("【提醒】\n" + "\n".join(warnings))
            if infos:
                details.append("【信息】\n" + "\n".join(infos))
            box.setDetailedText("\n\n".join(details))
            box.exec()
            return report
        except Exception as exc:
            QMessageBox.critical(self, "印前检查失败", str(exc))
            return {"errors": [str(exc)], "warnings": [], "infos": []}

    def _run_impose(self, output_path: str):
        jobs = self.input_jobs()
        if not jobs:
            raise ValueError("请先添加至少一个 PDF 或图片文件")
        return impose_jobs(jobs, output_path, self._settings(), layout_override=self._layout_override)

    def generate_preview(self):
        try:
            if self._preview_path:
                try: os.unlink(self._preview_path)
                except Exception: pass
                self._preview_path = None
            fd, path = tempfile.mkstemp(prefix="desktop_imposer_preview_", suffix=".pdf"); os.close(fd)
            summary = self._run_impose(path); self._preview_path = path
            self._pdf_doc.close(); error = self._pdf_doc.load(path)
            if error != QPdfDocument.Error.None_: raise RuntimeError(f"预览 PDF 加载失败：{error}")
            self.pdf_view.setZoomMode(QPdfView.ZoomMode.FitToWidth)
            mode = "双面" if summary["duplex"] else "单面"
            if summary.get("smart_mixed_sizes"):
                manual = " · 手工版位" if summary.get("manual_layout") else ""
                layout = f"异尺寸 · 利用率{summary['utilization_percent']:.1f}%{manual}"
            else:
                layout = f"{summary['rows']}×{summary['cols']}"
            self.preview_status.setText(
                f"{summary['job_count']}款 · {layout} · {summary['sheet_count']}张纸 · "
                f"混拼省{summary['sheets_saved_by_mixing']}张 · {mode}"
            )
            self.statusBar().showMessage("预览已更新", 5000)
        except Exception as exc:
            QMessageBox.critical(self, "生成预览失败", str(exc))

    def export_pdf(self):
        if not self._require_permission("production.export"): return
        try:
            self._require_production_license()
            if not self.input_paths():
                raise ValueError("请先添加至少一个 PDF 或图片文件")

            path, _ = QFileDialog.getSaveFileName(self, "导出生产 PDF", "拼版输出.pdf", "PDF (*.pdf)")
            if not path:
                return
            if not path.lower().endswith(".pdf"):
                path += ".pdf"
            manifest = atomic_production_export(
                self.input_jobs(), path, self._settings(), self._layout_override, db=self.db, write_manifest=True
            )
            summary = manifest["summary"]
            mode = "双面" if summary["duplex"] else "单面"
            if summary.get("smart_mixed_sizes"):
                layout_text = (
                    f"异尺寸智能混拼\n平均利用率：{summary['utilization_percent']:.1f}%\n"
                    f"单张最多：{summary['max_items_on_sheet']} 件"
                )
            else:
                layout_text = f"每张：{summary['rows']} × {summary['cols']} = {summary['capacity_per_sheet']} 模"
            QMessageBox.information(
                self, "生产导出完成",
                f"生产 PDF 已通过写入后校验。\n\n模式：{mode}\n纸张数：{summary['sheet_count']}\n"
                f"PDF 页数：{summary['output_pages']}\n{layout_text}\n"
                f"总拼版件数：{summary['total_items']}\n混拼省纸：{summary['sheets_saved_by_mixing']} 张\n"
                f"SHA-256：{manifest['output_sha256'][:20]}…\n\n{path}\n\n"
                f"生产清单：{manifest.get('manifest_path','')}"
            )
            self.statusBar().showMessage(f"已安全导出：{path}", 8000)
        except Exception as exc:
            self.logger.exception("export failed")
            QMessageBox.critical(self, "导出失败", str(exc))

    def _automation_snapshot(self) -> dict:
        return {
            "hot_input": self.hot_input.text().strip(), "hot_output": self.hot_output.text().strip(),
            "hot_archive": self.hot_archive.text().strip(), "hot_failed": self.hot_failed.text().strip(),
            "hot_log": self.hot_log.text().strip(), "move_success": self.hot_move_success.isChecked(),
            "move_failure": self.hot_move_failure.isChecked(), "settle_seconds": self.hot_settle.value(),
        }

    def _project_snapshot(self) -> dict:
        return build_project_snapshot(
            self.input_jobs(), self._settings(), self._layout_override,
            automation=self._automation_snapshot(),
            ui={"default_quantity": self.default_quantity.value()},
        )

    def _restore_project_snapshot(self, data: dict):
        self.file_table.setRowCount(0)
        self._layout_override = None
        self._apply_settings_dict(data.get("settings") or {})
        for row in data.get("jobs") or []:
            path = str(row.get("path") or "")
            if not path:
                continue
            self._append_job_row(
                path,
                int(row.get("quantity") or 1),
                float(row.get("trim_width_mm") or self.trim_w.value()),
                float(row.get("trim_height_mm") or self.trim_h.value()),
                float(row.get("bleed_mm") or 0),
                str(row.get("name") or Path(path).stem),
            )
        self._layout_override = data.get("layout")
        automation = data.get("automation") or {}
        if automation.get("hot_input"): self.hot_input.setText(str(automation["hot_input"]))
        if automation.get("hot_output"): self.hot_output.setText(str(automation["hot_output"]))
        if automation.get("hot_archive"): self.hot_archive.setText(str(automation["hot_archive"]))
        if automation.get("hot_failed"): self.hot_failed.setText(str(automation["hot_failed"]))
        if automation.get("hot_log"): self.hot_log.setText(str(automation["hot_log"]))
        if "move_success" in automation: self.hot_move_success.setChecked(bool(automation["move_success"]))
        if "move_failure" in automation: self.hot_move_failure.setChecked(bool(automation["move_failure"]))
        if automation.get("settle_seconds"): self.hot_settle.setValue(int(automation["settle_seconds"]))
        ui = data.get("ui") or {}
        if ui.get("default_quantity"): self.default_quantity.setValue(int(ui["default_quantity"]))
        self._refresh_grid_info()

    def new_project(self):
        self.file_table.setRowCount(0)
        self._layout_override = None
        self._current_project_path = None
        self.setWindowTitle(f"{APP_NAME} · V{APP_VERSION}")
        self.statusBar().showMessage("已新建空白项目", 4000)

    def _open_project_path(self, path: str | Path, *, show_errors: bool = True) -> bool:
        try:
            path = str(Path(path).expanduser().resolve())
            data = load_project(path)
            self._restore_project_snapshot(data)
            self._current_project_path = path
            self.db.add_recent_project(path)
            self.db.audit("project.opened", {"path": path})
            self.setWindowTitle(f"{APP_NAME} · {Path(path).name} · V{APP_VERSION}")
            self.statusBar().showMessage(f"项目已打开：{path}", 5000)
            return True
        except Exception as exc:
            if show_errors:
                QMessageBox.critical(self, "打开项目失败", str(exc))
            return False

    def open_project(self):
        path, _ = QFileDialog.getOpenFileName(self, "打开拼版项目", "", "拼版项目 (*.imposeproj)")
        if path:
            self._open_project_path(path)

    def save_project(self):
        try:
            path = self._current_project_path
            if not path:
                path, _ = QFileDialog.getSaveFileName(self, "保存拼版项目", "未命名.imposeproj", "拼版项目 (*.imposeproj)")
                if not path:
                    return
            saved = write_project_file(path, self._project_snapshot())
            self._current_project_path = str(saved)
            self.db.add_recent_project(saved)
            self.db.audit("project.saved", {"path": str(saved)})
            self.setWindowTitle(f"{APP_NAME} · {saved.name} · V{APP_VERSION}")
            self.statusBar().showMessage(f"项目已保存：{saved}", 5000)
        except Exception as exc:
            QMessageBox.critical(self, "保存项目失败", str(exc))

    def _autosave_project(self):
        jobs = self.input_jobs()
        if not jobs:
            return
        path = autosave_dir() / "recovery.imposeproj"
        write_project_file(path, self._project_snapshot())
        self.db.set_setting("last_autosave", str(path))

    def _offer_recovery(self):
        path = autosave_dir() / "recovery.imposeproj"
        if (self._previous_clean_shutdown and not self._runtime_recovery.previous_unclean_shutdown) or not path.exists():
            return
        try:
            data = load_project(path)
        except Exception:
            return
        answer = QMessageBox.question(
            self, "恢复上次工作", "检测到自动恢复项目。是否恢复上次未完成的拼版工作？",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes,
        )
        if answer == QMessageBox.Yes:
            self._restore_project_snapshot(data)
            self.statusBar().showMessage("已从自动恢复文件恢复工作", 6000)
        else:
            try: path.unlink()
            except Exception: pass

    def _refresh_license_badge(self):
        status = self.license_manager.status()
        if status.mode == "licensed":
            text = f"已授权 · {status.edition} · {status.customer or status.license_id}"
        elif status.mode == "trial":
            text = f"试用版 · 剩余 {status.days_remaining} 天"
        else:
            text = "未授权 · 生产输出已停用"
        self.license_badge.setText(text)

    def _require_production_license(self):
        status = self.license_manager.status()
        self._refresh_license_badge()
        if not status.valid:
            raise PermissionError(status.message or "当前许可证不可用于生产输出")
        return status

    def _security_bootstrap(self):
        try:
            if not self._user_store.has_users():
                dlg = FirstAdminDialog(self._user_store, self)
            else:
                dlg = LoginDialog(self._user_store, self)
            if dlg.exec() == QDialog.Accepted and getattr(dlg, "session", None):
                self._session = dlg.session
                self._security_audit.append(self._session.username, "login.success", details={"role": self._session.role})
                self.statusBar().showMessage(f"已登录：{self._session.display_name} / {self._session.role}", 8000)
            else:
                self.statusBar().showMessage("未登录：受保护操作不可用", 8000)
        except Exception as exc:
            QMessageBox.critical(self, "安全初始化失败", str(exc))

    def _require_permission(self, permission: str) -> bool:
        try:
            require(self._session, permission); return True
        except AccessDenied:
            QMessageBox.warning(self, "权限不足", f"当前账户没有权限：{permission}")
            return False

    def show_workspace(self):
        dlg = ProductWorkspaceDialog(self._brand, self._translator, self._session, self)
        routes = {
            "prepress": self.generate_preview, "production": self.show_production_console,
            "mes": self.show_mes_console, "factory": self.show_smart_factory_console,
            "commercial": self.show_commercial_console, "admin": self.show_users,
        }
        dlg.moduleRequested.connect(lambda key: routes.get(key, lambda: None)())
        dlg.exec()

    def show_users(self):
        if not self._require_permission("users.manage"): return
        UserManagementDialog(self._user_store, self).exec()

    def create_backup_ui(self):
        if not self._require_permission("*"): return
        path, _ = QFileDialog.getSaveFileName(self, "创建完整备份", f"DesktopImposer-{APP_VERSION}.dibackup", "Desktop Imposer Backup (*.dibackup)")
        if not path: return
        try:
            info = create_backup(path)
            QMessageBox.information(self, "备份完成", f"已备份 {info['files']} 个文件。\nSHA-256: {info['sha256']}")
        except Exception as exc: QMessageBox.critical(self, "备份失败", str(exc))

    def restore_backup_ui(self):
        if not self._require_permission("*"): return
        path, _ = QFileDialog.getOpenFileName(self, "恢复完整备份", "", "Desktop Imposer Backup (*.dibackup)")
        if not path: return
        try:
            manifest = inspect_backup(path)
            if QMessageBox.question(self, "确认恢复", f"备份版本：{manifest.get('app_version')}\n恢复会覆盖当前本机业务数据。继续？") != QMessageBox.Yes: return
            result = restore_backup(path)
            QMessageBox.information(self, "恢复完成", f"已恢复 {result['restored']} 个文件。请重新启动软件。")
        except Exception as exc: QMessageBox.critical(self, "恢复失败", str(exc))


    def configure_automatic_backup(self):
        if not self._require_permission("*"):
            return
        try:
            current = self._backup_service.load_policy()
            dlg = QDialog(self)
            dlg.setWindowTitle("自动备份设置")
            layout = QVBoxLayout(dlg)
            form = QFormLayout()
            enabled = QCheckBox("启用自动备份"); enabled.setChecked(current.enabled)
            interval = QSpinBox(); interval.setRange(1, 24 * 30); interval.setValue(current.interval_hours); interval.setSuffix(" 小时")
            keep = QSpinBox(); keep.setRange(1, 365); keep.setValue(current.keep_last); keep.setSuffix(" 份")
            logs = QCheckBox("备份包含日志"); logs.setChecked(current.include_logs)
            form.addRow("", enabled); form.addRow("备份间隔", interval); form.addRow("保留最近", keep); form.addRow("", logs)
            layout.addLayout(form)
            buttons = QHBoxLayout(); save_btn = QPushButton("保存"); cancel_btn = QPushButton("取消")
            buttons.addStretch(); buttons.addWidget(cancel_btn); buttons.addWidget(save_btn); layout.addLayout(buttons)
            cancel_btn.clicked.connect(dlg.reject); save_btn.clicked.connect(dlg.accept)
            if dlg.exec() == QDialog.Accepted:
                policy = BackupPolicy(enabled.isChecked(), interval.value(), keep.value(), logs.isChecked())
                self._backup_service.save_policy(policy)
                self._security_audit.append(self._session.username if self._session else "system", "backup.policy_changed", details={"enabled": policy.enabled, "interval_hours": policy.interval_hours, "keep_last": policy.keep_last})
                QMessageBox.information(self, "自动备份", "自动备份策略已保存。")
        except Exception as exc:
            QMessageBox.critical(self, "自动备份设置失败", str(exc))

    def _automatic_backup_tick(self):
        try:
            result = self._backup_service.run_if_due()
            if result.get("created"):
                self.logger.info("automatic backup created path=%s", result.get("path"))
                self._security_audit.append("system", "backup.automatic", str(result.get("path") or ""), {"sha256": result.get("sha256")})
        except Exception as exc:
            self.logger.error("automatic backup failed: %s", exc)

    def show_health_check(self):
        if not self._require_permission("*"):
            return
        report = run_health_checks()
        lines = [f"总体状态：{report['overall'].upper()}", ""]
        for item in report.get("checks", []):
            lines.append(f"[{item['status'].upper()}] {item['name']}: {item['detail']}")
        QMessageBox.information(self, "系统健康检查", "\n".join(lines))

    def show_help_center(self):
        HelpCenterDialog(Path(__file__).resolve().parent, self).exec()

    def show_production_console(self):
        if not self._require_permission("queue.read"): return
        dialog = ProductionConsoleDialog(self.db, self._device_registry, self)
        dialog.exec()

    def show_mes_console(self):
        if not self._require_permission("mes.read"): return
        dialog = MESConsoleDialog(self.db, self._device_registry, self)
        dialog.exec()

    def show_smart_factory_console(self):
        if not self._require_permission("inventory.read"): return
        dialog = SmartFactoryConsoleDialog(self.db, self._device_registry, self)
        dialog.exec()

    def show_commercial_console(self):
        if not self._require_permission("order.read"): return
        dlg = CommercialConsoleDialog(self.db, self)
        dlg.exec()

    def show_device_center(self):
        if not self._require_permission("device.manage"): return
        dialog = DeviceCenterDialog(self._device_registry, self)
        dialog.exec()

    def show_license(self):
        status = self.license_manager.status()
        details = (
            f"状态：{status.message}\n版本：{status.edition}\n客户：{status.customer or '-'}\n"
            f"许可证：{status.license_id or '-'}\n到期：{status.expires_at or '永久/试用期内'}\n\n"
            f"本机指纹：\n{machine_fingerprint()}"
        )
        box = QMessageBox(self)
        box.setWindowTitle("商业许可证")
        box.setText(details)
        install_btn = box.addButton("安装许可证…", QMessageBox.ActionRole)
        box.addButton(QMessageBox.Close)
        box.exec()
        if box.clickedButton() is install_btn:
            path, _ = QFileDialog.getOpenFileName(self, "安装许可证", "", "许可证 (*.json *.lic);;所有文件 (*)")
            if path:
                try:
                    installed = self.license_manager.install_license(path)
                    self.db.audit("license.installed", {"license_id": installed.license_id, "customer": installed.customer})
                    self._refresh_license_badge()
                    QMessageBox.information(self, "许可证", "许可证安装成功")
                except Exception as exc:
                    QMessageBox.critical(self, "许可证无效", str(exc))

    def enqueue_current(self):
        if not self._require_permission("queue.enqueue"): return
        try:
            self._require_production_license()
            if not self.input_jobs():
                raise ValueError("请先添加生产文件")
            report = run_preflight(self.input_jobs(), self._settings())
            if report.get("errors"):
                raise ValueError("印前检查未通过：\n" + "\n".join(report["errors"][:8]))
            path, _ = QFileDialog.getSaveFileName(self, "队列输出 PDF", "拼版输出.pdf", "PDF (*.pdf)")
            if not path:
                return
            if not path.lower().endswith(".pdf"):
                path += ".pdf"
            snapshot = self._project_snapshot()
            job_id = self.db.enqueue(self.order_no.text().strip() or Path(path).stem, path, snapshot)
            try:
                assignment = self._scheduler.auto_assign_job(job_id)
                device = self._device_registry.get(assignment.device_id)
                suffix = f" · 已派到 {device.name}" if device else ""
            except Exception:
                suffix = " · 暂未自动派机"
            self.statusBar().showMessage(f"已加入生产队列 #{job_id}{suffix}", 6000)
            self.show_queue()
        except Exception as exc:
            QMessageBox.critical(self, "加入队列失败", str(exc))

    def _process_queue_tick(self):
        if self._queue_worker and self._queue_worker.isRunning():
            return
        if not self.license_manager.status().valid:
            return
        if not self.db.has_queued_job():
            return
        job_id = self._scheduler.next_scheduled_job_id()
        if job_id is None:
            return
        self._active_scheduled_job_id = job_id
        try:
            self._scheduler.mark_schedule_state(job_id, "dispatched")
        except Exception:
            pass
        self._queue_worker = QueueWorker(self._persistent_queue, self, job_id=job_id)
        self._queue_worker.finished_one.connect(self._queue_finished)
        self._queue_worker.start()

    def _queue_finished(self, result: dict):
        status = result.get("status")
        job_id = result.get("job_id") or self._active_scheduled_job_id
        if job_id:
            try:
                self._scheduler.mark_schedule_state(int(job_id), "completed" if status == "succeeded" else "failed" if status == "failed" else "planned")
            except Exception:
                pass
        self._active_scheduled_job_id = None
        if status == "succeeded":
            self.statusBar().showMessage(f"生产队列 #{result.get('job_id')} 已完成", 6000)
        elif status == "failed":
            self.statusBar().showMessage(f"生产队列 #{result.get('job_id')} 失败：{result.get('error','')}", 9000)

    def show_queue(self):
        dialog = ProductionQueueDialog(self.db, self, scheduler=self._scheduler, registry=self._device_registry)
        dialog.exec()

    def create_support_bundle_ui(self):
        try:
            path = create_support_bundle()
            self.db.audit("support.bundle_created", {"path": str(path)})
            QMessageBox.information(self, "支持包", f"已生成支持包。\n其中不包含客户 PDF 或生产数据库内容。\n\n{path}")
        except Exception as exc:
            QMessageBox.critical(self, "生成支持包失败", str(exc))

    def check_updates_ui(self):
        try:
            info = check_for_update(Path(__file__).with_name("vendor_public_key.pem"))
            if not info.available:
                QMessageBox.information(self, "软件更新", info.message)
                return
            box = QMessageBox(self)
            box.setWindowTitle("软件更新")
            box.setText(f"发现 V{info.latest_version}\n\n{info.notes}\n\n更新包会先下载到暂存区并验证 SHA-256，不会自动执行安装。")
            stage_btn = box.addButton("下载并校验", QMessageBox.ActionRole)
            box.addButton(QMessageBox.Cancel)
            box.exec()
            if box.clickedButton() is not stage_btn:
                return
            staged = stage_signed_update(info.latest_version, info.download_url, info.sha256)
            actor = self._session.username if self._session else "system"
            self._security_audit.append(actor, "update.staged", staged.path, {"version": staged.version, "sha256": staged.sha256})
            QMessageBox.information(self, "更新已准备", f"更新包校验成功，已进入暂存区：\n{staged.path}\n\n请通过受控安装/升级流程完成安装。")
        except Exception as exc:
            QMessageBox.warning(self, "软件更新", str(exc))

    def about_commercial(self):
        QMessageBox.information(
            self, "关于", f"{APP_NAME} V{APP_VERSION}\n\n"
            "本版本提供生产控制台、设备自动派机、JMF状态看板、ERP自动接单、持久生产队列、事务式 PDF 导出、离线签名授权和支持诊断。\n\n"
            f"厂商：{VENDOR_NAME}\n支持：{SUPPORT_EMAIL}"
        )

    def save_template(self):
        try:
            path, _ = QFileDialog.getSaveFileName(self, "保存拼版模板", "拼版模板.json", "拼版模板 (*.json)")
            if not path: return
            if not path.lower().endswith(".json"): path += ".json"
            payload = {
                "app": "DesktopImposer", "version": APP_VERSION, "settings": self._settings().to_dict(), "layout": self._layout_override,
                "automation": {
                    "hot_input": self.hot_input.text().strip(), "hot_output": self.hot_output.text().strip(),
                    "hot_archive": self.hot_archive.text().strip(), "hot_failed": self.hot_failed.text().strip(),
                    "hot_log": self.hot_log.text().strip(), "move_success": self.hot_move_success.isChecked(),
                    "move_failure": self.hot_move_failure.isChecked(), "settle_seconds": self.hot_settle.value(),
                },
            }
            Path(path).write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
            self.statusBar().showMessage(f"模板已保存：{path}", 5000)
        except Exception as exc:
            QMessageBox.critical(self, "保存模板失败", str(exc))

    def load_template(self):
        try:
            path, _ = QFileDialog.getOpenFileName(self, "加载拼版模板", "", "拼版模板 (*.json)")
            if not path: return
            payload = json.loads(Path(path).read_text(encoding="utf-8"))
            settings = payload.get("settings", payload)
            self._apply_settings_dict(settings)
            self._layout_override = payload.get("layout")
            automation = payload.get("automation", {})
            if automation.get("hot_input"): self.hot_input.setText(str(automation["hot_input"]))
            if automation.get("hot_output"): self.hot_output.setText(str(automation["hot_output"]))
            if automation.get("hot_archive"): self.hot_archive.setText(str(automation["hot_archive"]))
            if automation.get("hot_failed"): self.hot_failed.setText(str(automation["hot_failed"]))
            if automation.get("hot_log"): self.hot_log.setText(str(automation["hot_log"]))
            if "move_success" in automation: self.hot_move_success.setChecked(bool(automation["move_success"]))
            if "move_failure" in automation: self.hot_move_failure.setChecked(bool(automation["move_failure"]))
            if automation.get("settle_seconds"): self.hot_settle.setValue(int(automation["settle_seconds"]))
            self.statusBar().showMessage(f"模板已加载：{path}", 5000)
        except Exception as exc:
            QMessageBox.critical(self, "加载模板失败", str(exc))

    def choose_variable_data(self):
        path, _ = QFileDialog.getOpenFileName(self, "选择逐件变量数据", self.variable_data.text().strip() or "", "变量数据 (*.csv *.xlsx *.xlsm);;CSV (*.csv);;Excel (*.xlsx *.xlsm)")
        if path:
            self.variable_data.setText(path)

    def choose_hot_archive(self):
        path = QFileDialog.getExistingDirectory(self, "选择成功归档目录", self.hot_archive.text().strip() or self.hot_output.text().strip() or "")
        if path:
            self.hot_archive.setText(path)

    def choose_hot_failed(self):
        path = QFileDialog.getExistingDirectory(self, "选择失败隔离目录", self.hot_failed.text().strip() or self.hot_output.text().strip() or "")
        if path:
            self.hot_failed.setText(path)

    def choose_hot_log(self):
        path, _ = QFileDialog.getSaveFileName(self, "选择 Hot Folder 任务日志", self.hot_log.text().strip() or "hotfolder-tasks.jsonl", "JSONL 日志 (*.jsonl);;所有文件 (*)")
        if path:
            if not Path(path).suffix:
                path += ".jsonl"
            self.hot_log.setText(path)

    def choose_hot_input(self):
        path = QFileDialog.getExistingDirectory(self, "选择 Hot Folder 输入目录", self.hot_input.text().strip() or "")
        if path:
            self.hot_input.setText(path)

    def choose_hot_output(self):
        path = QFileDialog.getExistingDirectory(self, "选择 Hot Folder 输出目录", self.hot_output.text().strip() or "")
        if path:
            self.hot_output.setText(path)

    def toggle_hotfolder_from_toolbar(self):
        self.hot_enabled.setChecked(not self.hot_enabled.isChecked())

    def _toggle_hotfolder(self, checked: bool):
        if checked:
            try:
                self._require_production_license()
            except Exception as exc:
                self.hot_enabled.blockSignals(True); self.hot_enabled.setChecked(False); self.hot_enabled.blockSignals(False)
                QMessageBox.warning(self, "Hot Folder", str(exc))
                return
            input_text = self.hot_input.text().strip()
            output_text = self.hot_output.text().strip()
            if not input_text or not output_text:
                self.hot_enabled.blockSignals(True); self.hot_enabled.setChecked(False); self.hot_enabled.blockSignals(False)
                QMessageBox.warning(self, "Hot Folder", "请先选择输入目录和输出目录")
                return
            input_dir = Path(input_text)
            output_dir = Path(output_text)
            if not input_dir.is_dir():
                self.hot_enabled.blockSignals(True); self.hot_enabled.setChecked(False); self.hot_enabled.blockSignals(False)
                QMessageBox.warning(self, "Hot Folder", "请先选择有效的输入目录")
                return
            try:
                output_dir.mkdir(parents=True, exist_ok=True)
            except Exception as exc:
                self.hot_enabled.blockSignals(True); self.hot_enabled.setChecked(False); self.hot_enabled.blockSignals(False)
                QMessageBox.warning(self, "Hot Folder", f"输出目录不可用：{exc}")
                return
            self._hot_processor.settle_seconds = float(self.hot_settle.value())
            self._hot_processor.reset()
            self._hot_timer.start()
            self.hot_status.setText("监听中 · 每 3 秒扫描一次")
            self.statusBar().showMessage("Hot Folder 已启用")
            self._poll_hotfolder()
        else:
            self._hot_timer.stop()
            self.hot_status.setText("未启用")
            self.statusBar().showMessage("Hot Folder 已停止", 4000)

    def _poll_hotfolder(self):
        if not self.hot_enabled.isChecked():
            return
        try:
            self._hot_processor.settle_seconds = float(self.hot_settle.value())
            output_dir = Path(self.hot_output.text().strip())
            archive_dir = self.hot_archive.text().strip() or str(output_dir / "_archive")
            failed_dir = self.hot_failed.text().strip() or str(output_dir / "_failed")
            log_path = self.hot_log.text().strip() or str(output_dir / "hotfolder-tasks.jsonl")
            result = self._hot_processor.scan_once(
                self.hot_input.text().strip(), self.hot_output.text().strip(),
                self._settings(), quantity=self.default_quantity.value(),
                archive_dir=archive_dir, failed_dir=failed_dir, log_path=log_path,
                move_success=self.hot_move_success.isChecked(), move_failure=self.hot_move_failure.isChecked(),
                db=self.db,
            )
            done = result.get("processed", [])
            errors = result.get("errors", [])
            if done:
                names = "、".join(Path(x["input"]).name for x in done[-3:])
                self.hot_status.setText(f"刚完成 {len(done)} 个：{names}")
                self.statusBar().showMessage(f"Hot Folder 自动拼版完成 {len(done)} 个文件", 5000)
            elif errors:
                last = errors[-1]
                self.hot_status.setText(f"错误：{Path(last['input']).name} · {last['error']}")
            else:
                self.hot_status.setText("监听中 · 暂无新文件")
        except Exception as exc:
            self.hot_status.setText(f"监听错误：{exc}")

    def closeEvent(self, event):
        if self._queue_worker and self._queue_worker.isRunning():
            QMessageBox.warning(self, "生产任务进行中", "当前生产队列正在写入 PDF。为避免产生损坏文件，请等待当前任务完成后再关闭软件。")
            event.ignore()
            return
        self._hot_timer.stop()
        self._queue_timer.stop()
        self._autosave_timer.stop()
        self._backup_timer.stop()
        try:
            self._autosave_project()
        except Exception:
            pass
        self._pdf_doc.close()
        if self._preview_path:
            try: os.unlink(self._preview_path)
            except Exception: pass
        self.db.audit("app.closed", {"project": self._current_project_path or ""})
        self.db.set_setting("session.clean_shutdown", True)
        try:
            self._security_audit.append(self._session.username if self._session else "system", "app.clean_shutdown")
            self._crash_marker.clean_shutdown()
        except Exception:
            pass
        super().closeEvent(event)


def main():
    # Used by the Windows packaging pipeline to verify the frozen executable
    # without opening the full production UI. The marker file makes this work
    # even for a windowed/no-console PyInstaller build.
    if "--packaging-self-test" in sys.argv:
        os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
        app = QApplication([sys.argv[0]])
        doc = QPdfDocument()
        marker = os.environ.get("DESKTOP_IMPOSER_SELFTEST_FILE", "").strip()
        payload = {
            "ok": True,
            "app": APP_NAME,
            "version": APP_VERSION,
            "qt_pdf": doc is not None,
        }
        if marker:
            Path(marker).write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        return 0

    logger = configure_logging()
    install_exception_hook(logger)
    app = QApplication(sys.argv); app.setApplicationName(APP_NAME); app.setApplicationVersion(APP_VERSION); app.setStyleSheet(APP_STYLE)
    font = QFont(); font.setPointSize(10); app.setFont(font)
    window = MainWindow()

    # Windows installer registers .imposeproj with this executable. Accept a
    # project path from Explorer/file association on startup.
    project_arg = next((arg for arg in sys.argv[1:] if str(arg).lower().endswith(".imposeproj")), None)
    if project_arg and Path(project_arg).exists():
        window._open_project_path(project_arg, show_errors=False)

    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
