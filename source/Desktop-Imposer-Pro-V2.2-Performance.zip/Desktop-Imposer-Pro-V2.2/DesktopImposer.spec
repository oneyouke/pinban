# PyInstaller spec for Desktop Imposer Pro 2.1
from pathlib import Path
from PyInstaller.utils.hooks import collect_data_files, collect_submodules

root = Path(SPECPATH)
hiddenimports = (
    collect_submodules('PySide6.QtPdf') +
    collect_submodules('PySide6.QtPdfWidgets') +
    collect_submodules('reportlab.graphics.barcode') +
    collect_submodules('PIL') +
    collect_submodules('cryptography')
)
datas = collect_data_files('PySide6', include_py_files=False) + collect_data_files('reportlab', include_py_files=False)
public_key = root / 'vendor_public_key.pem'
if public_key.exists():
    datas.append((str(public_key), '.'))

# license_admin.py and private keys are intentionally NOT bundled.
a = Analysis(
    ['app.py'],
    pathex=[str(root)],
    binaries=[],
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=['license_admin'],
    noarchive=False,
)
pyz = PYZ(a.pure)
exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='DesktopImposerPro',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=False,
)
coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=False,
    upx_exclude=[],
    name='DesktopImposerPro',
)
