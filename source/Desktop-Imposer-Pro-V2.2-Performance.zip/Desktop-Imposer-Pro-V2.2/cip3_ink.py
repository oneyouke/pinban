from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Iterable
import math
import shutil
import subprocess
import tempfile

from PIL import Image


@dataclass(frozen=True)
class InkZoneResult:
    channel: str
    zones: list[float]
    average: float

    def to_dict(self):
        return asdict(self)


def _ink_from_channel_value(channel: str, value: int) -> float:
    value = max(0, min(255, int(value)))
    # RGB source channel means subtractive ink approximation; CMYK image values
    # already represent ink amount. This helper is used only for pre-separated
    # grayscale rasters, so black=100% ink and white=0% ink.
    return (255 - value) / 255.0


def calculate_zones_from_grayscale(image: Image.Image, zones: int = 32, channel: str = "K") -> InkZoneResult:
    if zones < 1:
        raise ValueError("墨键区数量必须大于 0")
    img = image.convert("L")
    width, height = img.size
    if width < 1 or height < 1:
        raise ValueError("图像尺寸无效")
    pixels = img.load()
    values: list[float] = []
    for zone in range(zones):
        x0 = round(zone * width / zones)
        x1 = round((zone + 1) * width / zones)
        if x1 <= x0:
            x1 = min(width, x0 + 1)
        total = 0.0
        count = 0
        for x in range(x0, x1):
            for y in range(height):
                total += _ink_from_channel_value(channel, pixels[x, y])
                count += 1
        values.append(round((total / max(1, count)) * 100.0, 2))
    return InkZoneResult(channel=channel, zones=values, average=round(sum(values) / len(values), 2))


def build_ppf_with_ink_zones(job_id: str, sheet_width_mm: float, sheet_height_mm: float, results: Iterable[InkZoneResult]) -> str:
    lines = [
        "%!PS-Adobe-3.0",
        "%%CIP3-File Version 2.1",
        f"%%CIP3-JobName: {job_id}",
        f"%%CIP3-SheetSizeMM: {sheet_width_mm:.3f} {sheet_height_mm:.3f}",
        "%%CIP3-Note: Ink-zone coverage generated from separated preview rasters",
    ]
    for result in results:
        values = " ".join(f"{v:.2f}" for v in result.zones)
        lines.append(f"%%CIP3-InkZone-{result.channel}: {values}")
        lines.append(f"%%CIP3-InkAverage-{result.channel}: {result.average:.2f}")
    lines.append("%%EOF")
    return "\n".join(lines) + "\n"


def _find_ghostscript() -> str | None:
    for exe in ("gswin64c.exe", "gswin32c.exe", "gs"):
        path = shutil.which(exe)
        if path:
            return path
    return None


def rasterize_separations_with_ghostscript(pdf_path: str | Path, dpi: int = 72, page: int = 1) -> dict[str, Image.Image]:
    """Rasterize CMYK process separations via Ghostscript when available.

    This is a provider baseline, not a guarantee that every RIP's color
    management/overprint behavior is identical. The generated zone values are
    suitable for workflow integration and must be calibrated against the press.
    """
    gs = _find_ghostscript()
    if not gs:
        raise RuntimeError("未检测到 Ghostscript，无法生成 CIP3 墨键预览")
    pdf_path = str(Path(pdf_path).resolve())
    results: dict[str, Image.Image] = {}
    with tempfile.TemporaryDirectory(prefix="imposer_cip3_") as td:
        td = Path(td)
        # Ghostscript tiffsep emits base + separation files. We request one page.
        out = td / "sep.tif"
        cmd = [
            gs, "-dSAFER", "-dBATCH", "-dNOPAUSE",
            f"-r{int(dpi)}", f"-dFirstPage={int(page)}", f"-dLastPage={int(page)}",
            "-sDEVICE=tiffsep", f"-sOutputFile={out}", pdf_path,
        ]
        proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        if proc.returncode != 0:
            raise RuntimeError("Ghostscript 分色失败：" + proc.stdout[-1200:])
        # Common Ghostscript filenames include sep(Cyan).tif etc.
        for p in td.glob("*.tif"):
            lower = p.name.lower()
            channel = None
            for key, label in (("cyan", "C"), ("magenta", "M"), ("yellow", "Y"), ("black", "K")):
                if key in lower:
                    channel = label
                    break
            if channel:
                with Image.open(p) as im:
                    results[channel] = im.convert("L").copy()
    if not results:
        raise RuntimeError("Ghostscript 未生成可识别的 CMYK 分色文件")
    return results
