from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import shutil, subprocess, tempfile

@dataclass(frozen=True)
class ImportResult:
    source: str
    normalized_pdf: str
    provider: str
    temporary: bool = True

class ImportProviderError(RuntimeError): pass


def _ghostscript_exe() -> str | None:
    for name in ("gswin64c", "gswin32c", "gs"):
        p = shutil.which(name)
        if p: return p
    return None


def normalize_to_pdf(path: str | Path, out_dir: str | Path | None = None) -> ImportResult:
    src = Path(path)
    ext = src.suffix.lower()
    if ext == '.pdf':
        return ImportResult(str(src), str(src), 'native-pdf', temporary=False)
    if ext not in {'.ai','.eps','.ps'}:
        raise ImportProviderError(f'该 Provider 仅处理 PDF/AI/EPS/PS：{src.name}')
    gs = _ghostscript_exe()
    if not gs:
        raise ImportProviderError('AI/EPS 导入需要 Ghostscript（或后续配置 Adobe/专业转换 Provider）。')
    out_root = Path(out_dir) if out_dir else Path(tempfile.mkdtemp(prefix='imposer_import_'))
    out_root.mkdir(parents=True, exist_ok=True)
    out = out_root / (src.stem + '.normalized.pdf')
    cmd = [gs,'-dSAFER','-dBATCH','-dNOPAUSE','-sDEVICE=pdfwrite','-dCompatibilityLevel=1.7',f'-sOutputFile={out}',str(src)]
    proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if proc.returncode != 0 or not out.exists():
        raise ImportProviderError(proc.stderr.strip() or 'Ghostscript 转换失败')
    return ImportResult(str(src), str(out), 'ghostscript')
