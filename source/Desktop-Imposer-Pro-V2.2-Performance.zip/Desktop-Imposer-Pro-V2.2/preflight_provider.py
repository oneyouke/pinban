from __future__ import annotations

import json
import os
import shlex
import subprocess
import tempfile
from pathlib import Path
from typing import Any, Sequence

from imposition import InputJob, ImpositionSettings, preflight_jobs


BASIC_PROVIDER = "builtin-risk-scanner"


def _normalize(report: dict[str, Any], provider: str, certified: bool) -> dict[str, Any]:
    result = dict(report or {})
    result["errors"] = list(result.get("errors") or [])
    result["warnings"] = list(result.get("warnings") or [])
    result["infos"] = list(result.get("infos") or [])
    result["provider"] = provider
    result["certified"] = bool(certified)
    result["standard_claim"] = str(result.get("standard_claim") or ("external-certified" if certified else "risk-screening-only"))
    return result


def run_preflight(jobs: Sequence[InputJob], settings: ImpositionSettings) -> dict[str, Any]:
    """Run the configured preflight provider.

    Default: built-in risk scanner. It intentionally returns certified=False.

    Optional professional integration: set DESKTOP_IMPOSER_PREFLIGHT_CLI to an
    executable/command. The command is invoked as:
        <command> <request.json> <response.json>
    and must write errors/warnings/infos plus certified=true only when the
    separately licensed engine really performed the claimed standard check.
    """
    command = os.environ.get("DESKTOP_IMPOSER_PREFLIGHT_CLI", "").strip()
    if not command:
        return _normalize(preflight_jobs(jobs, settings), BASIC_PROVIDER, False)

    request = {
        "schema_version": 1,
        "jobs": [{
            "path": str(Path(j.path).resolve()),
            "quantity": int(j.quantity),
            "trim_width_mm": j.trim_width_mm,
            "trim_height_mm": j.trim_height_mm,
            "bleed_mm": j.bleed_mm,
            "name": j.name,
        } for j in jobs],
        "settings": settings.to_dict(),
    }
    with tempfile.TemporaryDirectory(prefix="desktop_imposer_preflight_") as td:
        req = Path(td) / "request.json"
        resp = Path(td) / "response.json"
        req.write_text(json.dumps(request, ensure_ascii=False, indent=2), encoding="utf-8")
        argv = shlex.split(command, posix=os.name != "nt") + [str(req), str(resp)]
        try:
            completed = subprocess.run(argv, capture_output=True, text=True, timeout=180, check=False)
        except Exception as exc:
            return _normalize({"errors": [f"专业印前引擎启动失败：{exc}"]}, command, False)
        if completed.returncode != 0:
            detail = (completed.stderr or completed.stdout or "").strip()[-2000:]
            return _normalize({"errors": [f"专业印前引擎返回错误码 {completed.returncode}：{detail}"]}, command, False)
        try:
            data = json.loads(resp.read_text(encoding="utf-8"))
        except Exception as exc:
            return _normalize({"errors": [f"专业印前引擎响应无效：{exc}"]}, command, False)
        return _normalize(data, str(data.get("provider") or command), bool(data.get("certified", False)))
