from __future__ import annotations

import hashlib
import hmac
import json
import os
import secrets
import sqlite3
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

from app_paths import database_path

ROLE_PERMISSIONS: dict[str, set[str]] = {
    "admin": {"*"},
    "prepress": {
        "project.open", "project.save", "source.import", "imposition.edit", "preflight.run",
        "production.export", "queue.enqueue", "device.read", "template.manage", "help.read",
    },
    "production": {
        "queue.read", "queue.reorder", "mes.read", "mes.report", "device.read", "rip.deliver",
        "inventory.read", "quality.read", "quality.report", "help.read",
    },
    "sales": {
        "customer.read", "customer.manage", "quote.read", "quote.manage", "order.read", "order.manage",
        "profit.read_limited", "help.read",
    },
    "finance": {
        "customer.read", "quote.read", "order.read", "ar.manage", "ap.manage", "credit.manage",
        "profit.read", "cashflow.read", "commission.manage", "help.read",
    },
    "viewer": {
        "project.open", "queue.read", "mes.read", "device.read", "inventory.read", "quote.read",
        "order.read", "help.read",
    },
}

@dataclass(frozen=True)
class UserSession:
    user_id: int
    username: str
    display_name: str
    role: str
    permissions: frozenset[str]

    def can(self, permission: str) -> bool:
        return "*" in self.permissions or permission in self.permissions

class AccessDenied(PermissionError):
    pass


def require(session: UserSession | None, permission: str) -> None:
    if session is None or not session.can(permission):
        raise AccessDenied(f"permission denied: {permission}")


def _derive(password: str, salt: bytes) -> bytes:
    if len(password) < 8:
        raise ValueError("password must contain at least 8 characters")
    return hashlib.scrypt(password.encode("utf-8"), salt=salt, n=2**14, r=8, p=1, dklen=32)


class UserStore:
    """Local RBAC store.

    Passwords are stored as scrypt hashes. The application never ships a default
    administrator password: first-run setup must explicitly create one.
    """

    def __init__(self, path: str | Path | None = None) -> None:
        self.path = Path(path) if path else database_path()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._init_schema()

    def _connect(self) -> sqlite3.Connection:
        db = sqlite3.connect(self.path, timeout=15)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys=ON")
        return db

    def _init_schema(self) -> None:
        with self._connect() as db:
            db.executescript("""
            CREATE TABLE IF NOT EXISTS app_users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE COLLATE NOCASE,
                display_name TEXT NOT NULL,
                role TEXT NOT NULL,
                password_salt BLOB NOT NULL,
                password_hash BLOB NOT NULL,
                enabled INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS user_permission_overrides (
                user_id INTEGER NOT NULL REFERENCES app_users(id) ON DELETE CASCADE,
                permission TEXT NOT NULL,
                allowed INTEGER NOT NULL,
                PRIMARY KEY(user_id, permission)
            );
            """)

    def has_users(self) -> bool:
        with self._connect() as db:
            return bool(db.execute("SELECT 1 FROM app_users LIMIT 1").fetchone())

    def create_user(self, username: str, password: str, role: str, display_name: str = "") -> int:
        username = username.strip()
        if not username:
            raise ValueError("username is required")
        if role not in ROLE_PERMISSIONS:
            raise ValueError(f"unknown role: {role}")
        salt = secrets.token_bytes(16)
        digest = _derive(password, salt)
        with self._connect() as db:
            cur = db.execute(
                "INSERT INTO app_users(username,display_name,role,password_salt,password_hash) VALUES(?,?,?,?,?)",
                (username, display_name.strip() or username, role, salt, digest),
            )
            return int(cur.lastrowid)

    def set_password(self, user_id: int, password: str) -> None:
        salt = secrets.token_bytes(16)
        digest = _derive(password, salt)
        with self._connect() as db:
            db.execute(
                "UPDATE app_users SET password_salt=?,password_hash=?,updated_at=CURRENT_TIMESTAMP WHERE id=?",
                (salt, digest, int(user_id)),
            )

    def set_enabled(self, user_id: int, enabled: bool) -> None:
        with self._connect() as db:
            db.execute("UPDATE app_users SET enabled=?,updated_at=CURRENT_TIMESTAMP WHERE id=?", (1 if enabled else 0, int(user_id)))

    def set_role(self, user_id: int, role: str) -> None:
        if role not in ROLE_PERMISSIONS:
            raise ValueError(f"unknown role: {role}")
        with self._connect() as db:
            db.execute("UPDATE app_users SET role=?,updated_at=CURRENT_TIMESTAMP WHERE id=?", (role, int(user_id)))

    def set_override(self, user_id: int, permission: str, allowed: bool | None) -> None:
        with self._connect() as db:
            if allowed is None:
                db.execute("DELETE FROM user_permission_overrides WHERE user_id=? AND permission=?", (int(user_id), permission))
            else:
                db.execute(
                    "INSERT INTO user_permission_overrides(user_id,permission,allowed) VALUES(?,?,?) "
                    "ON CONFLICT(user_id,permission) DO UPDATE SET allowed=excluded.allowed",
                    (int(user_id), permission, 1 if allowed else 0),
                )

    def authenticate(self, username: str, password: str) -> UserSession | None:
        with self._connect() as db:
            row = db.execute("SELECT * FROM app_users WHERE username=? COLLATE NOCASE", (username.strip(),)).fetchone()
            if not row or not row["enabled"]:
                return None
            try:
                actual = _derive(password, bytes(row["password_salt"]))
            except ValueError:
                return None
            if not hmac.compare_digest(actual, bytes(row["password_hash"])):
                return None
            perms = set(ROLE_PERMISSIONS.get(row["role"], set()))
            overrides = db.execute(
                "SELECT permission,allowed FROM user_permission_overrides WHERE user_id=?", (row["id"],)
            ).fetchall()
        if "*" not in perms:
            for item in overrides:
                if item["allowed"]:
                    perms.add(item["permission"])
                else:
                    perms.discard(item["permission"])
        return UserSession(int(row["id"]), row["username"], row["display_name"], row["role"], frozenset(perms))

    def list_users(self) -> list[dict]:
        with self._connect() as db:
            rows = db.execute("SELECT id,username,display_name,role,enabled,created_at,updated_at FROM app_users ORDER BY id").fetchall()
        return [dict(r) for r in rows]
