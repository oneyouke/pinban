# V2.1 Release Hardening Layer

V2.1 在 V2.0 产品化层上增加 `runtime_resilience.py`、`backup_scheduler.py`、`update_staging.py` 和 `health_check.py`。原则是：生产输出事务与运维任务隔离；升级包先验证后 staging；备份/审计失败不得造成半写 PDF；支持包只包含诊断元数据，不包含客户原稿。

# V2.0 Productization Layer

V2.0 在原业务模块之上新增产品化层：`access_control.py`、`migration_manager.py`、`backup_restore.py`、`branding.py`、`localization.py`、`first_run.py`、`product_workspace.py`、`help_center.py`。权限校验既存在于 UI 路由，也存在于关键业务动作入口。备份恢复与数据库迁移均以“先验证、后替换”为原则。

# Desktop Imposer Pro 1.0 Architecture

## Product goals

- Local-first print production: imposition does not require internet access.
- Production safety: an interrupted export must not replace a valid output with a partial PDF.
- Recoverability: projects, queued jobs and audit records survive application restarts.
- Clear standards boundary: built-in preflight is risk screening; standards-certified PDF/X conversion/preflight is delegated to a professional provider when required.
- Commercial distribution: offline signed licenses, signed update manifests, installer/build gates, support diagnostics and third-party notices.

## Layers

```text
Qt Widgets UI (app.py / layout_editor.py / queue_dialog.py)
        |
        +-- project_file.py        .imposeproj persistence / autosave
        +-- storage.py             SQLite settings / queue / audit
        +-- licensing.py           Ed25519 offline licenses
        +-- updates.py             signed update manifest verification
        +-- support.py             rotating logs / crash hook / support bundle
        |
production_service.py             transaction boundary
        |-- preflight_provider.py  built-in or professional external provider
        |-- imposition.py          layout / PDF merge / marks / variable data
        |-- output validation      reopen pages + SHA-256 + sidecar manifest
        |
hotfolder.py / queue_service.py   unattended production entry points
```

## Transactional production export

`atomic_production_export()` performs:

1. preflight;
2. input SHA-256 inventory;
3. output to a temporary file in the destination directory;
4. reopen generated PDF and validate every page dictionary/media box;
5. output SHA-256;
6. atomic `os.replace()` to the customer-visible PDF path;
7. `.production.json` sidecar with inputs, hashes, settings, warnings and summary;
8. SQLite audit event.

This design prevents a crash halfway through PDF writing from leaving a partial file at the final output path.

## Production queue

`production_jobs` is persisted in SQLite. States are:

- `queued`
- `running`
- `succeeded`
- `failed`
- `canceled`

If the application starts and finds `running` jobs from an interrupted session, they are automatically returned to `queued` with an interruption reason. The Qt application continuously processes queued work in a worker thread while the license is valid.

## Licensing

Runtime ships only an Ed25519 **public key**. Licenses are signed JSON documents. The private signing key is generated/stored outside the client build tree and is excluded from PyInstaller.

The included trial is a convenience mechanism, not an anti-tamper substitute for an activation service. For subscriptions or high-value licenses, add a server activation/lease service while keeping the offline signed-license fallback for print-floor resilience.

## PDF standards provider

The built-in provider returns:

```json
{"provider":"builtin-risk-scanner","certified":false,"standard_claim":"risk-screening-only"}
```

Set `DESKTOP_IMPOSER_PREFLIGHT_CLI` to integrate a separately licensed professional engine. See `PROFESSIONAL_PREFLIGHT_PROTOCOL.md`.


## V1.4 调度层

V1.4 在 `production_jobs` 之上增加 `production_schedule`，保持“文件生产状态”和“设备排程状态”分离：

- `production_jobs`：PDF 生成事务的 source of truth；
- `production_schedule`：设备、优先级、计划状态和派机原因；
- `device_runtime_status`：JMF 轮询得到的设备/作业状态；
- `ProductionScheduler`：设备兼容性和负载评分；
- `PersistentQueue`：生产完成后按派机信息进行 RIP/JDF 投递；
- `ProductionConsoleDialog`：只负责调度和可视化，不直接修改拼版引擎。

这种分层让设备离线或 JMF 异常不会破坏本地 PDF 生产事务。


## V1.5 MES 层

`mes.py` 在预印队列/排程之上建立车间执行模型，使用 `mes_runs`、`mes_downtime`、`mes_events` 三张 SQLite 表。`workflow.py` 提供 ERP→预印→设备→印刷→完工统一状态；`mes_console.py` 提供桌面现场操作入口。


## V1.8 商业运营层

`commercial.py` 独立管理客户、报价、销售订单、应收、采购、批次成本和实际毛利；通过 `order_id` / `production_job_id` 与生产层关联。该层不承担法定财务总账和税务开票。


## V1.9 Sales/Finance Collaboration Layer

`sales_finance.py` 位于 `commercial.py` 之上，使用同一 ProductionDB，但不改变拼版/生产事务语义。
它负责价格规则、审批、信用、提成、对账、现金流和经营分析；法定会计仍通过外部 Provider 集成。
