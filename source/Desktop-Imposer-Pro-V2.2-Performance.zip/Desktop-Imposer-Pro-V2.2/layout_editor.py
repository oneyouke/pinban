from __future__ import annotations

import copy

from PySide6.QtCore import Qt, QSize, QPointF
from PySide6.QtGui import QColor, QBrush, QPen, QPainter, QPixmap
from PySide6.QtPdf import QPdfDocument
from PySide6.QtWidgets import (
    QCheckBox, QDialog, QDialogButtonBox, QDoubleSpinBox, QGraphicsItem,
    QGraphicsRectItem, QGraphicsScene, QGraphicsSimpleTextItem, QGraphicsView,
    QHBoxLayout, QLabel, QMessageBox, QPushButton, QSlider, QSpinBox, QVBoxLayout,
)

from imposition import ImpositionSettings, validate_manual_layout


class PlacementItem(QGraphicsRectItem):
    def __init__(self, placement: dict, sheet_height_mm: float, label: str, owner):
        self.placement = copy.deepcopy(placement)
        self.sheet_height_mm = sheet_height_mm
        self.owner = owner
        w = float(placement["footprint_width_mm"])
        h = float(placement["footprint_height_mm"])
        super().__init__(0, 0, w, h)
        self.setPos(float(placement["x_mm"]), sheet_height_mm - float(placement["y_mm"]) - h)
        self.setFlags(
            QGraphicsItem.ItemIsMovable
            | QGraphicsItem.ItemIsSelectable
            | QGraphicsItem.ItemSendsGeometryChanges
        )
        self.setPen(QPen(QColor("#1769aa"), 0.35))
        self.setBrush(QBrush(QColor(77, 166, 255, 55)))
        self._label = QGraphicsSimpleTextItem(label, self)
        self._label.setBrush(QBrush(QColor("#17324d")))
        self._label.setScale(0.75)
        self._recenter_label()

    def _recenter_label(self):
        br = self._label.boundingRect()
        r = self.rect()
        self._label.setPos(
            max(1.0, (r.width() - br.width() * 0.75) / 2),
            max(1.0, (r.height() - br.height() * 0.75) / 2),
        )

    def itemChange(self, change, value):
        if change == QGraphicsItem.ItemPositionChange and self.owner.snap_enabled():
            step = self.owner.snap_step()
            if step > 0:
                p = value
                return QPointF(round(p.x() / step) * step, round(p.y() / step) * step)
        return super().itemChange(change, value)

    def mousePressEvent(self, event):
        self.owner.begin_item_action()
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event):
        super().mouseReleaseEvent(event)
        self.owner.end_item_action()

    def mouseDoubleClickEvent(self, event):
        self.owner.begin_item_action()
        r = self.rect()
        self.setRect(0, 0, r.height(), r.width())
        self.placement["rotation"] = (int(self.placement.get("rotation", 0)) + 90) % 360
        self._recenter_label()
        self.owner.end_item_action()
        event.accept()

    def export_placement(self) -> dict:
        r = self.rect()
        pos = self.pos()
        data = copy.deepcopy(self.placement)
        data["x_mm"] = round(float(pos.x()), 4)
        data["y_mm"] = round(float(self.sheet_height_mm - pos.y() - r.height()), 4)
        data["footprint_width_mm"] = round(float(r.width()), 4)
        data["footprint_height_mm"] = round(float(r.height()), 4)
        return data


class LayoutEditorDialog(QDialog):
    def __init__(self, layout: dict, settings: ImpositionSettings, job_names: list[str], parent=None):
        super().__init__(parent)
        self.setWindowTitle("手工调整版位 · 吸附 / 对齐 / 撤销 / 跨版")
        self.resize(1120, 800)
        self.layout = copy.deepcopy(layout)
        self.settings = settings
        self.job_names = job_names
        self.items: list[PlacementItem] = []
        self._sheet_index = 0
        self._action_open = False
        self._history: list[dict] = [copy.deepcopy(self.layout)]
        self._history_index = 0
        self._original = copy.deepcopy(layout)

        root = QVBoxLayout(self)
        header = QHBoxLayout()
        header.addWidget(QLabel("版次"))
        self.sheet_spin = QSpinBox()
        self.sheet_spin.setRange(1, max(1, len(self.layout.get("sheets", []))))
        header.addWidget(self.sheet_spin)
        header.addSpacing(12)
        self.snap_check = QCheckBox("网格吸附")
        self.snap_check.setChecked(True)
        self.snap_mm = QDoubleSpinBox()
        self.snap_mm.setRange(0.1, 20.0)
        self.snap_mm.setDecimals(1)
        self.snap_mm.setSingleStep(0.5)
        self.snap_mm.setValue(1.0)
        self.snap_mm.setSuffix(" mm")
        header.addWidget(self.snap_check)
        header.addWidget(self.snap_mm)
        header.addStretch()
        self.status = QLabel("拖动=移动；双击=旋转90°；多选后可对齐或跨版")
        self.status.setStyleSheet("color:#667788;")
        header.addWidget(self.status)
        root.addLayout(header)

        self.scene = QGraphicsScene(self)
        self.view = QGraphicsView(self.scene)
        self.view.setRenderHint(QPainter.Antialiasing, True)
        self.view.setDragMode(QGraphicsView.RubberBandDrag)
        root.addWidget(self.view, 1)

        tools1 = QHBoxLayout()
        self.undo_btn = QPushButton("撤销")
        self.redo_btn = QPushButton("重做")
        self.reset_btn = QPushButton("恢复自动布局")
        self.fit_btn = QPushButton("适合窗口")
        self.prev_sheet_btn = QPushButton("移到上一版")
        self.next_sheet_btn = QPushButton("移到下一版")
        for b in (self.undo_btn, self.redo_btn, self.reset_btn, self.fit_btn, self.prev_sheet_btn, self.next_sheet_btn):
            tools1.addWidget(b)
        tools1.addStretch()
        root.addLayout(tools1)

        tools2 = QHBoxLayout()
        tools2.addWidget(QLabel("对齐："))
        for text, mode in [
            ("左", "left"), ("右", "right"), ("上", "top"), ("下", "bottom"),
            ("水平中心", "hcenter"), ("垂直中心", "vcenter"),
        ]:
            btn = QPushButton(text)
            btn.clicked.connect(lambda _=False, m=mode: self.align_selected(m))
            tools2.addWidget(btn)
        tools2.addStretch()
        root.addLayout(tools2)

        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.button(QDialogButtonBox.Save).setText("检查并保存版位")
        buttons.button(QDialogButtonBox.Cancel).setText("取消")
        root.addWidget(buttons)

        self.sheet_spin.valueChanged.connect(self._switch_sheet)
        self.reset_btn.clicked.connect(self._reset_current_sheet)
        self.fit_btn.clicked.connect(self._fit)
        self.undo_btn.clicked.connect(self.undo)
        self.redo_btn.clicked.connect(self.redo)
        self.prev_sheet_btn.clicked.connect(lambda: self.move_selected_to_sheet(-1))
        self.next_sheet_btn.clicked.connect(lambda: self.move_selected_to_sheet(1))
        buttons.accepted.connect(self._accept_checked)
        buttons.rejected.connect(self.reject)

        self._render_sheet(0)
        self._update_history_buttons()

    def snap_enabled(self) -> bool:
        return self.snap_check.isChecked()

    def snap_step(self) -> float:
        return float(self.snap_mm.value())

    def _commit_current(self):
        sheets = self.layout.get("sheets", [])
        if not sheets or self._sheet_index >= len(sheets):
            return
        sheets[self._sheet_index] = [item.export_placement() for item in self.items]

    def _push_history(self):
        self._commit_current()
        snapshot = copy.deepcopy(self.layout)
        if snapshot == self._history[self._history_index]:
            return
        self._history = self._history[: self._history_index + 1]
        self._history.append(snapshot)
        self._history_index += 1
        if len(self._history) > 100:
            self._history.pop(0)
            self._history_index -= 1
        self._update_history_buttons()

    def begin_item_action(self):
        if not self._action_open:
            self._commit_current()
            self._action_open = True

    def end_item_action(self):
        if self._action_open:
            self._action_open = False
            self._push_history()

    def undo(self):
        self._commit_current()
        if self._history_index <= 0:
            return
        self._history_index -= 1
        self.layout = copy.deepcopy(self._history[self._history_index])
        self._normalize_sheet_index()
        self._render_sheet(self._sheet_index)
        self._update_history_buttons()

    def redo(self):
        self._commit_current()
        if self._history_index >= len(self._history) - 1:
            return
        self._history_index += 1
        self.layout = copy.deepcopy(self._history[self._history_index])
        self._normalize_sheet_index()
        self._render_sheet(self._sheet_index)
        self._update_history_buttons()

    def _update_history_buttons(self):
        self.undo_btn.setEnabled(self._history_index > 0)
        self.redo_btn.setEnabled(self._history_index < len(self._history) - 1)

    def _normalize_sheet_index(self):
        sheets = self.layout.get("sheets", [])
        if not sheets:
            self.layout["sheets"] = [[]]
            sheets = self.layout["sheets"]
        self._sheet_index = max(0, min(self._sheet_index, len(sheets) - 1))
        self.sheet_spin.blockSignals(True)
        self.sheet_spin.setRange(1, len(sheets))
        self.sheet_spin.setValue(self._sheet_index + 1)
        self.sheet_spin.blockSignals(False)

    def _switch_sheet(self, value: int):
        self._commit_current()
        self._render_sheet(value - 1)

    def _render_sheet(self, index: int):
        sheets = self.layout.setdefault("sheets", [[]])
        self._sheet_index = max(0, min(index, len(sheets) - 1))
        self.scene.clear()
        self.items = []
        sw = float(self.settings.sheet_width_mm)
        sh = float(self.settings.sheet_height_mm)
        self.scene.setSceneRect(-8, -8, sw + 16, sh + 16)

        paper = self.scene.addRect(0, 0, sw, sh, QPen(QColor("#2c3e50"), 0.5), QBrush(QColor("white")))
        paper.setZValue(-10)
        mx = float(self.settings.margin_x_mm)
        my = float(self.settings.margin_y_mm)
        safe = self.scene.addRect(mx, my, sw - 2 * mx, sh - 2 * my, QPen(QColor("#9aa7b4"), 0.3, Qt.DashLine))
        safe.setZValue(-5)

        for p in sheets[self._sheet_index]:
            job_idx = int(p.get("job_index", 0))
            label = self.job_names[job_idx] if 0 <= job_idx < len(self.job_names) else f"款{job_idx+1}"
            label = f"{label} #{int(p.get('unit_index', 0)) + 1}"
            item = PlacementItem(p, sh, label, self)
            self.scene.addItem(item)
            self.items.append(item)
        self._normalize_sheet_index()
        self.status.setText(f"第 {self._sheet_index + 1}/{len(sheets)} 版 · {len(self.items)} 件")
        self._fit()

    def _selected(self) -> list[PlacementItem]:
        return [x for x in self.items if x.isSelected()]

    def align_selected(self, mode: str):
        selected = self._selected()
        if len(selected) < 2:
            QMessageBox.information(self, "对齐", "请至少选择 2 个版位")
            return
        self.begin_item_action()
        left = min(x.pos().x() for x in selected)
        right = max(x.pos().x() + x.rect().width() for x in selected)
        top = min(x.pos().y() for x in selected)
        bottom = max(x.pos().y() + x.rect().height() for x in selected)
        cx = (left + right) / 2
        cy = (top + bottom) / 2
        for item in selected:
            p = item.pos()
            if mode == "left": item.setPos(left, p.y())
            elif mode == "right": item.setPos(right - item.rect().width(), p.y())
            elif mode == "top": item.setPos(p.x(), top)
            elif mode == "bottom": item.setPos(p.x(), bottom - item.rect().height())
            elif mode == "hcenter": item.setPos(cx - item.rect().width()/2, p.y())
            elif mode == "vcenter": item.setPos(p.x(), cy - item.rect().height()/2)
        self.end_item_action()

    def move_selected_to_sheet(self, delta: int):
        selected = self._selected()
        if not selected:
            QMessageBox.information(self, "跨版移动", "请先选择要移动的版位")
            return
        self._commit_current()
        target = self._sheet_index + delta
        if target < 0:
            QMessageBox.information(self, "跨版移动", "当前已经是第一版")
            return
        sheets = self.layout.setdefault("sheets", [[]])
        if target >= len(sheets):
            sheets.append([])
        keys = {(int(x.placement.get("job_index", 0)), int(x.placement.get("unit_index", 0))) for x in selected}
        moving = []
        remain = []
        for p in sheets[self._sheet_index]:
            key = (int(p.get("job_index", 0)), int(p.get("unit_index", 0)))
            (moving if key in keys else remain).append(p)
        sheets[self._sheet_index] = remain
        sheets[target].extend(moving)
        # Remove empty trailing sheets only when they are not the target.
        while len(sheets) > 1 and not sheets[-1] and target != len(sheets) - 1:
            sheets.pop()
        self._sheet_index = target
        self._push_history()
        self._render_sheet(self._sheet_index)

    def _fit(self):
        self.view.fitInView(self.scene.sceneRect(), Qt.KeepAspectRatio)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._fit()

    def _reset_current_sheet(self):
        self._commit_current()
        idx = self._sheet_index
        if idx < len(self._original.get("sheets", [])):
            self.layout["sheets"][idx] = copy.deepcopy(self._original["sheets"][idx])
        else:
            self.layout["sheets"][idx] = []
        self._push_history()
        self._render_sheet(idx)

    def _accept_checked(self):
        self._commit_current()
        # Drop empty sheets before validation/output.
        self.layout["sheets"] = [s for s in self.layout.get("sheets", []) if s]
        if not self.layout["sheets"]:
            QMessageBox.critical(self, "版位检查未通过", "没有任何版位")
            return
        result = validate_manual_layout(self.layout, self.settings)
        if result["errors"]:
            QMessageBox.critical(self, "版位检查未通过", "\n".join(result["errors"][:20]))
            return
        self.accept()


class DuplexOverlayDialog(QDialog):
    def __init__(self, pdf_path: str, settings: ImpositionSettings, parent=None):
        super().__init__(parent)
        self.setWindowTitle("正反面透明叠加检查")
        self.resize(1000, 760)
        self.settings = settings
        self.doc = QPdfDocument(self)
        error = self.doc.load(pdf_path)
        if error != QPdfDocument.Error.None_:
            raise RuntimeError(f"PDF 加载失败：{error}")
        if self.doc.pageCount() < 2:
            raise ValueError("当前预览没有正反页")

        root = QVBoxLayout(self)
        top = QHBoxLayout()
        top.addWidget(QLabel("版次"))
        self.pair_spin = QSpinBox()
        self.pair_spin.setRange(1, max(1, self.doc.pageCount() // 2))
        top.addWidget(self.pair_spin)
        top.addWidget(QLabel("反面透明度"))
        self.opacity = QSlider(Qt.Horizontal)
        self.opacity.setRange(0, 100)
        self.opacity.setValue(50)
        self.opacity.setMaximumWidth(220)
        top.addWidget(self.opacity)
        top.addStretch()
        self.info = QLabel("反面已按翻长边/翻短边还原；轮廓重合越好，对位越准确")
        self.info.setStyleSheet("color:#667788;")
        top.addWidget(self.info)
        root.addLayout(top)

        self.scene = QGraphicsScene(self)
        self.view = QGraphicsView(self.scene)
        self.view.setRenderHint(QPainter.Antialiasing, True)
        root.addWidget(self.view, 1)

        buttons = QDialogButtonBox(QDialogButtonBox.Close)
        buttons.rejected.connect(self.reject)
        buttons.accepted.connect(self.accept)
        root.addWidget(buttons)

        self.pair_spin.valueChanged.connect(self._render)
        self.opacity.valueChanged.connect(self._render)
        self._render()

    def _render(self, *_):
        pair = self.pair_spin.value() - 1
        front_idx = pair * 2
        back_idx = front_idx + 1
        if back_idx >= self.doc.pageCount():
            return

        sizef = self.doc.pagePointSize(front_idx)
        width = 1400
        height = max(1, int(width * sizef.height() / max(1.0, sizef.width())))
        target = QSize(width, height)
        front = self.doc.render(front_idx, target)
        back = self.doc.render(back_idx, target)

        long_edge_is_horizontal = self.settings.sheet_width_mm >= self.settings.sheet_height_mm
        mirror_y = (self.settings.duplex_flip == "long") == long_edge_is_horizontal
        if mirror_y:
            back = back.mirrored(False, True)
        else:
            back = back.mirrored(True, False)

        painter = QPainter(front)
        painter.setOpacity(self.opacity.value() / 100.0)
        painter.drawImage(0, 0, back)
        painter.end()

        self.scene.clear()
        self.scene.addPixmap(QPixmap.fromImage(front))
        self.scene.setSceneRect(0, 0, front.width(), front.height())
        self.view.fitInView(self.scene.sceneRect(), Qt.KeepAspectRatio)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if not self.scene.sceneRect().isEmpty():
            self.view.fitInView(self.scene.sceneRect(), Qt.KeepAspectRatio)
