from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timezone

@dataclass(frozen=True)
class DeliveryRisk:
    order_id: str
    risk: str
    minutes_late: float
    score: float
    reason: str

def delivery_risk(order_id:str, planned_end:str, due_at:str, *, priority:int=100, margin_value:float=0.0) -> DeliveryRisk:
    pe=datetime.fromisoformat(planned_end.replace('Z','+00:00')); due=datetime.fromisoformat(due_at.replace('Z','+00:00'))
    if pe.tzinfo is None: pe=pe.replace(tzinfo=timezone.utc)
    if due.tzinfo is None: due=due.replace(tzinfo=timezone.utc)
    late=(pe-due).total_seconds()/60
    urgency=max(0, 120-int(priority))/120
    score=max(0.0, late/60)*50 + urgency*25 + min(25,max(0,margin_value)/1000)
    level='high' if late>60 or score>=70 else 'medium' if late>0 or score>=35 else 'low'
    return DeliveryRisk(order_id,level,round(max(0,late),2),round(score,2),f'预计完工 {planned_end}，交期 {due_at}')
