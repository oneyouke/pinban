from __future__ import annotations

import json
import logging
from logging.handlers import RotatingFileHandler
import os
import platform
import sys
import traceback
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from app_paths import data_dir, log_dir, database_path, config_dir
from product import APP_NAME, APP_VERSION


def utc_stamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def configure_logging() -> logging.Logger:
    logger = logging.getLogger("desktop_imposer")
    if logger.handlers:
        return logger
    logger.setLevel(logging.INFO)
    path = log_dir() / "desktop-imposer.log"
    handler = RotatingFileHandler(path, maxBytes=2_000_000, backupCount=5, encoding="utf-8")
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s %(message)s"))
    logger.addHandler(handler)
    logger.info("startup app=%s version=%s platform=%s", APP_NAME, APP_VERSION, platform.platform())
    return logger


def install_exception_hook(logger: logging.Logger | None = None) -> None:
    log = logger or configure_logging()
    original = sys.excepthook

    def hook(exc_type, exc_value, exc_tb):
        log.critical("uncaught exception\n%s", "".join(traceback.format_exception(exc_type, exc_value, exc_tb)))
        original(exc_type, exc_value, exc_tb)

    sys.excepthook = hook


def runtime_info() -> dict[str, Any]:
    info = {
        "app": APP_NAME,
        "app_version": APP_VERSION,
        "python": sys.version,
        "platform": platform.platform(),
        "machine": platform.machine(),
        "executable": sys.executable,
        "frozen": bool(getattr(sys, "frozen", False)),
    }
    for module_name in ("PySide6", "pypdf", "reportlab", "PIL", "openpyxl", "cryptography"):
        try:
            mod = __import__(module_name)
            info[module_name] = getattr(mod, "__version__", getattr(mod, "Version", "unknown"))
        except Exception as exc:
            info[module_name] = f"unavailable: {exc}"
    return info


def create_support_bundle(output_dir: str | Path | None = None) -> Path:
    out_dir = Path(output_dir) if output_dir else data_dir() / "support"
    out_dir.mkdir(parents=True, exist_ok=True)
    dst = out_dir / f"support-{utc_stamp()}.zip"
    info = runtime_info()
    info["data_dir"] = str(data_dir())
    info["config_dir"] = str(config_dir())
    info["database_exists"] = database_path().exists()
    info["database_size"] = database_path().stat().st_size if database_path().exists() else 0

    with zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("runtime.json", json.dumps(info, ensure_ascii=False, indent=2, default=str))
        for p in sorted(log_dir().glob("desktop-imposer.log*")):
            if p.is_file():
                zf.write(p, f"logs/{p.name}")
        try:
            from health_check import run_health_checks
            zf.writestr("health-check.json", json.dumps(run_health_checks(), ensure_ascii=False, indent=2))
        except Exception as exc:
            zf.writestr("health-check.json", json.dumps({"error": str(exc)}, ensure_ascii=False, indent=2))
        try:
            from runtime_resilience import AuditTrail
            zf.writestr("audit-chain.json", json.dumps(AuditTrail(database_path()).verify(), ensure_ascii=False, indent=2))
        except Exception as exc:
            zf.writestr("audit-chain.json", json.dumps({"error": str(exc)}, ensure_ascii=False, indent=2))
        # Only include schema diagnostics, never the production DB/customer files.
        try:
            import sqlite3
            with sqlite3.connect(database_path()) as db:
                integrity = db.execute("PRAGMA integrity_check").fetchone()[0]
                tables = [r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")]
            zf.writestr("database-diagnostic.json", json.dumps({"integrity_check": integrity, "tables": tables}, ensure_ascii=False, indent=2))
        except Exception as exc:
            zf.writestr("database-diagnostic.json", json.dumps({"error": str(exc)}, ensure_ascii=False, indent=2))
    return dst
