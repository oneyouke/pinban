from __future__ import annotations
import importlib.metadata as md
import json
from datetime import datetime, timezone
from pathlib import Path
from product import APP_NAME, APP_VERSION

wanted = {"PySide6", "pypdf", "reportlab", "Pillow", "openpyxl", "cryptography"}
components = []
for dist in md.distributions():
    name = dist.metadata.get("Name", "")
    if name in wanted:
        components.append({
            "name": name,
            "version": dist.version,
            "license": dist.metadata.get("License", ""),
            "home_page": dist.metadata.get("Home-page", ""),
        })
payload = {
    "bomFormat": "DesktopImposer-SBOM",
    "created_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    "product": APP_NAME,
    "version": APP_VERSION,
    "components": sorted(components, key=lambda x: x["name"].lower()),
}
out = Path("release-sbom.json")
out.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
print(out)
