from __future__ import annotations

import hashlib
import json
import os
import shutil
import urllib.parse
import urllib.request
from dataclasses import dataclass
from pathlib import Path

from app_paths import data_dir

ALLOWED_INSTALLER_SUFFIXES = {".exe", ".msi", ".zip"}


def sha256_file(path: str | Path) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


@dataclass(frozen=True)
class StagedUpdate:
    version: str
    path: str
    sha256: str
    metadata_path: str


def stage_signed_update(version: str, download_url: str, expected_sha256: str,
                        staging_dir: str | Path | None = None, timeout: int = 30) -> StagedUpdate:
    parsed = urllib.parse.urlparse(download_url)
    if parsed.scheme.lower() != "https":
        raise ValueError("update package must use HTTPS")
    name = Path(parsed.path).name or f"DesktopImposer-{version}.exe"
    suffix = Path(name).suffix.lower()
    if suffix not in ALLOWED_INSTALLER_SUFFIXES:
        raise ValueError(f"unsupported update package type: {suffix}")
    expected = expected_sha256.strip().lower()
    if len(expected) != 64 or any(c not in "0123456789abcdef" for c in expected):
        raise ValueError("invalid expected SHA-256")

    root = Path(staging_dir) if staging_dir else data_dir() / "updates" / version
    root.mkdir(parents=True, exist_ok=True)
    final = root / name
    temp = final.with_suffix(final.suffix + ".download")
    temp.unlink(missing_ok=True)

    req = urllib.request.Request(download_url, headers={"User-Agent": "DesktopImposerUpdater/2.1"})
    h = hashlib.sha256()
    with urllib.request.urlopen(req, timeout=timeout) as resp, temp.open("wb") as out:
        while True:
            block = resp.read(1024 * 1024)
            if not block:
                break
            h.update(block)
            out.write(block)
        out.flush()
        os.fsync(out.fileno())
    actual = h.hexdigest()
    if actual != expected:
        temp.unlink(missing_ok=True)
        raise ValueError("download SHA-256 mismatch")
    temp.replace(final)
    metadata = root / "staged-update.json"
    metadata.write_text(json.dumps({
        "version": version,
        "package": final.name,
        "sha256": actual,
        "source": download_url,
        "ready": True,
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    return StagedUpdate(version, str(final), actual, str(metadata))
