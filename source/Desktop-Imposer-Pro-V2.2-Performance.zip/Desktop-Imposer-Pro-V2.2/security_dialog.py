from __future__ import annotations

from access_control import ROLE_PERMISSIONS, UserSession, UserStore

try:
    from PySide6.QtWidgets import (
        QComboBox, QDialog, QDialogButtonBox, QFormLayout, QHBoxLayout, QLabel,
        QLineEdit, QMessageBox, QPushButton, QTableWidget, QTableWidgetItem,
        QVBoxLayout,
    )
except ImportError:
    QDialog = object

if QDialog is not object:
    class LoginDialog(QDialog):
        def __init__(self, store: UserStore, parent=None):
            super().__init__(parent)
            self.store = store
            self.session: UserSession | None = None
            self.setWindowTitle("登录")
            form = QFormLayout(self)
            self.username = QLineEdit()
            self.password = QLineEdit(); self.password.setEchoMode(QLineEdit.Password)
            form.addRow("用户名", self.username); form.addRow("密码", self.password)
            buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
            buttons.accepted.connect(self._login); buttons.rejected.connect(self.reject)
            form.addRow(buttons)
        def _login(self):
            session = self.store.authenticate(self.username.text(), self.password.text())
            if not session:
                QMessageBox.warning(self, "登录失败", "用户名或密码不正确，或账户已停用。")
                return
            self.session = session; self.accept()

    class FirstAdminDialog(QDialog):
        def __init__(self, store: UserStore, parent=None):
            super().__init__(parent); self.store = store; self.session = None
            self.setWindowTitle("首次启动 · 创建管理员")
            form = QFormLayout(self)
            tip = QLabel("V2.1 不提供默认管理员密码。请创建本机管理员账户。")
            tip.setWordWrap(True); form.addRow(tip)
            self.username = QLineEdit("admin")
            self.display_name = QLineEdit("系统管理员")
            self.password = QLineEdit(); self.password.setEchoMode(QLineEdit.Password)
            self.confirm = QLineEdit(); self.confirm.setEchoMode(QLineEdit.Password)
            form.addRow("用户名", self.username); form.addRow("显示名称", self.display_name)
            form.addRow("密码（至少8位）", self.password); form.addRow("确认密码", self.confirm)
            buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
            buttons.accepted.connect(self._create); buttons.rejected.connect(self.reject); form.addRow(buttons)
        def _create(self):
            if self.password.text() != self.confirm.text():
                QMessageBox.warning(self, "密码", "两次输入的密码不一致。")
                return
            try:
                self.store.create_user(self.username.text(), self.password.text(), "admin", self.display_name.text())
                self.session = self.store.authenticate(self.username.text(), self.password.text())
            except Exception as exc:
                QMessageBox.critical(self, "创建失败", str(exc)); return
            self.accept()

    class UserManagementDialog(QDialog):
        def __init__(self, store: UserStore, parent=None):
            super().__init__(parent); self.store = store
            self.setWindowTitle("用户与权限"); self.resize(720, 440)
            outer = QVBoxLayout(self)
            self.table = QTableWidget(0, 5)
            self.table.setHorizontalHeaderLabels(["ID", "用户名", "显示名称", "角色", "状态"])
            outer.addWidget(self.table)
            row = QHBoxLayout(); add = QPushButton("新增用户"); refresh = QPushButton("刷新"); close = QPushButton("关闭")
            add.clicked.connect(self._add); refresh.clicked.connect(self.refresh); close.clicked.connect(self.accept)
            row.addWidget(add); row.addWidget(refresh); row.addStretch(); row.addWidget(close); outer.addLayout(row)
            self.refresh()
        def refresh(self):
            users = self.store.list_users(); self.table.setRowCount(len(users))
            for r, u in enumerate(users):
                vals = [u["id"], u["username"], u["display_name"], u["role"], "启用" if u["enabled"] else "停用"]
                for c, v in enumerate(vals): self.table.setItem(r, c, QTableWidgetItem(str(v)))
        def _add(self):
            dlg = QDialog(self); dlg.setWindowTitle("新增用户")
            form = QFormLayout(dlg); username = QLineEdit(); display = QLineEdit(); password = QLineEdit(); password.setEchoMode(QLineEdit.Password)
            role = QComboBox(); role.addItems(list(ROLE_PERMISSIONS))
            form.addRow("用户名", username); form.addRow("显示名称", display); form.addRow("密码", password); form.addRow("角色", role)
            buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel); buttons.accepted.connect(dlg.accept); buttons.rejected.connect(dlg.reject); form.addRow(buttons)
            if dlg.exec() != QDialog.Accepted: return
            try: self.store.create_user(username.text(), password.text(), role.currentText(), display.text())
            except Exception as exc: QMessageBox.critical(self, "新增失败", str(exc)); return
            self.refresh()
