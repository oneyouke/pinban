from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

parser = argparse.ArgumentParser()
parser.add_argument("--strict", action="store_true", help="fail on release placeholders")
args = parser.parse_args()
ROOT = Path(__file__).resolve().parent
errors = []
warnings = []

# Never ship private licensing material.
for pattern in ("*private*.pem", "*.p12", "*.pfx", "*.key"):
    for p in ROOT.glob(pattern):
        errors.append(f"检测到禁止进入客户端包的私钥/证书文件：{p.name}")

pub = ROOT / "vendor_public_key.pem"
try:
    key = serialization.load_pem_public_key(pub.read_bytes())
    if not isinstance(key, Ed25519PublicKey):
        errors.append("vendor_public_key.pem 不是 Ed25519 公钥")
except Exception as exc:
    errors.append(f"商业授权公钥不可用：{exc}")

product_text = (ROOT / "product.py").read_text(encoding="utf-8")
if 'APP_ID = "com.yourcompany.desktopimposer.pro"' in product_text:
    (errors if args.strict else warnings).append("APP_ID 仍为 com.yourcompany...，正式发布前应换成你的反向域名产品 ID")
if 'VENDOR_NAME = "Your Company"' in product_text:
    (errors if args.strict else warnings).append("VENDOR_NAME 仍为 Your Company，正式发布前应替换为你的公司/品牌")
if 'SUPPORT_EMAIL = "support@example.com"' in product_text:
    (errors if args.strict else warnings).append("SUPPORT_EMAIL 仍为示例地址")
installer_text = (ROOT / "installer.iss").read_text(encoding="utf-8") if (ROOT / "installer.iss").exists() else ""
if 'MyAppPublisher "Your Company"' in installer_text:
    (errors if args.strict else warnings).append("installer.iss 的 Publisher 仍为 Your Company")
eula = (ROOT / "EULA_TEMPLATE.txt").read_text(encoding="utf-8") if (ROOT / "EULA_TEMPLATE.txt").exists() else ""
if "[LEGAL COMPANY NAME]" in eula:
    (errors if args.strict else warnings).append("EULA 仍是模板，正式发布前必须由真实条款替换")

req = (ROOT / "requirements.txt").read_text(encoding="utf-8")
for required in ("PySide6", "pypdf", "reportlab", "Pillow", "openpyxl", "cryptography"):
    if required not in req:
        errors.append(f"requirements.txt 缺少 {required}")

for name in ("THIRD_PARTY_NOTICES.md", "EULA_TEMPLATE.txt", "COMMERCIAL_RELEASE_CHECKLIST.md"):
    if not (ROOT / name).exists():
        errors.append(f"缺少发布文档：{name}")

print("Commercial release gate")
for w in warnings:
    print("WARN:", w)
for e in errors:
    print("ERROR:", e)
if errors:
    sys.exit(1)
print("PASS")
