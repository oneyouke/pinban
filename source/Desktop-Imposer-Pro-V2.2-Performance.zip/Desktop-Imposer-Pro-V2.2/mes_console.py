from __future__ import annotations

from PySide6.QtCore import QTimer
from PySide6.QtWidgets import (
    QComboBox, QDialog, QHBoxLayout, QLabel, QLineEdit, QMessageBox, QPushButton,
    QSpinBox, QTableWidget, QTableWidgetItem, QTabWidget, QVBoxLayout, QWidget,
)

from device_center import DeviceRegistry
from mes import MESManager
from production_scheduler import ProductionScheduler
from storage import ProductionDB


class MESConsoleDialog(QDialog):
    """V1.5 shop-floor MES console: planning, reporting, OEE and scan actions."""

    def __init__(self, db: ProductionDB, registry: DeviceRegistry, parent=None):
        super().__init__(parent)
        self.db = db
        self.registry = registry
        self.scheduler = ProductionScheduler(db, registry)
        self.mes = MESManager(db, registry, self.scheduler)
        self.setWindowTitle("车间 MES 控制台 · V1.5")
        self.resize(1260, 760)
        self._build()
        self.refresh_all()
        self.timer = QTimer(self); self.timer.setInterval(5000); self.timer.timeout.connect(self.refresh_all); self.timer.start()

    def _build(self):
        root = QVBoxLayout(self)
        head = QHBoxLayout()
        self.summary = QLabel("MES 状态")
        self.operator = QLineEdit(); self.operator.setPlaceholderText("操作员")
        self.balance_btn = QPushButton("多机负载平衡")
        self.gantt_btn = QPushButton("重算甘特排程")
        self.refresh_btn = QPushButton("刷新")
        head.addWidget(self.summary); head.addStretch(); head.addWidget(self.operator)
        head.addWidget(self.balance_btn); head.addWidget(self.gantt_btn); head.addWidget(self.refresh_btn)
        root.addLayout(head)
        self.tabs = QTabWidget(); root.addWidget(self.tabs, 1)
        self._build_runs(); self._build_oee(); self._build_scan()
        self.balance_btn.clicked.connect(self.balance)
        self.gantt_btn.clicked.connect(self.rebuild_gantt)
        self.refresh_btn.clicked.connect(self.refresh_all)

    def _build_runs(self):
        page = QWidget(); layout = QVBoxLayout(page)
        row = QHBoxLayout()
        self.start_btn = QPushButton("开工"); self.finish_btn = QPushButton("完工"); self.report_btn = QPushButton("报工")
        self.stop_btn = QPushButton("开始停机"); self.resume_btn = QPushButton("结束停机")
        self.stop_reason = QComboBox(); self.stop_reason.addItems(["换纸", "换版", "设备故障", "等料", "等版", "质量调整", "清洗保养", "其他"])
        self.good = QSpinBox(); self.good.setRange(0, 100000000); self.waste = QSpinBox(); self.waste.setRange(0, 100000000)
        self.sheets = QSpinBox(); self.sheets.setRange(0, 100000000)
        row.addWidget(self.start_btn); row.addWidget(self.finish_btn); row.addWidget(QLabel("良品")); row.addWidget(self.good)
        row.addWidget(QLabel("废品")); row.addWidget(self.waste); row.addWidget(QLabel("完成印张")); row.addWidget(self.sheets); row.addWidget(self.report_btn)
        row.addWidget(self.stop_reason); row.addWidget(self.stop_btn); row.addWidget(self.resume_btn)
        layout.addLayout(row)
        self.run_table = QTableWidget(0, 12)
        self.run_table.setHorizontalHeaderLabels(["Run","队列","订单","设备","状态","计划开始","计划结束","实际开始","实际结束","目标印张","完成印张","操作员"])
        layout.addWidget(self.run_table, 1)
        self.start_btn.clicked.connect(self.start_selected); self.finish_btn.clicked.connect(self.finish_selected); self.report_btn.clicked.connect(self.report_selected)
        self.stop_btn.clicked.connect(self.start_downtime); self.resume_btn.clicked.connect(self.end_downtime)
        self.tabs.addTab(page, "生产执行")

    def _build_oee(self):
        page = QWidget(); layout = QVBoxLayout(page)
        row = QHBoxLayout(); self.oee_device = QComboBox(); self.oee_refresh = QPushButton("刷新 OEE")
        row.addWidget(QLabel("设备")); row.addWidget(self.oee_device); row.addWidget(self.oee_refresh); row.addStretch(); layout.addLayout(row)
        self.oee_table = QTableWidget(0, 9)
        self.oee_table.setHorizontalHeaderLabels(["设备","OEE","开动率","性能","质量","计划分钟","运行分钟","停机分钟","良/废"])
        layout.addWidget(self.oee_table, 1)
        self.oee_refresh.clicked.connect(self.refresh_oee)
        self.tabs.addTab(page, "OEE")

    def _build_scan(self):
        page = QWidget(); layout = QVBoxLayout(page)
        layout.addWidget(QLabel("支持扫码枪直接输入 DIMES V1 工单码。START/FINISH/REPORT 可用于车间开工、完工与报工。"))
        row = QHBoxLayout(); self.scan = QLineEdit(); self.scan.setPlaceholderText("DIMES|1|RUN=12|ACTION=START")
        self.scan_exec = QPushButton("执行扫码"); row.addWidget(self.scan,1); row.addWidget(self.scan_exec); layout.addLayout(row)
        self.scan_result = QLabel("等待扫码"); layout.addWidget(self.scan_result); layout.addStretch()
        self.scan_exec.clicked.connect(self.execute_scan); self.scan.returnPressed.connect(self.execute_scan)
        self.tabs.addTab(page, "扫码报工")

    def selected_run_id(self):
        row = self.run_table.currentRow()
        if row < 0 or not self.run_table.item(row,0): return None
        return int(self.run_table.item(row,0).text())

    def rebuild_gantt(self):
        try:
            estimates = self.mes.build_gantt(persist=True)
            self.refresh_all(); QMessageBox.information(self,"甘特排程",f"已重算 {len(estimates)} 个计划工单。")
        except Exception as exc: QMessageBox.warning(self,"排程失败",str(exc))

    def balance(self):
        try:
            rows = self.mes.auto_balance(); self.mes.build_gantt(persist=True); self.refresh_all()
            QMessageBox.information(self,"多机负载平衡",f"已自动派机 {len(rows)} 个任务。")
        except Exception as exc: QMessageBox.warning(self,"负载平衡失败",str(exc))

    def start_selected(self):
        rid=self.selected_run_id()
        if rid is None: return
        try: self.mes.start_run(rid,self.operator.text().strip()); self.refresh_all()
        except Exception as exc: QMessageBox.warning(self,"开工失败",str(exc))

    def report_selected(self):
        rid=self.selected_run_id()
        if rid is None: return
        try:
            self.mes.report_progress(rid,completed_sheets=self.sheets.value(),good_count=self.good.value(),waste_count=self.waste.value(),operator=self.operator.text().strip()); self.refresh_all()
        except Exception as exc: QMessageBox.warning(self,"报工失败",str(exc))

    def finish_selected(self):
        rid=self.selected_run_id()
        if rid is None: return
        try:
            self.mes.complete_run(rid,completed_sheets=self.sheets.value(),good_count=self.good.value(),waste_count=self.waste.value(),operator=self.operator.text().strip()); self.refresh_all()
        except Exception as exc: QMessageBox.warning(self,"完工失败",str(exc))

    def start_downtime(self):
        rid=self.selected_run_id()
        if rid is None: return
        try:
            reason=self.stop_reason.currentText().strip()
            self.mes.begin_downtime(rid,reason,reason); self.refresh_all()
        except Exception as exc: QMessageBox.warning(self,"停机登记失败",str(exc))

    def end_downtime(self):
        rid=self.selected_run_id()
        if rid is None: return
        try:
            row=self.mes.open_downtime(rid)
            if not row: raise ValueError("当前工单没有未结束停机事件")
            minutes=self.mes.end_downtime(int(row["id"])); self.refresh_all()
            QMessageBox.information(self,"恢复生产",f"本次停机 {minutes:.1f} 分钟")
        except Exception as exc: QMessageBox.warning(self,"恢复失败",str(exc))

    def execute_scan(self):
        try:
            result=self.mes.execute_scan(self.scan.text().strip(),operator=self.operator.text().strip(),completed_sheets=self.sheets.value(),good_count=self.good.value(),waste_count=self.waste.value())
            self.scan_result.setText(f"已执行 {result['action']} · Run {result['run_id']}"); self.scan.clear(); self.refresh_all()
        except Exception as exc: QMessageBox.warning(self,"扫码失败",str(exc))

    def refresh_all(self):
        runs=self.mes.list_runs()
        self.summary.setText(f"MES Run {len(runs)} · 生产中 {sum(1 for r in runs if r['status']=='running')} · 已完成 {sum(1 for r in runs if r['status']=='completed')}")
        self.run_table.setRowCount(0)
        device_names={d.id:d.name for d in self.registry.load()}
        for run in runs:
            r=self.run_table.rowCount(); self.run_table.insertRow(r)
            vals=[run['id'],run['queue_job_id'],run['order_id'],device_names.get(run['device_id'],run['device_id']),run['status'],run['planned_start'],run['planned_end'],run['actual_start'],run['actual_end'],run['target_sheets'],run['completed_sheets'],run['operator']]
            for c,v in enumerate(vals): self.run_table.setItem(r,c,QTableWidgetItem(str(v)))
        self.run_table.resizeColumnsToContents()
        self.oee_device.clear(); self.oee_device.addItem("全部设备","")
        for d in self.registry.load(): self.oee_device.addItem(d.name,d.id)
        self.refresh_oee()

    def refresh_oee(self):
        selected=str(self.oee_device.currentData() or "") if self.oee_device.count() else ""
        devices=[d for d in self.registry.load() if not selected or d.id==selected]
        self.oee_table.setRowCount(0)
        for d in devices:
            rep=self.mes.oee(d.id); r=self.oee_table.rowCount(); self.oee_table.insertRow(r)
            vals=[d.name,f"{rep.oee:.2f}%",f"{rep.availability:.2f}%",f"{rep.performance:.2f}%",f"{rep.quality:.2f}%",rep.planned_minutes,rep.run_minutes,rep.downtime_minutes,f"{rep.good_count}/{rep.waste_count}"]
            for c,v in enumerate(vals): self.oee_table.setItem(r,c,QTableWidgetItem(str(v)))
        self.oee_table.resizeColumnsToContents()
