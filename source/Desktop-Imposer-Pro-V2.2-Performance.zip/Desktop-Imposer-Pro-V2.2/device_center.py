from __future__ import annotations

from dataclasses import asdict, dataclass, field
from pathlib import Path
import json


@dataclass
class DeviceProfile:
    id: str
    name: str
    kind: str = "press"  # press / ctp / rip / digital
    vendor: str = ""
    model: str = ""
    enabled: bool = True
    min_sheet_width_mm: float = 0.0
    min_sheet_height_mm: float = 0.0
    max_sheet_width_mm: float = 0.0
    max_sheet_height_mm: float = 0.0
    colors: int = 4
    production_speed_sph: float = 0.0
    setup_minutes: float = 0.0
    hourly_cost: float = 0.0
    shift_minutes_per_day: int = 480
    oee_target: float = 85.0
    gripper_mm: float = 0.0
    tail_mm: float = 0.0
    side_lay_left_mm: float = 0.0
    side_lay_right_mm: float = 0.0
    duplex_mode: str = "long_edge"
    rip_hotfolder: str = ""
    jmf_url: str = ""
    jdf_hotfolder: str = ""
    notes: str = ""
    capabilities: dict = field(default_factory=dict)

    def validate_sheet(self, width_mm: float, height_mm: float) -> list[str]:
        issues: list[str] = []
        if self.min_sheet_width_mm and width_mm < self.min_sheet_width_mm:
            issues.append(f"纸张宽 {width_mm:g} mm 小于设备最小宽度 {self.min_sheet_width_mm:g} mm")
        if self.min_sheet_height_mm and height_mm < self.min_sheet_height_mm:
            issues.append(f"纸张高 {height_mm:g} mm 小于设备最小高度 {self.min_sheet_height_mm:g} mm")
        if self.max_sheet_width_mm and width_mm > self.max_sheet_width_mm:
            issues.append(f"纸张宽 {width_mm:g} mm 超过设备最大宽度 {self.max_sheet_width_mm:g} mm")
        if self.max_sheet_height_mm and height_mm > self.max_sheet_height_mm:
            issues.append(f"纸张高 {height_mm:g} mm 超过设备最大高度 {self.max_sheet_height_mm:g} mm")
        return issues

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> "DeviceProfile":
        allowed = set(cls.__dataclass_fields__)
        return cls(**{k: v for k, v in data.items() if k in allowed})


DEFAULT_PROFILES = [
    DeviceProfile(
        id="offset-sra3",
        name="SRA3 四色胶印机",
        kind="press",
        max_sheet_width_mm=450,
        max_sheet_height_mm=320,
        colors=4,
        gripper_mm=10,
        tail_mm=5,
        side_lay_left_mm=5,
        side_lay_right_mm=5,
    ),
    DeviceProfile(
        id="digital-sra3",
        name="SRA3 数码印刷机",
        kind="digital",
        max_sheet_width_mm=330,
        max_sheet_height_mm=488,
        colors=4,
        gripper_mm=3,
        tail_mm=3,
        side_lay_left_mm=3,
        side_lay_right_mm=3,
    ),
]


class DeviceRegistry:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self.save(DEFAULT_PROFILES)

    def load(self) -> list[DeviceProfile]:
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except Exception:
            return [DeviceProfile.from_dict(p.to_dict()) for p in DEFAULT_PROFILES]
        if isinstance(data, dict):
            data = data.get("devices", [])
        return [DeviceProfile.from_dict(item) for item in data if isinstance(item, dict)]

    def save(self, profiles: list[DeviceProfile]) -> None:
        payload = {"schema": 1, "devices": [p.to_dict() for p in profiles]}
        tmp = self.path.with_suffix(self.path.suffix + ".tmp")
        tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(self.path)

    def get(self, device_id: str) -> DeviceProfile | None:
        return next((p for p in self.load() if p.id == device_id), None)

    def upsert(self, profile: DeviceProfile) -> None:
        profiles = self.load()
        for i, existing in enumerate(profiles):
            if existing.id == profile.id:
                profiles[i] = profile
                break
        else:
            profiles.append(profile)
        self.save(profiles)

    def delete(self, device_id: str) -> bool:
        profiles = self.load()
        filtered = [p for p in profiles if p.id != device_id]
        if len(filtered) == len(profiles):
            return False
        self.save(filtered)
        return True
