from __future__ import annotations

import json
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta, timezone
from pathlib import Path

from app_paths import backup_dir, config_dir
from backup_restore import create_backup


@dataclass
class BackupPolicy:
    enabled: bool = True
    interval_hours: int = 24
    keep_last: int = 14
    include_logs: bool = False

    def validate(self) -> None:
        if self.interval_hours < 1:
            raise ValueError("interval_hours must be >= 1")
        if self.keep_last < 1:
            raise ValueError("keep_last must be >= 1")


class ScheduledBackupService:
    def __init__(self, policy_path: str | Path | None = None, destination: str | Path | None = None) -> None:
        self.policy_path = Path(policy_path) if policy_path else config_dir() / "backup_policy.json"
        self.destination = Path(destination) if destination else backup_dir()
        self.destination.mkdir(parents=True, exist_ok=True)

    def load_policy(self) -> BackupPolicy:
        if not self.policy_path.exists():
            return BackupPolicy()
        doc = json.loads(self.policy_path.read_text(encoding="utf-8"))
        policy = BackupPolicy(**{k: doc[k] for k in asdict(BackupPolicy()) if k in doc})
        policy.validate()
        return policy

    def save_policy(self, policy: BackupPolicy) -> None:
        policy.validate()
        self.policy_path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.policy_path.with_suffix(".tmp")
        tmp.write_text(json.dumps(asdict(policy), ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(self.policy_path)

    def _backups(self) -> list[Path]:
        return sorted(self.destination.glob("auto-*.dibackup"), key=lambda p: p.stat().st_mtime, reverse=True)

    def due(self, policy: BackupPolicy | None = None, now: datetime | None = None) -> bool:
        policy = policy or self.load_policy()
        if not policy.enabled:
            return False
        now = now or datetime.now(timezone.utc)
        backups = self._backups()
        if not backups:
            return True
        last = datetime.fromtimestamp(backups[0].stat().st_mtime, tz=timezone.utc)
        return now - last >= timedelta(hours=policy.interval_hours)

    def run_if_due(self, policy: BackupPolicy | None = None) -> dict:
        policy = policy or self.load_policy()
        if not self.due(policy):
            return {"created": False, "reason": "not_due"}
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        path = self.destination / f"auto-{stamp}.dibackup"
        info = create_backup(path, include_logs=policy.include_logs)
        backups = self._backups()
        for old in backups[policy.keep_last:]:
            old.unlink(missing_ok=True)
        return {"created": True, **info}
