# V1.0 商业发布闸门

## 必须完成

- [ ] 把 `product.py` 中公司/品牌、支持邮箱改为真实信息。
- [ ] 在安全、离线的授权电脑运行 `python license_admin.py generate-keypair`；**私钥只保存在授权后台/离线介质**，只把公钥复制到客户端源码的 `vendor_public_key.pem`。
- [ ] 确认安装包、源码仓库、CI artifact 中绝无私钥/PFX/P12。
- [ ] 决定 Qt 许可路径：购买 Qt Commercial，或由法律/工程共同确认满足 LGPLv3 的动态链接、替换库与 notice 等义务。
- [ ] 对最终打包环境生成 SBOM/第三方许可证清单并归档。
- [ ] 替换并经律师审阅 `EULA_TEMPLATE.txt`。
- [ ] 购买并配置 Windows 代码签名证书，签名 EXE 与安装包并使用可信时间戳。
- [ ] 在干净的 Windows 10/11 x64 机器测试安装、卸载、升级、无 Python 环境启动、中文路径、长路径、网络断开。
- [ ] 做真实印刷样张验收：1:1 尺寸、出血、正反、裁切线、专色、可变码、不同 RIP。
- [ ] 建立客户数据/日志保留策略与隐私说明。

## PDF 专业引擎边界

当前内置引擎可以做拼版、页面/字体/颜色/图像 DPI/部分图形状态风险扫描，但**不应宣称**它完成 ISO PDF/X 合规认证、ICC 转换、透明度扁平化、陷印或 RIP 等价预检。

商业客户如果要求“PDF/X-1a / PDF/X-4 认证与修复”，应接入一个单独采购/许可的专业 PDF preflight SDK，并通过 `ProfessionalPreflightProvider` 类接口接入；不要把基础扫描结果包装成“标准认证通过”。

## 版本发布

1. 运行 `python test_engine.py`
2. 运行 `python test_commercial.py`
3. 运行 `python release_gate.py`
4. `pyinstaller --noconfirm --clean DesktopImposer.spec`
5. 在干净 Windows 机验收 EXE
6. 用 `build_release.ps1` 签名并构建安装包
7. 对安装包生成 SHA-256，保存发布记录和 SBOM
