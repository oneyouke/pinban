# V1.3 设备与系统集成说明

## 设备配置中心

设备档案保存在用户配置目录 `devices.json`，默认不与客户 PDF 混放。字段包含：设备类型、厂商/型号、最小/最大纸张、色数、咬口/拖梢/左右规、双面模式、RIP Hot Folder、JDF Hot Folder、JMF URL 与扩展 capabilities。

## JMF

`jmf.py` 提供 Status Query 构建、状态响应解析和 HTTP POST。不同厂商 JMF 实现并不完全一致，因此这里是 CIP4/JDFSchema 1.1 namespace 下的互操作基线，不宣称设备认证。生产接机时应保存厂商示例报文并加入回归测试。

## CIP3 墨键区

`cip3_ink.py` 的核心算法接收分色灰度图：白色为 0% 墨、黑色为 100% 墨，并按横向墨键区计算平均覆盖率。可配置 16/24/32/40 等区域数。

如系统安装 Ghostscript，可用 `tiffsep` 生成 CMYK 分色预览。此结果与具体 RIP 的 ICC、黑版生成、套印和透明度处理可能不同，因此正式用于墨键预置前必须针对印刷机/RIP 做标定。

## ERP API

默认仅监听 `127.0.0.1`：

- `GET /health`
- `POST /v1/jobs`

生产环境若要开放到局域网，建议放在反向代理后面并启用 TLS、访问控制、Bearer Token 与网络白名单。不要直接把桌面进程暴露到公网。

## 刀版库

刀版按 SHA-256 去重，索引可记录客户、产品编码、尺寸与刀线专色名。它负责资产管理，不替代 `dieline.py` 的矢量路径提取和 `nesting.py` 的碰撞计算。
