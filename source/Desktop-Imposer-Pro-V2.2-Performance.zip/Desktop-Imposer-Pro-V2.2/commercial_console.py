from __future__ import annotations

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QTabWidget, QWidget, QTableWidget, QTableWidgetItem,
    QPushButton, QHBoxLayout, QLabel, QHeaderView
)
from sales_finance import SalesFinanceManager


class CommercialConsoleDialog(QDialog):
    def __init__(self, db, parent=None):
        super().__init__(parent)
        self.setWindowTitle('销售与财务协同控制台 · V1.9')
        self.resize(1250, 780)
        self.m = SalesFinanceManager(db)
        root = QVBoxLayout(self)
        self.summary = QLabel()
        self.summary.setWordWrap(True)
        root.addWidget(self.summary)
        self.tabs = QTabWidget(); root.addWidget(self.tabs, 1)

        self.q = self._tab('报价', ['报价单','客户','状态','未税','税','总额','预计毛利'])
        self.ap = self._tab('报价审批', ['ID','报价单','状态','申请人','审批人','原因','申请时间','决定时间'])
        self.o = self._tab('销售订单', ['订单','客户','状态','总额','预计成本','交期','生产任务'])
        self.cr = self._tab('信用控制', ['订单','客户','状态','信用额度','未收应收','逾期','信用状态'])
        self.ar = self._tab('客户对账', ['发票','订单','客户','金额','已收','未收','到期日','状态'])
        self.po = self._tab('供应商/采购', ['采购单','供应商','状态','总额','已付','未付','预计到货'])
        self.cm = self._tab('业务员提成', ['ID','订单','业务员','基数','基数金额','比例','提成','状态'])
        self.pf = self._tab('订单盈亏排行', ['排名','订单','收入','预计成本','实际成本','利润','实际毛利率'])
        self.cf = self._tab('90天现金流', ['期间','预计流入','预计流出','净现金流'])

        bar = QHBoxLayout()
        b = QPushButton('刷新'); b.clicked.connect(self.refresh_all); bar.addWidget(b)
        bar.addStretch(); root.addLayout(bar)
        self.refresh_all()

    def _tab(self, title, headers):
        w = QWidget(); l = QVBoxLayout(w)
        t = QTableWidget(0, len(headers)); t.setHorizontalHeaderLabels(headers)
        t.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
        t.setAlternatingRowColors(True)
        l.addWidget(t); self.tabs.addTab(w, title); return t

    @staticmethod
    def _fill(t, rows):
        t.setRowCount(len(rows))
        for r, row in enumerate(rows):
            for c, v in enumerate(row):
                t.setItem(r, c, QTableWidgetItem(str(v)))

    def refresh_all(self):
        d = self.m.executive_dashboard()
        self.summary.setText(
            f"销售额 ¥{d['revenue']:.2f}  |  应收 ¥{d['accounts_receivable']:.2f}  |  "
            f"逾期 ¥{d['overdue_receivable']:.2f}  |  实际利润 ¥{d['actual_profit']:.2f}  |  "
            f"毛利率 {d['actual_margin']*100:.1f}%  |  待审批 {d['pending_approvals']}  |  "
            f"信用冻结 {d['credit_holds']}  |  待结提成 ¥{d['accrued_commissions']:.2f}  |  "
            f"90天净现金流 ¥{d['cashflow_90d_net']:.2f}"
        )
        with self.m.db.connect() as c:
            q = c.execute('SELECT quote_id,customer_id,status,subtotal,tax,total,estimated_margin FROM quotes ORDER BY created_at DESC').fetchall()
            ap = c.execute('SELECT id,quote_id,status,requested_by,approver,reason,requested_at,decided_at FROM quote_approvals ORDER BY id DESC').fetchall()
            o = c.execute("SELECT order_id,customer_id,status,total,estimated_cost,due_at,COALESCE(production_job_id,'') FROM sales_orders ORDER BY created_at DESC").fetchall()
            ar = c.execute('SELECT invoice_id,order_id,customer_id,amount,paid,(amount-paid),due_date,status FROM receivables ORDER BY created_at DESC').fetchall()
            po = c.execute("""SELECT po.po_id,po.supplier,po.status,po.total,
                       COALESCE((SELECT SUM(sp.amount) FROM supplier_payments sp WHERE sp.po_id=po.po_id),0) paid,
                       po.total-COALESCE((SELECT SUM(sp.amount) FROM supplier_payments sp WHERE sp.po_id=po.po_id),0) balance,
                       po.expected_at FROM purchase_orders po ORDER BY po.created_at DESC""").fetchall()
            cm = c.execute('SELECT id,order_id,salesperson_id,basis,basis_amount,rate,commission,status FROM commission_accruals ORDER BY id DESC').fetchall()
            orders = [dict(r) for r in c.execute('SELECT order_id,customer_id,status FROM sales_orders ORDER BY created_at DESC').fetchall()]

        self._fill(self.q, [(x['quote_id'],x['customer_id'],x['status'],x['subtotal'],x['tax'],x['total'],f"{x['estimated_margin']*100:.1f}%") for x in q])
        self._fill(self.ap, [tuple(x) for x in ap])
        self._fill(self.o, [tuple(x) for x in o])

        credit_rows = []
        for order in orders:
            try:
                cd = self.m.credit_decision(order['customer_id'])
                credit_rows.append((order['order_id'],order['customer_id'],order['status'],cd.credit_limit,cd.outstanding,cd.overdue,'通过' if cd.approved else cd.reason))
            except Exception as exc:
                credit_rows.append((order['order_id'],order['customer_id'],order['status'],'','','',str(exc)))
        self._fill(self.cr, credit_rows)
        self._fill(self.ar, [tuple(x) for x in ar]); self._fill(self.po, [tuple(x) for x in po])
        self._fill(self.cm, [(x['id'],x['order_id'],x['salesperson_id'],x['basis'],x['basis_amount'],f"{x['rate']*100:.2f}%",x['commission'],x['status']) for x in cm])

        ranking = self.m.profit_ranking()
        self._fill(self.pf, [(i+1,x['order_id'],x['revenue'],x['estimated_cost'],x['actual_cost'],x['profit'],f"{x['margin']*100:.1f}%") for i,x in enumerate(ranking)])
        forecast = self.m.cashflow_forecast(90,30)
        self._fill(self.cf, [(f"{x['start']} ~ {x['end']}",x['inflow'],x['outflow'],x['net']) for x in forecast])
