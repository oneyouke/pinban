from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any
from inventory import InventoryManager
from routing import RoutingManager
from storage import ProductionDB

@dataclass(frozen=True)
class ProductionPathScore:
    route_name:str
    total_minutes:float
    estimated_cost:float
    inventory_ok:bool
    tardiness_minutes:float
    score:float
    reasons:tuple[str,...]

class SmartFactoryOptimizer:
    def __init__(self,db:ProductionDB,inventory:InventoryManager,routing:RoutingManager): self.db=db; self.inventory=inventory; self.routing=routing
    def score_path(self,queue_job_id:int,route_name:str,qty:int,material_requirements:dict[str,float],due_at:str='',margin:float=0)->ProductionPathScore:
        reasons=[]; inventory_ok=True
        for sku,need in material_requirements.items():
            item=self.inventory.get(sku)
            if not item or item.available<need:
                inventory_ok=False; reasons.append(f'{sku} 库存不足')
        plan=self.routing.plan_job(queue_job_id,route_name,qty)
        if plan:
            start=datetime.fromisoformat(plan[0]['planned_start']); end=datetime.fromisoformat(plan[-1]['planned_end']); mins=(end-start).total_seconds()/60
        else: mins=0
        cost=0.0
        for r in plan:
            # infer hourly cost from registry
            d=self.routing.registry.get(r['device_id'])
            if d:
                dur=(datetime.fromisoformat(r['planned_end'])-datetime.fromisoformat(r['planned_start'])).total_seconds()/3600
                cost+=dur*max(0,d.hourly_cost)
        tardy=0.0
        if due_at:
            due=datetime.fromisoformat(due_at.replace('Z','+00:00'))
            if due.tzinfo is None: due=due.replace(tzinfo=timezone.utc)
            end=datetime.fromisoformat(plan[-1]['planned_end']) if plan else datetime.now(timezone.utc)
            tardy=max(0,(end-due).total_seconds()/60)
        score=10000 - mins*0.8 - cost*0.5 - tardy*8 + max(0,margin)*2
        if not inventory_ok: score-=5000
        reasons.append(f'预计 {mins:.1f} 分钟'); reasons.append(f'设备成本约 {cost:.2f}');
        if tardy: reasons.append(f'预计逾期 {tardy:.1f} 分钟')
        if inventory_ok: reasons.append('物料充足')
        return ProductionPathScore(route_name,round(mins,2),round(cost,2),inventory_ok,round(tardy,2),round(score,2),tuple(reasons))
    def choose_best(self,*candidates:ProductionPathScore)->ProductionPathScore:
        if not candidates: raise ValueError('没有可选生产路径')
        return max(candidates,key=lambda x:x.score)
