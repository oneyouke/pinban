from __future__ import annotations

SUPPORTED_LOCALES = ("zh_CN", "en_US")

_STRINGS = {
    "zh_CN": {
        "app.home": "工作台",
        "app.prepress": "印前拼版",
        "app.production": "生产控制台",
        "app.mes": "车间 MES",
        "app.factory": "智能工厂",
        "app.commercial": "商业运营",
        "app.admin": "系统管理",
        "backup.create": "创建备份",
        "backup.restore": "恢复备份",
        "users.manage": "用户与权限",
        "help.center": "帮助中心",
    },
    "en_US": {
        "app.home": "Workspace",
        "app.prepress": "Prepress & Imposition",
        "app.production": "Production Console",
        "app.mes": "Shop-floor MES",
        "app.factory": "Smart Factory",
        "app.commercial": "Commercial Operations",
        "app.admin": "Administration",
        "backup.create": "Create Backup",
        "backup.restore": "Restore Backup",
        "users.manage": "Users & Permissions",
        "help.center": "Help Center",
    },
}

class Translator:
    def __init__(self, locale: str = "zh_CN") -> None:
        if locale not in SUPPORTED_LOCALES:
            locale = "zh_CN"
        self.locale = locale

    def tr(self, key: str, **kwargs) -> str:
        text = _STRINGS.get(self.locale, {}).get(key) or _STRINGS["zh_CN"].get(key) or key
        return text.format(**kwargs) if kwargs else text
