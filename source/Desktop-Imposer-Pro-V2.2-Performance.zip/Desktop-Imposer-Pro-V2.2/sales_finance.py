from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, timedelta
from typing import Any

from commercial import CommercialManager
from storage import ProductionDB, utc_now


@dataclass(frozen=True)
class CreditDecision:
    customer_id: str
    credit_limit: float
    outstanding: float
    overdue: float
    available_credit: float
    approved: bool
    reason: str


class SalesFinanceManager:
    """Sales + finance collaboration layer.

    This is operational management, not statutory accounting. It adds approval,
    customer-specific pricing, credit control, commission accrual, statements,
    cash-flow forecasting and executive profitability analytics on top of V1.8.
    """

    def __init__(self, db: ProductionDB):
        self.db = db
        self.commercial = CommercialManager(db)
        self._init_schema()

    def _init_schema(self) -> None:
        with self.db.connect() as c:
            c.executescript(
                """
                CREATE TABLE IF NOT EXISTS customer_price_rules(
                  id INTEGER PRIMARY KEY AUTOINCREMENT,
                  customer_id TEXT NOT NULL,
                  sku TEXT NOT NULL,
                  min_qty REAL NOT NULL DEFAULT 0,
                  unit_price REAL NOT NULL,
                  min_margin REAL NOT NULL DEFAULT 0.15,
                  active INTEGER NOT NULL DEFAULT 1,
                  created_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_price_rules_lookup
                  ON customer_price_rules(customer_id,sku,min_qty,active);

                CREATE TABLE IF NOT EXISTS quote_approvals(
                  id INTEGER PRIMARY KEY AUTOINCREMENT,
                  quote_id TEXT NOT NULL,
                  status TEXT NOT NULL,
                  requested_by TEXT,
                  approver TEXT,
                  reason TEXT,
                  requested_at TEXT NOT NULL,
                  decided_at TEXT
                );

                CREATE TABLE IF NOT EXISTS salespeople(
                  salesperson_id TEXT PRIMARY KEY,
                  name TEXT NOT NULL,
                  commission_rate REAL NOT NULL DEFAULT 0,
                  active INTEGER NOT NULL DEFAULT 1,
                  created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS order_sales_assignments(
                  order_id TEXT PRIMARY KEY,
                  salesperson_id TEXT NOT NULL,
                  assigned_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS commission_accruals(
                  id INTEGER PRIMARY KEY AUTOINCREMENT,
                  order_id TEXT NOT NULL,
                  salesperson_id TEXT NOT NULL,
                  basis TEXT NOT NULL,
                  basis_amount REAL NOT NULL,
                  rate REAL NOT NULL,
                  commission REAL NOT NULL,
                  status TEXT NOT NULL DEFAULT 'accrued',
                  created_at TEXT NOT NULL,
                  settled_at TEXT
                );

                CREATE TABLE IF NOT EXISTS supplier_payments(
                  id INTEGER PRIMARY KEY AUTOINCREMENT,
                  po_id TEXT NOT NULL,
                  amount REAL NOT NULL,
                  method TEXT,
                  reference TEXT,
                  paid_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS credit_holds(
                  id INTEGER PRIMARY KEY AUTOINCREMENT,
                  order_id TEXT NOT NULL,
                  customer_id TEXT NOT NULL,
                  reason TEXT NOT NULL,
                  active INTEGER NOT NULL DEFAULT 1,
                  created_at TEXT NOT NULL,
                  released_by TEXT,
                  released_at TEXT
                );
                """
            )

    # ---------- customer pricing ----------
    def set_price_rule(self, customer_id: str, sku: str, min_qty: float,
                       unit_price: float, min_margin: float = 0.15) -> int:
        if unit_price < 0 or min_qty < 0:
            raise ValueError("数量和价格不能为负")
        with self.db.connect() as c:
            cur = c.execute(
                "INSERT INTO customer_price_rules(customer_id,sku,min_qty,unit_price,min_margin,created_at) VALUES(?,?,?,?,?,?)",
                (customer_id, sku, float(min_qty), float(unit_price), float(min_margin), utc_now()),
            )
            return int(cur.lastrowid)

    def resolve_price(self, customer_id: str, sku: str, qty: float,
                      fallback_price: float | None = None) -> dict[str, Any]:
        with self.db.connect() as c:
            r = c.execute(
                """SELECT * FROM customer_price_rules
                   WHERE customer_id=? AND sku=? AND active=1 AND min_qty<=?
                   ORDER BY min_qty DESC,id DESC LIMIT 1""",
                (customer_id, sku, float(qty)),
            ).fetchone()
        if r:
            return {"unit_price": float(r["unit_price"]), "min_margin": float(r["min_margin"]), "source": "customer_rule"}
        if fallback_price is None:
            raise KeyError(f"没有 {customer_id}/{sku} 的可用价格")
        return {"unit_price": float(fallback_price), "min_margin": 0.15, "source": "fallback"}

    # ---------- quote approval ----------
    def request_quote_approval(self, quote_id: str, requested_by: str = "", reason: str = "") -> dict[str, Any]:
        q = self.commercial.get_quote(quote_id)
        with self.db.connect() as c:
            c.execute("UPDATE quotes SET status='pending_approval' WHERE quote_id=?", (quote_id,))
            cur = c.execute(
                "INSERT INTO quote_approvals(quote_id,status,requested_by,reason,requested_at) VALUES(?,?,?,?,?)",
                (quote_id, "pending", requested_by, reason, utc_now()),
            )
        self.db.audit("sales.quote_approval_requested", {"quote_id": quote_id, "margin": q["estimated_margin"]})
        return {"approval_id": int(cur.lastrowid), "quote_id": quote_id, "status": "pending"}

    def approve_quote(self, quote_id: str, approver: str, approved: bool = True, reason: str = "") -> dict[str, Any]:
        status = "approved" if approved else "rejected"
        quote_status = "approved" if approved else "rejected"
        with self.db.connect() as c:
            r = c.execute(
                "SELECT id FROM quote_approvals WHERE quote_id=? AND status='pending' ORDER BY id DESC LIMIT 1",
                (quote_id,),
            ).fetchone()
            if not r:
                raise ValueError("该报价没有待审批记录")
            c.execute(
                "UPDATE quote_approvals SET status=?,approver=?,reason=?,decided_at=? WHERE id=?",
                (status, approver, reason, utc_now(), r["id"]),
            )
            c.execute("UPDATE quotes SET status=? WHERE quote_id=?", (quote_status, quote_id))
        self.db.audit("sales.quote_approval_decided", {"quote_id": quote_id, "status": status, "approver": approver})
        return {"quote_id": quote_id, "status": status, "approver": approver}

    def approval_required(self, quote_id: str, default_min_margin: float = 0.15) -> dict[str, Any]:
        q = self.commercial.get_quote(quote_id)
        threshold = float(default_min_margin)
        for line in q["lines"]:
            sku = str(line.get("description", ""))
            qty = float(line.get("qty", 0))
            try:
                rule = self.resolve_price(q["customer_id"], sku, qty)
                threshold = max(threshold, float(rule["min_margin"]))
            except KeyError:
                pass
        required = float(q["estimated_margin"]) + 1e-9 < threshold
        return {"required": required, "margin": float(q["estimated_margin"]), "threshold": threshold}

    # ---------- credit control ----------
    def credit_decision(self, customer_id: str) -> CreditDecision:
        with self.db.connect() as c:
            customer = c.execute("SELECT * FROM customers WHERE customer_id=?", (customer_id,)).fetchone()
            if not customer:
                raise KeyError(customer_id)
            outstanding = float(c.execute(
                "SELECT COALESCE(SUM(amount-paid),0) FROM receivables WHERE customer_id=? AND status!='paid'",
                (customer_id,),
            ).fetchone()[0])
            overdue = float(c.execute(
                """SELECT COALESCE(SUM(amount-paid),0) FROM receivables
                   WHERE customer_id=? AND status!='paid' AND due_date!='' AND due_date<?""",
                (customer_id, date.today().isoformat()),
            ).fetchone()[0])
        limit = float(customer["credit_limit"])
        available = round(limit - outstanding, 2) if limit > 0 else float("inf")
        approved = (limit <= 0 or outstanding <= limit + 0.005) and overdue <= max(limit * 0.25, 0.0) + 0.005
        if not approved:
            reason = "逾期应收超过信用策略" if overdue > max(limit * 0.25, 0.0) + 0.005 else "已用信用额度超过上限"
        else:
            reason = "信用检查通过"
        return CreditDecision(customer_id, limit, round(outstanding,2), round(overdue,2), available, approved, reason)

    def enforce_order_credit(self, order_id: str) -> CreditDecision:
        order = self.commercial.get_order(order_id)
        decision = self.credit_decision(order["customer_id"])
        with self.db.connect() as c:
            # Add the new order value to exposure if it is not already invoiced.
            invoiced = c.execute("SELECT 1 FROM receivables WHERE order_id=? LIMIT 1", (order_id,)).fetchone()
            projected = decision.outstanding + (0 if invoiced else float(order["total"]))
            limit_ok = decision.credit_limit <= 0 or projected <= decision.credit_limit + 0.005
            approved = decision.approved and limit_ok
            if not approved:
                reason = decision.reason if decision.approved is False else "订单加入后将超过信用额度"
                c.execute("UPDATE sales_orders SET status='credit_hold' WHERE order_id=?", (order_id,))
                c.execute(
                    "INSERT INTO credit_holds(order_id,customer_id,reason,created_at) VALUES(?,?,?,?)",
                    (order_id, order["customer_id"], reason, utc_now()),
                )
                return CreditDecision(decision.customer_id, decision.credit_limit, round(projected,2), decision.overdue,
                                      round(decision.credit_limit-projected,2) if decision.credit_limit > 0 else float('inf'), False, reason)
        return decision

    def release_credit_hold(self, order_id: str, released_by: str) -> None:
        with self.db.connect() as c:
            c.execute("UPDATE credit_holds SET active=0,released_by=?,released_at=? WHERE order_id=? AND active=1",
                      (released_by, utc_now(), order_id))
            c.execute("UPDATE sales_orders SET status='confirmed' WHERE order_id=? AND status='credit_hold'", (order_id,))
        self.db.audit("sales.credit_hold_released", {"order_id": order_id, "released_by": released_by})

    # ---------- sales commission ----------
    def upsert_salesperson(self, salesperson_id: str, name: str, commission_rate: float) -> None:
        with self.db.connect() as c:
            c.execute(
                """INSERT INTO salespeople(salesperson_id,name,commission_rate,created_at) VALUES(?,?,?,?)
                   ON CONFLICT(salesperson_id) DO UPDATE SET name=excluded.name,commission_rate=excluded.commission_rate""",
                (salesperson_id, name, float(commission_rate), utc_now()),
            )

    def assign_salesperson(self, order_id: str, salesperson_id: str) -> None:
        with self.db.connect() as c:
            c.execute(
                """INSERT INTO order_sales_assignments(order_id,salesperson_id,assigned_at) VALUES(?,?,?)
                   ON CONFLICT(order_id) DO UPDATE SET salesperson_id=excluded.salesperson_id,assigned_at=excluded.assigned_at""",
                (order_id, salesperson_id, utc_now()),
            )

    def accrue_commission(self, order_id: str, basis: str = "gross_profit") -> dict[str, Any]:
        with self.db.connect() as c:
            a = c.execute("SELECT salesperson_id FROM order_sales_assignments WHERE order_id=?", (order_id,)).fetchone()
            if not a: raise ValueError("订单未分配业务员")
            sp = c.execute("SELECT * FROM salespeople WHERE salesperson_id=? AND active=1", (a["salesperson_id"],)).fetchone()
            if not sp: raise ValueError("业务员不存在或已停用")
        profit = self.commercial.order_profit(order_id)
        if basis == "revenue": amount = profit["revenue"]
        elif basis == "cash_collected":
            with self.db.connect() as c:
                amount = float(c.execute(
                    "SELECT COALESCE(SUM(p.amount),0) FROM payments p JOIN receivables r ON r.invoice_id=p.invoice_id WHERE r.order_id=?",
                    (order_id,),
                ).fetchone()[0])
        else:
            basis = "gross_profit"; amount = max(0.0, profit["profit"])
        rate = float(sp["commission_rate"]); commission = round(amount * rate, 2)
        with self.db.connect() as c:
            cur = c.execute(
                "INSERT INTO commission_accruals(order_id,salesperson_id,basis,basis_amount,rate,commission,created_at) VALUES(?,?,?,?,?,?,?)",
                (order_id, sp["salesperson_id"], basis, amount, rate, commission, utc_now()),
            )
        return {"id": int(cur.lastrowid), "order_id": order_id, "salesperson_id": sp["salesperson_id"], "basis": basis,
                "basis_amount": round(amount,2), "rate": rate, "commission": commission}

    # ---------- statements / payables ----------
    def customer_statement(self, customer_id: str) -> dict[str, Any]:
        with self.db.connect() as c:
            inv = [dict(r) for r in c.execute(
                "SELECT * FROM receivables WHERE customer_id=? ORDER BY created_at,invoice_id", (customer_id,)
            ).fetchall()]
        total = round(sum(float(x["amount"]) for x in inv),2)
        paid = round(sum(float(x["paid"]) for x in inv),2)
        return {"customer_id": customer_id, "invoices": inv, "total": total, "paid": paid, "balance": round(total-paid,2)}

    def record_supplier_payment(self, po_id: str, amount: float, method: str = "bank", reference: str = "") -> None:
        if amount <= 0: raise ValueError("付款金额必须大于0")
        with self.db.connect() as c:
            if not c.execute("SELECT 1 FROM purchase_orders WHERE po_id=?", (po_id,)).fetchone(): raise KeyError(po_id)
            c.execute("INSERT INTO supplier_payments(po_id,amount,method,reference,paid_at) VALUES(?,?,?,?,?)",
                      (po_id,float(amount),method,reference,utc_now()))

    def supplier_statement(self, supplier: str) -> dict[str, Any]:
        with self.db.connect() as c:
            pos = [dict(r) for r in c.execute("SELECT * FROM purchase_orders WHERE supplier=? ORDER BY created_at", (supplier,)).fetchall()]
            paid = float(c.execute(
                "SELECT COALESCE(SUM(sp.amount),0) FROM supplier_payments sp JOIN purchase_orders po ON po.po_id=sp.po_id WHERE po.supplier=?",
                (supplier,),
            ).fetchone()[0])
        total = round(sum(float(x["total"]) for x in pos),2)
        return {"supplier": supplier, "purchase_orders": pos, "total": total, "paid": round(paid,2), "balance": round(total-paid,2)}

    # ---------- cash flow / executive analytics ----------
    def cashflow_forecast(self, days: int = 90, bucket_days: int = 30) -> list[dict[str, Any]]:
        today = date.today(); result=[]
        with self.db.connect() as c:
            ars=[dict(r) for r in c.execute("SELECT amount,paid,due_date FROM receivables WHERE status!='paid'").fetchall()]
            pos=[dict(r) for r in c.execute("SELECT po_id,total,expected_at FROM purchase_orders WHERE status!='closed'").fetchall()]
            paid_by_po={r["po_id"]: float(r["paid"]) for r in c.execute("SELECT po_id,COALESCE(SUM(amount),0) paid FROM supplier_payments GROUP BY po_id").fetchall()}
        for start in range(0, max(1,days), bucket_days):
            s=today+timedelta(days=start); e=min(today+timedelta(days=days), s+timedelta(days=bucket_days-1))
            inflow=0.0; outflow=0.0
            for r in ars:
                try: d=date.fromisoformat(r["due_date"]) if r["due_date"] else today
                except ValueError: d=today
                if s<=d<=e: inflow += float(r["amount"])-float(r["paid"])
            for po in pos:
                try: d=date.fromisoformat(po["expected_at"][:10]) if po["expected_at"] else today
                except ValueError: d=today
                if s<=d<=e: outflow += max(0.0,float(po["total"])-paid_by_po.get(po["po_id"],0.0))
            result.append({"start":s.isoformat(),"end":e.isoformat(),"inflow":round(inflow,2),"outflow":round(outflow,2),"net":round(inflow-outflow,2)})
        return result

    def profit_ranking(self, limit: int = 20) -> list[dict[str, Any]]:
        with self.db.connect() as c:
            ids=[r["order_id"] for r in c.execute("SELECT order_id FROM sales_orders ORDER BY created_at DESC").fetchall()]
        rows=[self.commercial.order_profit(x) for x in ids]
        rows.sort(key=lambda x:(x["profit"],x["margin"]), reverse=True)
        return rows[:limit]

    def executive_dashboard(self) -> dict[str, Any]:
        base=self.commercial.dashboard(); ranking=self.profit_ranking(1000); forecast=self.cashflow_forecast(90,30)
        with self.db.connect() as c:
            pending_approvals=int(c.execute("SELECT COUNT(*) FROM quote_approvals WHERE status='pending'").fetchone()[0])
            active_holds=int(c.execute("SELECT COUNT(*) FROM credit_holds WHERE active=1").fetchone()[0])
            commissions=float(c.execute("SELECT COALESCE(SUM(commission),0) FROM commission_accruals WHERE status='accrued'").fetchone()[0])
        loss_orders=sum(1 for r in ranking if r["profit"] < 0)
        return {**base,"pending_approvals":pending_approvals,"credit_holds":active_holds,
                "accrued_commissions":round(commissions,2),"loss_order_count":loss_orders,
                "cashflow_90d_net":round(sum(x["net"] for x in forecast),2),"top_profit_orders":ranking[:5]}
