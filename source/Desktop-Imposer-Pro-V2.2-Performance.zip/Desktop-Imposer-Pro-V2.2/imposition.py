from __future__ import annotations

from dataclasses import asdict, dataclass
from io import BytesIO
from pathlib import Path
from typing import Sequence
import copy
import csv
import json
import math
from functools import lru_cache
import re
import tempfile

from PIL import Image
from pypdf import PdfReader, PdfWriter, Transformation
from pypdf.generic import ContentStream
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.pdfgen import canvas
try:
    from reportlab.graphics.barcode.code128 import Code128
except Exception:  # pragma: no cover - optional runtime capability
    Code128 = None
try:
    from reportlab.graphics.barcode.qr import QrCodeWidget
    from reportlab.graphics.shapes import Drawing
    from reportlab.graphics import renderPDF
except Exception:  # pragma: no cover - optional runtime capability
    QrCodeWidget = None
    Drawing = None
    renderPDF = None


PT_PER_MM = 72.0 / 25.4
MM_PER_PT = 25.4 / 72.0


def mm(value: float) -> float:
    return float(value) * PT_PER_MM


def pt_to_mm(value: float) -> float:
    return float(value) * MM_PER_PT


@dataclass(frozen=True)
class ImpositionSettings:
    # Sheet / default product
    sheet_width_mm: float = 450.0
    sheet_height_mm: float = 320.0
    trim_width_mm: float = 90.0
    trim_height_mm: float = 54.0
    bleed_mm: float = 0.0

    # Grid / packing
    margin_x_mm: float = 10.0
    margin_y_mm: float = 10.0
    gap_x_mm: float = 4.0
    gap_y_mm: float = 4.0
    rows: int = 1
    cols: int = 1
    auto_grid: bool = True
    copies_per_page: int = 1
    rotation: int = 0
    auto_rotate: bool = False
    center_grid: bool = True
    smart_mixed_sizes: bool = False

    # Source / scale
    source_box: str = "crop"  # crop/media/trim/bleed
    scale_mode: str = "fit"   # fit/actual
    actual_size_tolerance_mm: float = 0.5

    # Marks
    crop_marks: bool = True
    crop_mark_length_mm: float = 4.0
    crop_mark_offset_mm: float = 2.0
    registration_marks: bool = False
    center_marks: bool = False

    # Duplex: source pages are paired [front, back]
    duplex: bool = False
    duplex_flip: str = "long"  # long/short

    # Production identity / sheet labels
    order_no: str = ""
    customer_name: str = ""
    sheet_info: bool = False
    barcode_enabled: bool = False
    qr_enabled: bool = False
    serial_prefix: str = ""
    serial_start: int = 1

    # Per-item variable data marks
    item_qr_enabled: bool = False
    item_serial_enabled: bool = False
    item_code_size_mm: float = 8.0

    # Deep preflight thresholds
    preflight_fonts: bool = True
    preflight_colors: bool = True
    preflight_images: bool = True
    preflight_pdfx: bool = True
    require_pdfx: bool = False
    preflight_graphics: bool = True
    min_image_dpi: int = 200

    # Per-item variable data mapping. Rows are consumed in final physical item order.
    variable_data_path: str = ""
    item_qr_template: str = ""
    item_text_template: str = ""
    variable_data_strict: bool = True

    def to_dict(self) -> dict:
        return asdict(self)

    def validate(self) -> None:
        positive = {
            "sheet_width_mm": self.sheet_width_mm,
            "sheet_height_mm": self.sheet_height_mm,
            "trim_width_mm": self.trim_width_mm,
            "trim_height_mm": self.trim_height_mm,
            "copies_per_page": self.copies_per_page,
            "actual_size_tolerance_mm": self.actual_size_tolerance_mm,
        }
        for name, value in positive.items():
            if value <= 0:
                raise ValueError(f"{name} 必须大于 0")

        non_negative = {
            "bleed_mm": self.bleed_mm,
            "margin_x_mm": self.margin_x_mm,
            "margin_y_mm": self.margin_y_mm,
            "gap_x_mm": self.gap_x_mm,
            "gap_y_mm": self.gap_y_mm,
            "crop_mark_length_mm": self.crop_mark_length_mm,
            "crop_mark_offset_mm": self.crop_mark_offset_mm,
        }
        for name, value in non_negative.items():
            if value < 0:
                raise ValueError(f"{name} 不能小于 0")

        if self.rotation not in (0, 90, 180, 270):
            raise ValueError("rotation 仅支持 0/90/180/270")
        if self.source_box not in {"crop", "media", "trim", "bleed"}:
            raise ValueError("source_box 仅支持 crop/media/trim/bleed")
        if self.scale_mode not in {"fit", "actual"}:
            raise ValueError("scale_mode 仅支持 fit/actual")
        if self.duplex_flip not in {"long", "short"}:
            raise ValueError("duplex_flip 仅支持 long/short")
        if self.serial_start < 0:
            raise ValueError("serial_start 不能小于 0")
        if self.item_code_size_mm <= 0:
            raise ValueError("item_code_size_mm 必须大于 0")
        if self.min_image_dpi < 36 or self.min_image_dpi > 2400:
            raise ValueError("min_image_dpi 建议设置在 36–2400 之间")
        if not self.auto_grid and not self.smart_mixed_sizes and (self.rows < 1 or self.cols < 1):
            raise ValueError("手动行列数必须至少为 1")

        footprint_w = self.trim_width_mm + 2 * self.bleed_mm
        footprint_h = self.trim_height_mm + 2 * self.bleed_mm
        if footprint_w <= 0 or footprint_h <= 0:
            raise ValueError("成品尺寸与出血组合无效")


@dataclass(frozen=True)
class InputJob:
    path: str | Path
    quantity: int = 1
    trim_width_mm: float | None = None
    trim_height_mm: float | None = None
    bleed_mm: float | None = None
    name: str = ""

    def validate(self) -> None:
        if self.quantity < 1:
            raise ValueError(f"文件数量必须至少为 1：{self.path}")
        for label, value in (
            ("成品宽", self.trim_width_mm),
            ("成品高", self.trim_height_mm),
        ):
            if value is not None and value <= 0:
                raise ValueError(f"{label}必须大于 0：{self.path}")
        if self.bleed_mm is not None and self.bleed_mm < 0:
            raise ValueError(f"出血不能小于 0：{self.path}")

    def effective_trim(self, settings: ImpositionSettings) -> tuple[float, float, float]:
        w = self.trim_width_mm if self.trim_width_mm is not None else settings.trim_width_mm
        h = self.trim_height_mm if self.trim_height_mm is not None else settings.trim_height_mm
        bleed = self.bleed_mm if self.bleed_mm is not None else settings.bleed_mm
        return float(w), float(h), float(bleed)


@dataclass(frozen=True)
class GridResult:
    rows: int
    cols: int
    capacity: int
    origin_x_mm: float
    origin_y_mm: float
    used_width_mm: float
    used_height_mm: float
    effective_rotation: int
    footprint_width_mm: float
    footprint_height_mm: float


@dataclass(frozen=True)
class PackedPlacement:
    job_index: int
    unit_index: int
    x_mm: float
    y_mm: float
    footprint_width_mm: float
    footprint_height_mm: float
    trim_width_mm: float
    trim_height_mm: float
    bleed_mm: float
    rotation: int

    @property
    def trim_rect(self) -> tuple[float, float, float, float]:
        if self.rotation in (90, 270):
            tw, th = self.trim_height_mm, self.trim_width_mm
        else:
            tw, th = self.trim_width_mm, self.trim_height_mm
        return self.x_mm + self.bleed_mm, self.y_mm + self.bleed_mm, tw, th


@dataclass(frozen=True)
class PackingSummary:
    sheets: list[list[PackedPlacement]]
    total_items: int
    utilization_percent: float
    per_sheet_utilization: list[float]


@dataclass(frozen=True)
class _PackSpec:
    job_index: int
    unit_index: int
    trim_width_mm: float
    trim_height_mm: float
    bleed_mm: float


@dataclass(frozen=True)
class _Rect:
    x: float
    y: float
    w: float
    h: float

    @property
    def right(self) -> float:
        return self.x + self.w

    @property
    def top(self) -> float:
        return self.y + self.h


class _MaxRectsBin:
    """Small, dependency-free MaxRects-style bin used for mixed-size imposition."""

    def __init__(self, width: float, height: float):
        self.width = width
        self.height = height
        self.free: list[_Rect] = [_Rect(0.0, 0.0, width, height)]

    def find_position(self, w: float, h: float, allow_rotate: bool) -> tuple | None:
        candidates = [(w, h, 0)]
        if allow_rotate and abs(w - h) > 1e-9:
            candidates.append((h, w, 90))

        best = None
        for free in self.free:
            for cw, ch, delta in candidates:
                if cw <= free.w + 1e-8 and ch <= free.h + 1e-8:
                    leftover_h = abs(free.h - ch)
                    leftover_w = abs(free.w - cw)
                    short = min(leftover_h, leftover_w)
                    long = max(leftover_h, leftover_w)
                    score = (short, long, free.y, free.x)
                    candidate = (score, _Rect(free.x, free.y, cw, ch), delta)
                    if best is None or candidate[0] < best[0]:
                        best = candidate
        return best

    def place(self, used: _Rect) -> None:
        new_free: list[_Rect] = []
        for free in self.free:
            if used.right <= free.x + 1e-9 or used.x >= free.right - 1e-9 or used.top <= free.y + 1e-9 or used.y >= free.top - 1e-9:
                new_free.append(free)
                continue

            if used.x > free.x + 1e-9:
                new_free.append(_Rect(free.x, free.y, used.x - free.x, free.h))
            if used.right < free.right - 1e-9:
                new_free.append(_Rect(used.right, free.y, free.right - used.right, free.h))
            if used.y > free.y + 1e-9:
                new_free.append(_Rect(free.x, free.y, free.w, used.y - free.y))
            if used.top < free.top - 1e-9:
                new_free.append(_Rect(free.x, used.top, free.w, free.top - used.top))

        self.free = self._prune(new_free)

    @staticmethod
    def _prune(rects: list[_Rect]) -> list[_Rect]:
        kept: list[_Rect] = []
        for i, a in enumerate(rects):
            if a.w <= 1e-8 or a.h <= 1e-8:
                continue
            contained = False
            for j, b in enumerate(rects):
                if i == j:
                    continue
                if (
                    a.x >= b.x - 1e-9 and a.y >= b.y - 1e-9
                    and a.right <= b.right + 1e-9 and a.top <= b.top + 1e-9
                ):
                    contained = True
                    break
            if not contained:
                kept.append(a)
        return kept


def _footprint_for_rotation(settings: ImpositionSettings, rotation: int) -> tuple[float, float]:
    w = settings.trim_width_mm + 2 * settings.bleed_mm
    h = settings.trim_height_mm + 2 * settings.bleed_mm
    if rotation in (90, 270):
        return h, w
    return w, h


def _candidate_grid(settings: ImpositionSettings, rotation: int) -> tuple[int, int, float, float]:
    item_w, item_h = _footprint_for_rotation(settings, rotation)
    usable_w = settings.sheet_width_mm - 2 * settings.margin_x_mm
    usable_h = settings.sheet_height_mm - 2 * settings.margin_y_mm
    if usable_w <= 0 or usable_h <= 0:
        return 0, 0, item_w, item_h

    cols = max(0, math.floor((usable_w + settings.gap_x_mm) / (item_w + settings.gap_x_mm)))
    rows = max(0, math.floor((usable_h + settings.gap_y_mm) / (item_h + settings.gap_y_mm)))
    return rows, cols, item_w, item_h


def calculate_grid(settings: ImpositionSettings) -> GridResult:
    settings.validate()

    usable_w = settings.sheet_width_mm - 2 * settings.margin_x_mm
    usable_h = settings.sheet_height_mm - 2 * settings.margin_y_mm
    if usable_w <= 0 or usable_h <= 0:
        raise ValueError("边距过大，已没有可用纸张区域")

    effective_rotation = settings.rotation
    if settings.auto_grid and settings.auto_rotate:
        candidates = []
        for rot in (0, 90):
            rows_, cols_, item_w_, item_h_ = _candidate_grid(settings, rot)
            used_w_ = cols_ * item_w_ + max(0, cols_ - 1) * settings.gap_x_mm
            used_h_ = rows_ * item_h_ + max(0, rows_ - 1) * settings.gap_y_mm
            waste = max(0.0, usable_w * usable_h - used_w_ * used_h_)
            candidates.append((rows_ * cols_, -waste, rot, rows_, cols_, item_w_, item_h_))
        _, _, effective_rotation, rows, cols, item_w, item_h = max(candidates)
    else:
        item_w, item_h = _footprint_for_rotation(settings, effective_rotation)
        if settings.auto_grid:
            rows, cols, _, _ = _candidate_grid(settings, effective_rotation)
        else:
            rows = settings.rows
            cols = settings.cols

    if rows < 1 or cols < 1:
        raise ValueError("当前纸张/成品/出血/边距/间距组合放不下一件成品")

    used_w = cols * item_w + (cols - 1) * settings.gap_x_mm
    used_h = rows * item_h + (rows - 1) * settings.gap_y_mm

    if used_w > usable_w + 1e-8 or used_h > usable_h + 1e-8:
        raise ValueError(
            f"当前 {rows}×{cols} 排列超出纸张可用区域；"
            f"需要约 {used_w:.2f}×{used_h:.2f} mm，"
            f"可用区域为 {usable_w:.2f}×{usable_h:.2f} mm"
        )

    if settings.center_grid:
        origin_x = (settings.sheet_width_mm - used_w) / 2
        origin_y = (settings.sheet_height_mm - used_h) / 2
    else:
        origin_x = settings.margin_x_mm
        origin_y = settings.margin_y_mm

    return GridResult(
        rows=rows,
        cols=cols,
        capacity=rows * cols,
        origin_x_mm=origin_x,
        origin_y_mm=origin_y,
        used_width_mm=used_w,
        used_height_mm=used_h,
        effective_rotation=effective_rotation,
        footprint_width_mm=item_w,
        footprint_height_mm=item_h,
    )


class SourceLibrary:
    """Keep readers alive while their PageObjects are reused."""

    def __init__(self) -> None:
        self._readers: list[PdfReader] = []
        self._temp_paths: list[Path] = []
        self.pages = []

    def close(self) -> None:
        for path in self._temp_paths:
            try:
                path.unlink(missing_ok=True)
            except Exception:
                pass
        self._temp_paths.clear()

    def _normalize_page(self, page):
        p = copy.deepcopy(page)
        try:
            if int(p.get("/Rotate", 0) or 0) % 360:
                p.transfer_rotation_to_content()
        except Exception:
            pass
        return p

    def add_pdf(self, path: str | Path) -> None:
        reader = PdfReader(str(path))
        if reader.is_encrypted:
            try:
                ok = reader.decrypt("")
            except Exception as exc:
                raise ValueError(f"无法打开加密 PDF：{path}") from exc
            if ok == 0:
                raise ValueError(f"PDF 已加密且需要密码：{path}")
        self._readers.append(reader)
        for page in reader.pages:
            self.pages.append(self._normalize_page(page))

    def add_image(self, path: str | Path, resolution: int = 300) -> None:
        src = Path(path)
        with Image.open(src) as im:
            if im.mode not in ("RGB", "L"):
                background = Image.new("RGB", im.size, "white")
                if "A" in im.getbands():
                    background.paste(im, mask=im.getchannel("A"))
                else:
                    background.paste(im.convert("RGB"))
                im = background
            elif im.mode == "L":
                im = im.convert("RGB")

            tmp = tempfile.NamedTemporaryFile(prefix="desktop_imposer_", suffix=".pdf", delete=False)
            tmp.close()
            tmp_path = Path(tmp.name)
            im.save(tmp_path, "PDF", resolution=resolution)
            self._temp_paths.append(tmp_path)
            self.add_pdf(tmp_path)

    def add(self, path: str | Path):
        before = len(self.pages)
        suffix = Path(path).suffix.lower()
        if suffix == ".pdf":
            self.add_pdf(path)
        elif suffix in {".ai", ".eps", ".ps"}:
            from import_providers import normalize_to_pdf
            normalized = normalize_to_pdf(path)
            self.add_pdf(normalized.normalized_pdf)
        elif suffix in {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".webp", ".bmp"}:
            self.add_image(path)
        else:
            raise ValueError(f"暂不支持该文件类型：{suffix or path}")
        return self.pages[before:]


def _source_box(page, name: str):
    key_map = {
        "media": "/MediaBox",
        "crop": "/CropBox",
        "trim": "/TrimBox",
        "bleed": "/BleedBox",
    }
    key = key_map[name]
    if name == "media":
        return page.mediabox
    if key in page:
        return getattr(page, f"{name}box")
    return page.cropbox


def _box_exists(page, name: str) -> bool:
    if name == "media":
        return True
    return {"crop": "/CropBox", "trim": "/TrimBox", "bleed": "/BleedBox"}[name] in page


def page_size_mm(page, source_box: str = "crop") -> tuple[float, float]:
    box = _source_box(page, source_box)
    return pt_to_mm(float(box.width)), pt_to_mm(float(box.height))


def _file_signature(path: str | Path) -> tuple[str, int, int]:
    src = Path(path).expanduser().resolve()
    stat = src.stat()
    return str(src), int(stat.st_mtime_ns), int(stat.st_size)


@lru_cache(maxsize=256)
def _inspect_source_cached(path_text: str, mtime_ns: int, size: int, source_box: str) -> tuple:
    """Fast metadata-only source inspection.

    The old implementation routed inspection through SourceLibrary, which deep-copied
    every PDF page.  Import-time inspection only needs page count + first-page boxes,
    so avoid materialising or normalising the whole document.
    """
    src = Path(path_text)
    suffix = src.suffix.lower()

    if suffix == ".pdf":
        reader = PdfReader(str(src), strict=False)
        if reader.is_encrypted:
            try:
                ok = reader.decrypt("")
            except Exception as exc:
                raise ValueError(f"无法打开加密 PDF：{src}") from exc
            if ok == 0:
                raise ValueError(f"PDF 已加密且需要密码：{src}")
        if len(reader.pages) < 1:
            raise ValueError("文件中没有可用页面")
        first = reader.pages[0]
        box = _source_box(first, source_box)
        w = pt_to_mm(float(box.width))
        h = pt_to_mm(float(box.height))
        try:
            rotation = int(first.get("/Rotate", 0) or 0) % 360
            if rotation in (90, 270):
                w, h = h, w
        except Exception:
            pass
        boxes = (
            True,
            _box_exists(first, "crop"),
            _box_exists(first, "trim"),
            _box_exists(first, "bleed"),
        )
        return (len(reader.pages), w, h, _box_exists(first, source_box), boxes)

    if suffix in {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".webp", ".bmp"}:
        with Image.open(src) as im:
            px_w, px_h = im.size
        # SourceLibrary converts raster sources to PDF at 300 DPI.  Mirror that
        # geometry here without creating a temporary PDF just to read it back.
        w = px_w / 300.0 * 25.4
        h = px_h / 300.0 * 25.4
        return (1, w, h, True, (True, True, False, False))

    if suffix in {".ai", ".eps", ".ps"}:
        from import_providers import normalize_to_pdf
        normalized = normalize_to_pdf(src)
        norm = Path(normalized.normalized_pdf)
        stat = norm.stat()
        return _inspect_source_cached(str(norm.resolve()), int(stat.st_mtime_ns), int(stat.st_size), source_box)

    raise ValueError(f"暂不支持该文件类型：{suffix or src}")


def inspect_source(path: str | Path, source_box: str = "crop") -> dict:
    path_text, mtime_ns, size = _file_signature(path)
    pages, w, h, requested, boxes = _inspect_source_cached(path_text, mtime_ns, size, source_box)
    return {
        "pages": int(pages),
        "width_mm": float(w),
        "height_mm": float(h),
        "source_box": source_box,
        "requested_box_exists": bool(requested),
        "boxes": {
            "media": bool(boxes[0]),
            "crop": bool(boxes[1]),
            "trim": bool(boxes[2]),
            "bleed": bool(boxes[3]),
        },
    }



def _resolved(obj):
    try:
        return obj.get_object()
    except Exception:
        return obj


def _resource_dict(page_or_form):
    try:
        return _resolved(page_or_form.get("/Resources", {})) or {}
    except Exception:
        return {}


def _font_is_embedded(font_obj) -> bool:
    font = _resolved(font_obj) or {}
    subtype = str(font.get("/Subtype", ""))
    descendants = _resolved(font.get("/DescendantFonts", [])) or []
    candidates = [font]
    for item in descendants:
        candidates.append(_resolved(item) or {})
    for candidate in candidates:
        descriptor = _resolved(candidate.get("/FontDescriptor")) if hasattr(candidate, "get") else None
        if descriptor and any(descriptor.get(key) is not None for key in ("/FontFile", "/FontFile2", "/FontFile3")):
            return True
    # Type3 glyphs are defined in the PDF itself rather than via an external font file.
    return subtype == "/Type3"


def _collect_font_status(resources, prefix: str = "") -> list[dict]:
    out = []
    resources = _resolved(resources) or {}
    fonts = _resolved(resources.get("/Font", {})) or {}
    for key, value in fonts.items():
        font = _resolved(value) or {}
        base = str(font.get("/BaseFont", key)).lstrip("/")
        out.append({"name": prefix + base, "embedded": _font_is_embedded(font), "subtype": str(font.get("/Subtype", ""))})
    return out


def _mat_mul(m1, m2):
    # PDF affine matrix [a b c d e f], equivalent to 3x3 multiplication m1*m2.
    a1,b1,c1,d1,e1,f1 = [float(x) for x in m1]
    a2,b2,c2,d2,e2,f2 = [float(x) for x in m2]
    return (
        a1*a2 + c1*b2,
        b1*a2 + d1*b2,
        a1*c2 + c1*d2,
        b1*c2 + d1*d2,
        a1*e2 + c1*f2 + e1,
        b1*e2 + d1*f2 + f1,
    )


def _extract_spot_names_from_colorspace(cs) -> list[str]:
    cs = _resolved(cs)
    if not isinstance(cs, (list, tuple)) or not cs:
        return []
    head = str(cs[0])
    if head == "/Separation" and len(cs) > 1:
        return [str(cs[1]).lstrip("/")]
    if head == "/DeviceN" and len(cs) > 1:
        names = _resolved(cs[1]) or []
        return [str(x).lstrip("/") for x in names]
    return []


def _classify_production_inks(names: Sequence[str]) -> dict[str, list[str]]:
    out = {"cut": [], "white": [], "varnish": [], "other": []}
    cut_tokens = ("cut", "die", "kiss", "contour", "thru", "刀", "模切", "切线")
    white_tokens = ("white", "opaque", "白墨", "白色")
    varnish_tokens = ("varnish", "spotuv", "spot uv", "uv", "gloss", "光油", "上光")
    for raw in sorted({str(x).strip() for x in names if str(x).strip()}):
        low = raw.lower()
        if any(t in low for t in cut_tokens):
            out["cut"].append(raw)
        elif any(t in low for t in white_tokens):
            out["white"].append(raw)
        elif any(t in low for t in varnish_tokens):
            out["varnish"].append(raw)
        else:
            out["other"].append(raw)
    return out


def _scan_content(page_or_form, reader, resources=None, ctm=(1,0,0,1,0,0), depth: int = 0) -> dict:
    """Best-effort scan for colors, spot inks, raster DPI, overprint and transparency."""
    colors: set[str] = set()
    spot_colors: set[str] = set()
    images: list[dict] = []
    overprint = False
    transparency = False
    transparency_signals: set[str] = set()
    if depth > 8:
        return {"colors": colors, "spot_colors": spot_colors, "images": images, "overprint": overprint,
                "transparency": transparency, "transparency_signals": transparency_signals}
    resources = _resolved(resources or _resource_dict(page_or_form)) or {}
    xobjects = _resolved(resources.get("/XObject", {})) or {}
    color_spaces = _resolved(resources.get("/ColorSpace", {})) or {}
    ext_gstates = _resolved(resources.get("/ExtGState", {})) or {}

    # Resource-declared spot colors are useful even when a page uses them through named CS operators.
    for _name, cs in getattr(color_spaces, "items", lambda: [])():
        for spot in _extract_spot_names_from_colorspace(cs):
            spot_colors.add(spot)
        txt = str(_resolved(cs))
        for token in ("DeviceRGB", "DeviceCMYK", "DeviceGray", "ICCBased", "Separation", "DeviceN"):
            if token in txt:
                colors.add(token)

    try:
        group = _resolved(page_or_form.get("/Group")) if hasattr(page_or_form, "get") else None
        if group and str(group.get("/S", "")) == "/Transparency":
            transparency = True
            transparency_signals.add("TransparencyGroup")
    except Exception:
        pass

    try:
        contents = page_or_form.get_contents() if hasattr(page_or_form, "get_contents") else page_or_form.get("/Resources") and page_or_form.get_data()
        stream = ContentStream(contents, reader) if hasattr(page_or_form, "get_contents") else ContentStream(page_or_form, reader)
    except Exception:
        return {"colors": colors, "spot_colors": spot_colors, "images": images, "overprint": overprint,
                "transparency": transparency, "transparency_signals": transparency_signals}

    stack = []
    current = tuple(ctm)
    for operands, operator in stream.operations:
        try:
            if operator == b"q":
                stack.append(current)
            elif operator == b"Q":
                if stack:
                    current = stack.pop()
            elif operator == b"cm" and len(operands) == 6:
                current = _mat_mul(tuple(float(x) for x in operands), current)
            elif operator in (b"rg", b"RG"):
                colors.add("DeviceRGB")
            elif operator in (b"k", b"K"):
                colors.add("DeviceCMYK")
            elif operator in (b"g", b"G"):
                colors.add("DeviceGray")
            elif operator in (b"cs", b"CS") and operands:
                name = str(operands[0])
                if name in ("/DeviceRGB", "/DeviceCMYK", "/DeviceGray", "/Pattern"):
                    colors.add(name.lstrip("/"))
                elif name in color_spaces:
                    cs = _resolved(color_spaces[name])
                    txt = str(cs)
                    for token in ("DeviceRGB", "DeviceCMYK", "DeviceGray", "ICCBased", "Separation", "DeviceN"):
                        if token in txt:
                            colors.add(token)
                    spot_colors.update(_extract_spot_names_from_colorspace(cs))
            elif operator == b"gs" and operands:
                gs = _resolved(ext_gstates.get(operands[0])) or {}
                if bool(gs.get("/OP", False)) or bool(gs.get("/op", False)):
                    overprint = True
                for key in ("/ca", "/CA"):
                    try:
                        if key in gs and float(gs.get(key, 1)) < 0.9999:
                            transparency = True
                            transparency_signals.add(f"{key}<{float(gs.get(key)):.3g}")
                    except Exception:
                        pass
                smask = gs.get("/SMask")
                if smask is not None and str(smask) not in ("/None", "None"):
                    transparency = True
                    transparency_signals.add("SoftMask")
                bm = gs.get("/BM")
                if bm is not None and str(bm) not in ("/Normal", "Normal"):
                    transparency = True
                    transparency_signals.add(f"BlendMode:{str(bm).lstrip('/')}")
            elif operator == b"Do" and operands:
                name = operands[0]
                obj = _resolved(xobjects.get(name))
                if not obj:
                    continue
                subtype = str(obj.get("/Subtype", ""))
                if subtype == "/Image":
                    px_w = int(obj.get("/Width", 0) or 0)
                    px_h = int(obj.get("/Height", 0) or 0)
                    cs = _resolved(obj.get("/ColorSpace", ""))
                    cs_txt = str(cs)
                    for token in ("DeviceRGB", "DeviceCMYK", "DeviceGray", "ICCBased", "Separation", "DeviceN"):
                        if token in cs_txt:
                            colors.add(token)
                    spot_colors.update(_extract_spot_names_from_colorspace(cs))
                    if obj.get("/SMask") is not None or obj.get("/Mask") is not None:
                        transparency = True
                        transparency_signals.add("ImageMask/SMask")
                    a,b,c,d,_,_ = current
                    width_pt = math.hypot(a, b)
                    height_pt = math.hypot(c, d)
                    if px_w > 0 and px_h > 0 and width_pt > 1e-6 and height_pt > 1e-6:
                        dpi_x = px_w * 72.0 / width_pt
                        dpi_y = px_h * 72.0 / height_pt
                        images.append({"name": str(name), "px": [px_w, px_h], "dpi_x": dpi_x, "dpi_y": dpi_y, "min_dpi": min(dpi_x, dpi_y)})
                elif subtype == "/Form":
                    form_resources = _resolved(obj.get("/Resources")) or resources
                    matrix = obj.get("/Matrix", [1,0,0,1,0,0])
                    nested_ctm = _mat_mul(tuple(float(x) for x in matrix), current)
                    nested = _scan_content(obj, reader, form_resources, nested_ctm, depth + 1)
                    colors.update(nested["colors"])
                    spot_colors.update(nested["spot_colors"])
                    images.extend(nested["images"])
                    overprint = overprint or nested["overprint"]
                    transparency = transparency or nested["transparency"]
                    transparency_signals.update(nested["transparency_signals"])
        except Exception:
            continue
    return {"colors": colors, "spot_colors": spot_colors, "images": images, "overprint": overprint,
            "transparency": transparency, "transparency_signals": transparency_signals}


def _pdfx_info(reader: PdfReader) -> dict:
    version = ""
    conformance = ""
    output_intents = []
    root = _resolved(reader.trailer.get("/Root")) or {}
    try:
        version = str(root.get("/GTS_PDFXVersion", "")).strip("()")
        conformance = str(root.get("/GTS_PDFXConformance", "")).strip("()")
    except Exception:
        pass
    try:
        meta = reader.metadata or {}
        version = version or str(meta.get("/GTS_PDFXVersion", "")).strip("()")
        conformance = conformance or str(meta.get("/GTS_PDFXConformance", "")).strip("()")
    except Exception:
        pass
    try:
        for raw in _resolved(root.get("/OutputIntents", [])) or []:
            oi = _resolved(raw) or {}
            output_intents.append({
                "subtype": str(oi.get("/S", "")).lstrip("/"),
                "condition": str(oi.get("/OutputCondition", "")).strip("()"),
                "identifier": str(oi.get("/OutputConditionIdentifier", "")).strip("()"),
                "registry": str(oi.get("/RegistryName", "")).strip("()"),
                "has_profile": oi.get("/DestOutputProfile") is not None,
            })
    except Exception:
        pass
    # XMP fallback: common PDF/X producers put the declaration only in metadata.
    if not version:
        try:
            metadata_obj = _resolved(root.get("/Metadata"))
            raw = metadata_obj.get_data() if metadata_obj is not None else b""
            text = raw.decode("utf-8", "ignore")
            m = re.search(r"GTS_PDFXVersion[^>]*>([^<]+)<", text, re.I)
            if not m:
                m = re.search(r"pdfxid:GTS_PDFXVersion=[\"']([^\"']+)", text, re.I)
            if m:
                version = m.group(1).strip()
        except Exception:
            pass
    declared = bool(version) or any(x.get("subtype") == "GTS_PDFX" for x in output_intents)
    return {"declared": declared, "version": version, "conformance": conformance, "output_intents": output_intents}


def analyze_pdf_prepress(path: str | Path, max_pages: int = 50) -> dict:
    """Inspect PDF/X declaration and production signals with file-signature caching."""
    path_text, mtime_ns, size = _file_signature(path)
    return _analyze_pdf_prepress_cached(path_text, mtime_ns, size, int(max_pages))


@lru_cache(maxsize=64)
def _analyze_pdf_prepress_cached(path_text: str, mtime_ns: int, size: int, max_pages: int) -> dict:
    reader = PdfReader(path_text, strict=False)
    fonts = []
    colors: set[str] = set()
    spot_colors: set[str] = set()
    images = []
    overprint = False
    transparency = False
    transparency_signals: set[str] = set()
    pages = reader.pages[:max_pages]
    for pno, page in enumerate(pages, 1):
        for f in _collect_font_status(_resource_dict(page)):
            f = dict(f); f["page"] = pno; fonts.append(f)
        scan = _scan_content(page, reader)
        colors.update(scan["colors"])
        spot_colors.update(scan["spot_colors"])
        overprint = overprint or scan["overprint"]
        transparency = transparency or scan["transparency"]
        transparency_signals.update(scan["transparency_signals"])
        for im in scan["images"]:
            im = dict(im); im["page"] = pno; images.append(im)
    dedup = {}
    for f in fonts:
        dedup[(f["name"], f["embedded"])] = f
    pdfx = _pdfx_info(reader)
    production_inks = _classify_production_inks(sorted(spot_colors))
    return {
        "pages_scanned": len(pages),
        "fonts": list(dedup.values()),
        "unembedded_fonts": sorted({f["name"] for f in fonts if not f["embedded"]}),
        "colors": sorted(colors),
        "spot_colors": sorted(spot_colors),
        "production_inks": production_inks,
        "overprint": overprint,
        "transparency": transparency,
        "transparency_signals": sorted(transparency_signals),
        "pdfx": pdfx,
        "images": images,
        "min_image_dpi": min((x["min_dpi"] for x in images), default=None),
    }

def analyze_raster_prepress(path: str | Path, target_w_mm: float, target_h_mm: float) -> dict:
    with Image.open(path) as im:
        px_w, px_h = im.size
        mode = im.mode
    if target_w_mm <= 0 or target_h_mm <= 0:
        dpi = None
    else:
        dpi_x = px_w / (target_w_mm / 25.4)
        dpi_y = px_h / (target_h_mm / 25.4)
        dpi = min(dpi_x, dpi_y)
    return {"pixels": [px_w, px_h], "mode": mode, "effective_dpi": dpi}


@lru_cache(maxsize=16)
def _load_variable_records_cached(path_text: str, mtime_ns: int, size: int) -> tuple[tuple[tuple[str, str], ...], ...]:
    src = Path(path_text)
    suffix = src.suffix.lower()
    rows: list[dict[str, str]] = []
    if suffix == ".csv":
        raw = src.read_bytes()
        text = None
        for enc in ("utf-8-sig", "utf-8", "gb18030"):
            try:
                text = raw.decode(enc)
                break
            except UnicodeDecodeError:
                pass
        if text is None:
            text = raw.decode("utf-8", "replace")
        reader = csv.DictReader(text.splitlines())
        for row in reader:
            rows.append({str(k or "").strip(): str(v or "").strip() for k, v in row.items()})
    elif suffix in {".xlsx", ".xlsm"}:
        try:
            from openpyxl import load_workbook
        except Exception as exc:
            raise ValueError("读取 Excel 变量数据需要 openpyxl") from exc
        wb = load_workbook(src, read_only=True, data_only=True)
        ws = wb.active
        iterator = ws.iter_rows(values_only=True)
        try:
            headers = [str(x or "").strip() for x in next(iterator)]
        except StopIteration:
            return tuple()
        for values in iterator:
            if not any(v is not None and str(v).strip() for v in values):
                continue
            rows.append({headers[i]: str(values[i] if i < len(values) and values[i] is not None else "").strip() for i in range(len(headers)) if headers[i]})
    else:
        raise ValueError("变量数据仅支持 CSV / XLSX")
    return tuple(tuple(sorted(row.items())) for row in rows)


def load_variable_records(path: str | Path) -> list[dict[str, str]]:
    """Load per-item variable data from CSV or XLSX with file-signature caching."""
    if not path:
        return []
    src = Path(path)
    if not src.is_file():
        raise ValueError(f"变量数据文件不存在：{src}")
    stat = src.stat()
    packed = _load_variable_records_cached(str(src.resolve()), int(stat.st_mtime_ns), int(stat.st_size))
    return [dict(items) for items in packed]


class _SafeFormatDict(dict):
    def __missing__(self, key):
        return ""


def _format_variable_template(template: str, record: dict[str, str]) -> str:
    if not template:
        return ""
    try:
        return template.format_map(_SafeFormatDict(record))
    except Exception:
        return template


def _variable_record(settings: ImpositionSettings, physical_index: int, sheet_index: int, side: str, item_no: int) -> dict[str, str]:
    serial_no = settings.serial_start + physical_index
    serial = f"{settings.serial_prefix}{serial_no:06d}" if settings.serial_prefix else f"{serial_no:06d}"
    base = {
        "serial": serial,
        "serial_no": str(serial_no),
        "order_no": settings.order_no or "",
        "customer": settings.customer_name or "",
        "sheet": str(sheet_index),
        "side": side or "single",
        "item": str(item_no),
    }
    if settings.variable_data_path:
        rows = load_variable_records(settings.variable_data_path)
        if 0 <= physical_index < len(rows):
            base.update(rows[physical_index])
    return base


def _trim_rect(settings: ImpositionSettings, grid: GridResult, row: int, col: int) -> tuple[float, float, float, float]:
    x = grid.origin_x_mm + col * (grid.footprint_width_mm + settings.gap_x_mm)
    y = grid.origin_y_mm + (grid.rows - 1 - row) * (grid.footprint_height_mm + settings.gap_y_mm)

    bleed = settings.bleed_mm
    if grid.effective_rotation in (90, 270):
        trim_w = settings.trim_height_mm
        trim_h = settings.trim_width_mm
    else:
        trim_w = settings.trim_width_mm
        trim_h = settings.trim_height_mm

    return x + bleed, y + bleed, trim_w, trim_h


def _registration_cross(c, x_mm: float, y_mm: float, size_mm: float = 3.0):
    c.line(mm(x_mm - size_mm), mm(y_mm), mm(x_mm + size_mm), mm(y_mm))
    c.line(mm(x_mm), mm(y_mm - size_mm), mm(x_mm), mm(y_mm + size_mm))
    c.circle(mm(x_mm), mm(y_mm), mm(size_mm * 0.55), stroke=1, fill=0)


_CJK_FONT = None


def _label_font() -> str:
    global _CJK_FONT
    if _CJK_FONT:
        return _CJK_FONT
    try:
        pdfmetrics.registerFont(UnicodeCIDFont("STSong-Light"))
        _CJK_FONT = "STSong-Light"
    except Exception:
        _CJK_FONT = "Helvetica"
    return _CJK_FONT


def _draw_sheet_info(
    c,
    settings: ImpositionSettings,
    sheet_index: int,
    total_sheets: int,
    side: str,
    utilization: float | None,
):
    if not settings.sheet_info and not settings.barcode_enabled and not settings.qr_enabled:
        return

    serial_no = settings.serial_start + sheet_index - 1
    serial_text = f"{settings.serial_prefix}{serial_no:04d}" if settings.serial_prefix else f"{serial_no:04d}"

    parts = []
    if settings.order_no:
        parts.append(f"订单:{settings.order_no}")
    if settings.customer_name:
        parts.append(f"客户:{settings.customer_name}")
    parts.append(f"版:{sheet_index}/{total_sheets}")
    parts.append(f"流水:{serial_text}")
    if side:
        parts.append(side)
    if utilization is not None:
        parts.append(f"利用率:{utilization:.1f}%")

    if settings.sheet_info:
        c.setFillColorRGB(0, 0, 0)
        c.setFont(_label_font(), 7)
        c.drawString(mm(max(2.0, settings.margin_x_mm * 0.2)), mm(2.0), "  |  ".join(parts))

    if settings.barcode_enabled and settings.order_no and Code128 is not None:
        value = "".join(ch for ch in settings.order_no if 32 <= ord(ch) <= 126)[:40]
        if value:
            try:
                code = Code128(value, barHeight=mm(5.5), barWidth=0.55, humanReadable=False)
                x = mm(settings.sheet_width_mm) - code.width - mm(3)
                y = mm(1.5)
                code.drawOn(c, x, y)
            except Exception:
                pass

    if settings.qr_enabled and QrCodeWidget is not None and Drawing is not None and renderPDF is not None:
        payload = "|".join([
            settings.order_no or "NO-ORDER",
            f"sheet={sheet_index}/{total_sheets}",
            f"side={side or 'single'}",
            f"serial={serial_text}",
        ])
        try:
            qr = QrCodeWidget(payload)
            bounds = qr.getBounds()
            qr_w = bounds[2] - bounds[0]
            qr_h = bounds[3] - bounds[1]
            size = mm(11.0)
            drawing = Drawing(size, size, transform=[size / qr_w, 0, 0, size / qr_h, 0, 0])
            drawing.add(qr)
            renderPDF.draw(drawing, c, mm(settings.sheet_width_mm - 14.0), mm(1.0))
        except Exception:
            pass



def _draw_variable_item_codes(
    c,
    settings: ImpositionSettings,
    trim_rects: Sequence[tuple[float, float, float, float]],
    sheet_index: int,
    total_sheets: int,
    side: str,
    item_serial_base: int,
):
    if not settings.item_qr_enabled and not settings.item_serial_enabled and not settings.item_text_template:
        return
    for item_no, (x, y, trim_w, trim_h) in enumerate(trim_rects, 1):
        physical_index = item_serial_base + item_no - 1
        record = _variable_record(settings, physical_index, sheet_index, side, item_no)
        serial = record["serial"]
        qr_size = min(settings.item_code_size_mm, max(3.0, min(trim_w, trim_h) * 0.28))
        pad = max(0.8, qr_size * 0.12)
        if settings.item_qr_enabled and QrCodeWidget is not None and Drawing is not None and renderPDF is not None:
            payload = _format_variable_template(settings.item_qr_template, record) if settings.item_qr_template.strip() else "|".join([
                settings.order_no or "NO-ORDER",
                f"sheet={sheet_index}/{total_sheets}",
                f"side={side or 'single'}",
                f"item={item_no}",
                f"serial={serial}",
            ])
            try:
                qr = QrCodeWidget(payload)
                bounds = qr.getBounds(); qw = bounds[2]-bounds[0]; qh = bounds[3]-bounds[1]
                size = mm(qr_size)
                drawing = Drawing(size, size, transform=[size/qw,0,0,size/qh,0,0])
                drawing.add(qr)
                renderPDF.draw(drawing, c, mm(x + trim_w - qr_size - pad), mm(y + pad))
            except Exception:
                pass
        if settings.item_serial_enabled:
            try:
                c.setFillColorRGB(0,0,0)
                c.setFont("Helvetica", max(4.0, min(7.0, mm(qr_size) * 0.11)))
                c.drawString(mm(x + pad), mm(y + pad), serial)
            except Exception:
                pass
        if settings.item_text_template.strip():
            text = _format_variable_template(settings.item_text_template, record)
            if text:
                try:
                    c.setFillColorRGB(0,0,0)
                    c.setFont(_label_font(), 5.5)
                    # Keep variable text inside the trim box and away from the QR corner.
                    max_chars = max(8, int((trim_w - 2 * pad) / 1.4))
                    c.drawString(mm(x + pad), mm(y + trim_h - pad - 1.8), text[:max_chars])
                except Exception:
                    pass

def _marks_overlay(
    settings: ImpositionSettings,
    grid: GridResult | None = None,
    trim_rects: Sequence[tuple[float, float, float, float]] | None = None,
    sheet_index: int = 1,
    total_sheets: int = 1,
    side: str = "",
    utilization: float | None = None,
    item_serial_base: int = 0,
    item_rects: Sequence[tuple[float, float, float, float]] | None = None,
) -> PdfReader:
    buf = BytesIO()
    sheet_w = mm(settings.sheet_width_mm)
    sheet_h = mm(settings.sheet_height_mm)
    c = canvas.Canvas(buf, pagesize=(sheet_w, sheet_h), pageCompression=1)
    c.setLineWidth(mm(0.12))
    c.setStrokeColorRGB(0, 0, 0)

    if trim_rects is None:
        trim_rects = []
        if grid is not None:
            for row in range(grid.rows):
                for col in range(grid.cols):
                    trim_rects.append(_trim_rect(settings, grid, row, col))

    if settings.crop_marks:
        mark_len = settings.crop_mark_length_mm
        offset = settings.crop_mark_offset_mm
        for x, y, trim_w, trim_h in trim_rects:
            left, right = x, x + trim_w
            bottom, top = y, y + trim_h

            for yy in (bottom, top):
                c.line(mm(left - offset - mark_len), mm(yy), mm(left - offset), mm(yy))
                c.line(mm(right + offset), mm(yy), mm(right + offset + mark_len), mm(yy))
            for xx in (left, right):
                c.line(mm(xx), mm(bottom - offset - mark_len), mm(xx), mm(bottom - offset))
                c.line(mm(xx), mm(top + offset), mm(xx), mm(top + offset + mark_len))

    if settings.registration_marks:
        safe = max(5.0, min(settings.margin_x_mm, settings.margin_y_mm) * 0.45)
        positions = [
            (safe, safe),
            (settings.sheet_width_mm - safe, safe),
            (safe, settings.sheet_height_mm - safe),
            (settings.sheet_width_mm - safe, settings.sheet_height_mm - safe),
        ]
        for x, y in positions:
            _registration_cross(c, x, y, 2.3)

    if settings.center_marks:
        cx = settings.sheet_width_mm / 2
        cy = settings.sheet_height_mm / 2
        inset = 2.0
        length = 4.0
        c.line(mm(cx), mm(inset), mm(cx), mm(inset + length))
        c.line(mm(cx), mm(settings.sheet_height_mm - inset - length), mm(cx), mm(settings.sheet_height_mm - inset))
        c.line(mm(inset), mm(cy), mm(inset + length), mm(cy))
        c.line(mm(settings.sheet_width_mm - inset - length), mm(cy), mm(settings.sheet_width_mm - inset), mm(cy))

    _draw_sheet_info(c, settings, sheet_index, total_sheets, side, utilization)
    _draw_variable_item_codes(c, settings, item_rects if item_rects is not None else trim_rects, sheet_index, total_sheets, side, item_serial_base)

    c.showPage()
    c.save()
    buf.seek(0)
    return PdfReader(buf)


def _box_geometry(page, source_box: str) -> tuple[float, float, float, float]:
    box = _source_box(page, source_box)
    return float(box.left), float(box.bottom), float(box.width), float(box.height)


def _placement_transform(
    page,
    x_mm: float,
    y_mm: float,
    target_w_mm: float,
    target_h_mm: float,
    rotation: int,
    source_box: str,
    scale_mode: str,
    tolerance_mm: float,
) -> Transformation:
    left, bottom, src_w, src_h = _box_geometry(page, source_box)
    target_w = mm(target_w_mm)
    target_h = mm(target_h_mm)

    if rotation in (0, 180):
        rotated_w = src_w
        rotated_h = src_h
    else:
        rotated_w = src_h
        rotated_h = src_w

    if scale_mode == "actual":
        dw = abs(pt_to_mm(rotated_w) - target_w_mm)
        dh = abs(pt_to_mm(rotated_h) - target_h_mm)
        if dw > tolerance_mm or dh > tolerance_mm:
            raise ValueError(
                "1:1 原尺寸模式校验失败："
                f"源页面约 {pt_to_mm(rotated_w):.2f}×{pt_to_mm(rotated_h):.2f} mm，"
                f"目标含出血尺寸为 {target_w_mm:.2f}×{target_h_mm:.2f} mm。"
                f"允许误差 {tolerance_mm:.2f} mm。"
            )
        scale = 1.0
    else:
        scale = min(target_w / rotated_w, target_h / rotated_h)

    draw_w = rotated_w * scale
    draw_h = rotated_h * scale
    x0 = mm(x_mm) + (target_w - draw_w) / 2
    y0 = mm(y_mm) + (target_h - draw_h) / 2

    op = Transformation().translate(tx=-left, ty=-bottom)
    if rotation == 0:
        return op.scale(sx=scale, sy=scale).translate(tx=x0, ty=y0)
    if rotation == 90:
        return op.rotate(90).translate(tx=src_h, ty=0).scale(sx=scale, sy=scale).translate(tx=x0, ty=y0)
    if rotation == 180:
        return op.rotate(180).translate(tx=src_w, ty=src_h).scale(sx=scale, sy=scale).translate(tx=x0, ty=y0)
    return op.rotate(270).translate(tx=0, ty=src_w).scale(sx=scale, sy=scale).translate(tx=x0, ty=y0)


def _mapped_back_slot(row: int, col: int, grid: GridResult, settings: ImpositionSettings) -> tuple[int, int]:
    long_edge_is_horizontal = settings.sheet_width_mm >= settings.sheet_height_mm

    if settings.duplex_flip == "long":
        mirror_rows = long_edge_is_horizontal
    else:
        mirror_rows = not long_edge_is_horizontal

    if mirror_rows:
        return grid.rows - 1 - row, col
    return row, grid.cols - 1 - col


def _mirror_packed_placement(p: PackedPlacement, settings: ImpositionSettings) -> PackedPlacement:
    long_edge_is_horizontal = settings.sheet_width_mm >= settings.sheet_height_mm
    if settings.duplex_flip == "long":
        mirror_y = long_edge_is_horizontal
    else:
        mirror_y = not long_edge_is_horizontal

    if mirror_y:
        x = p.x_mm
        y = settings.sheet_height_mm - p.y_mm - p.footprint_height_mm
    else:
        x = settings.sheet_width_mm - p.x_mm - p.footprint_width_mm
        y = p.y_mm

    return PackedPlacement(
        job_index=p.job_index,
        unit_index=p.unit_index,
        x_mm=x,
        y_mm=y,
        footprint_width_mm=p.footprint_width_mm,
        footprint_height_mm=p.footprint_height_mm,
        trim_width_mm=p.trim_width_mm,
        trim_height_mm=p.trim_height_mm,
        bleed_mm=p.bleed_mm,
        rotation=p.rotation,
    )


def _place_page(dest, source_page, row: int, col: int, settings: ImpositionSettings, grid: GridResult) -> None:
    x_mm = grid.origin_x_mm + col * (grid.footprint_width_mm + settings.gap_x_mm)
    y_mm = grid.origin_y_mm + (grid.rows - 1 - row) * (grid.footprint_height_mm + settings.gap_y_mm)

    transform = _placement_transform(
        source_page,
        x_mm=x_mm,
        y_mm=y_mm,
        target_w_mm=grid.footprint_width_mm,
        target_h_mm=grid.footprint_height_mm,
        rotation=grid.effective_rotation,
        source_box=settings.source_box,
        scale_mode=settings.scale_mode,
        tolerance_mm=settings.actual_size_tolerance_mm,
    )
    dest.merge_transformed_page(source_page, transform, over=True, expand=False)


def _place_packed_page(dest, source_page, placement: PackedPlacement, settings: ImpositionSettings) -> None:
    transform = _placement_transform(
        source_page,
        x_mm=placement.x_mm,
        y_mm=placement.y_mm,
        target_w_mm=placement.footprint_width_mm,
        target_h_mm=placement.footprint_height_mm,
        rotation=placement.rotation,
        source_box=settings.source_box,
        scale_mode=settings.scale_mode,
        tolerance_mm=settings.actual_size_tolerance_mm,
    )
    dest.merge_transformed_page(source_page, transform, over=True, expand=False)


def _job_footprint(job: InputJob, settings: ImpositionSettings, rotation: int) -> tuple[float, float, float, float, float]:
    trim_w, trim_h, bleed = job.effective_trim(settings)
    fw = trim_w + 2 * bleed
    fh = trim_h + 2 * bleed
    if rotation in (90, 270):
        fw, fh = fh, fw
    return fw, fh, trim_w, trim_h, bleed


def _pack_specs(specs: Sequence[_PackSpec], settings: ImpositionSettings) -> PackingSummary:
    settings.validate()
    usable_w = settings.sheet_width_mm - 2 * settings.margin_x_mm
    usable_h = settings.sheet_height_mm - 2 * settings.margin_y_mm
    if usable_w <= 0 or usable_h <= 0:
        raise ValueError("边距过大，已没有可用纸张区域")

    # Virtual extra gap on the far/right top means edge items do not lose capacity.
    bin_w = usable_w + settings.gap_x_mm
    bin_h = usable_h + settings.gap_y_mm

    # Large/awkward rectangles first generally gives much better fill than source order.
    ordered = sorted(
        specs,
        key=lambda s: (
            -max(s.trim_width_mm + 2 * s.bleed_mm, s.trim_height_mm + 2 * s.bleed_mm),
            -(s.trim_width_mm + 2 * s.bleed_mm) * (s.trim_height_mm + 2 * s.bleed_mm),
            s.job_index,
            s.unit_index,
        ),
    )

    bins: list[_MaxRectsBin] = []
    sheets: list[list[PackedPlacement]] = []

    for spec in ordered:
        base_rot = settings.rotation
        fw, fh, trim_w, trim_h, bleed = _job_footprint(
            InputJob("", 1, spec.trim_width_mm, spec.trim_height_mm, spec.bleed_mm),
            settings,
            base_rot,
        )
        pack_w = fw + settings.gap_x_mm
        pack_h = fh + settings.gap_y_mm

        best_sheet = None
        best_candidate = None
        for idx, bin_ in enumerate(bins):
            candidate = bin_.find_position(pack_w, pack_h, settings.auto_rotate)
            if candidate is not None:
                ranked = (candidate[0], idx)
                if best_candidate is None or ranked < (best_candidate[0], best_sheet):
                    best_sheet = idx
                    best_candidate = candidate

        if best_candidate is None:
            new_bin = _MaxRectsBin(bin_w, bin_h)
            candidate = new_bin.find_position(pack_w, pack_h, settings.auto_rotate)
            if candidate is None:
                raise ValueError(
                    f"异尺寸混拼无法放入：{trim_w:.2f}×{trim_h:.2f} mm，出血 {bleed:.2f} mm。"
                    f"纸张可用区域为 {usable_w:.2f}×{usable_h:.2f} mm。"
                )
            bins.append(new_bin)
            sheets.append([])
            best_sheet = len(bins) - 1
            best_candidate = candidate

        _, used_pack, delta = best_candidate
        bins[best_sheet].place(used_pack)

        effective_rotation = (base_rot + delta) % 360
        if delta == 90:
            actual_fw, actual_fh = fh, fw
        else:
            actual_fw, actual_fh = fw, fh

        placement = PackedPlacement(
            job_index=spec.job_index,
            unit_index=spec.unit_index,
            x_mm=settings.margin_x_mm + used_pack.x,
            y_mm=settings.margin_y_mm + used_pack.y,
            footprint_width_mm=actual_fw,
            footprint_height_mm=actual_fh,
            trim_width_mm=trim_w,
            trim_height_mm=trim_h,
            bleed_mm=bleed,
            rotation=effective_rotation,
        )
        sheets[best_sheet].append(placement)

    usable_area = usable_w * usable_h
    per_sheet = []
    for sheet in sheets:
        item_area = sum(p.footprint_width_mm * p.footprint_height_mm for p in sheet)
        per_sheet.append(0.0 if usable_area <= 0 else min(100.0, item_area / usable_area * 100.0))
    avg = 0.0 if not per_sheet else sum(per_sheet) / len(per_sheet)
    return PackingSummary(sheets=sheets, total_items=len(specs), utilization_percent=avg, per_sheet_utilization=per_sheet)


def estimate_smart_layout(
    jobs: Sequence[InputJob],
    settings: ImpositionSettings,
    page_counts: Sequence[int] | None = None,
) -> dict:
    if not jobs:
        return {"sheet_count": 0, "total_items": 0, "utilization_percent": 0.0, "per_sheet_utilization": []}
    if page_counts is not None and len(page_counts) != len(jobs):
        raise ValueError("page_counts 与 jobs 数量不一致")

    specs: list[_PackSpec] = []
    for idx, job in enumerate(jobs):
        job.validate()
        if page_counts is None:
            info = inspect_source(job.path, settings.source_box)
            pages = int(info["pages"])
        else:
            pages = int(page_counts[idx])
        if settings.duplex:
            if pages % 2:
                raise ValueError(f"双面模式要求偶数页：{Path(job.path).name}")
            units = pages // 2
        else:
            units = pages
        trim_w, trim_h, bleed = job.effective_trim(settings)
        counter = 0
        for _page in range(units):
            for _copy in range(job.quantity):
                specs.append(_PackSpec(idx, counter, trim_w, trim_h, bleed))
                counter += 1

    packed = _pack_specs(specs, settings)
    return {
        "sheet_count": len(packed.sheets),
        "total_items": packed.total_items,
        "utilization_percent": packed.utilization_percent,
        "per_sheet_utilization": packed.per_sheet_utilization,
        "max_items_on_sheet": max((len(s) for s in packed.sheets), default=0),
    }



def _build_pack_specs_for_jobs(
    jobs: Sequence[InputJob],
    settings: ImpositionSettings,
    page_counts: Sequence[int],
) -> list[_PackSpec]:
    if len(jobs) != len(page_counts):
        raise ValueError("page_counts 与 jobs 数量不一致")
    specs: list[_PackSpec] = []
    for idx, job in enumerate(jobs):
        job.validate()
        pages = int(page_counts[idx])
        if settings.duplex:
            if pages % 2:
                raise ValueError(f"双面模式要求偶数页：{Path(job.path).name}")
            units = pages // 2
        else:
            units = pages
        trim_w, trim_h, bleed = job.effective_trim(settings)
        unit_index = 0
        for _page in range(units):
            for _copy in range(job.quantity):
                specs.append(_PackSpec(idx, unit_index, trim_w, trim_h, bleed))
                unit_index += 1
    return specs


def _placement_dict(p: PackedPlacement) -> dict:
    return asdict(p)


def plan_smart_layout(
    jobs: Sequence[InputJob],
    settings: ImpositionSettings,
    page_counts: Sequence[int] | None = None,
) -> dict:
    """Return a serializable editable layout for mixed-size imposition."""
    if not settings.smart_mixed_sizes:
        raise ValueError("手工版位仅适用于异尺寸智能混拼模式")
    if page_counts is None:
        page_counts = [int(inspect_source(job.path, settings.source_box)["pages"]) for job in jobs]
    specs = _build_pack_specs_for_jobs(jobs, settings, page_counts)
    packed = _pack_specs(specs, settings)
    return {
        "version": 1,
        "sheet_width_mm": settings.sheet_width_mm,
        "sheet_height_mm": settings.sheet_height_mm,
        "margin_x_mm": settings.margin_x_mm,
        "margin_y_mm": settings.margin_y_mm,
        "gap_x_mm": settings.gap_x_mm,
        "gap_y_mm": settings.gap_y_mm,
        "expected_keys": [[s.job_index, s.unit_index] for s in specs],
        "sheets": [[_placement_dict(p) for p in sheet] for sheet in packed.sheets],
    }


def validate_manual_layout(layout: dict, settings: ImpositionSettings, expected_keys: set[tuple[int, int]] | None = None) -> dict:
    errors: list[str] = []
    warnings: list[str] = []
    sheets = layout.get("sheets") if isinstance(layout, dict) else None
    if not isinstance(sheets, list) or not sheets:
        return {"errors": ["手工版位没有任何纸张"], "warnings": []}

    if abs(float(layout.get("sheet_width_mm", settings.sheet_width_mm)) - settings.sheet_width_mm) > 0.01 or abs(float(layout.get("sheet_height_mm", settings.sheet_height_mm)) - settings.sheet_height_mm) > 0.01:
        errors.append("手工版位的纸张尺寸与当前参数不一致")

    seen: set[tuple[int, int]] = set()
    left = settings.margin_x_mm
    right = settings.sheet_width_mm - settings.margin_x_mm
    bottom = settings.margin_y_mm
    top = settings.sheet_height_mm - settings.margin_y_mm

    for sheet_no, sheet in enumerate(sheets, 1):
        rects = []
        if not isinstance(sheet, list):
            errors.append(f"第 {sheet_no} 张版格式错误")
            continue
        for idx, raw in enumerate(sheet, 1):
            try:
                key = (int(raw["job_index"]), int(raw["unit_index"]))
                x = float(raw["x_mm"]); y = float(raw["y_mm"])
                w = float(raw["footprint_width_mm"]); h = float(raw["footprint_height_mm"])
                rot = int(raw.get("rotation", 0)) % 360
            except Exception:
                errors.append(f"第 {sheet_no} 张版第 {idx} 件数据不完整")
                continue
            if key in seen:
                errors.append(f"版位重复：款 {key[0]+1} / 单元 {key[1]+1}")
            seen.add(key)
            if rot not in (0, 90, 180, 270):
                errors.append(f"第 {sheet_no} 张版第 {idx} 件旋转角度无效")
            if w <= 0 or h <= 0:
                errors.append(f"第 {sheet_no} 张版第 {idx} 件尺寸无效")
            if x < left - 1e-6 or y < bottom - 1e-6 or x + w > right + 1e-6 or y + h > top + 1e-6:
                errors.append(f"第 {sheet_no} 张版第 {idx} 件越出可用纸张区域")
            rects.append((idx, x, y, w, h))

        for a in range(len(rects)):
            ia, ax, ay, aw, ah = rects[a]
            for b in range(a + 1, len(rects)):
                ib, bx, by, bw, bh = rects[b]
                separated = (
                    ax + aw + settings.gap_x_mm <= bx + 1e-6
                    or bx + bw + settings.gap_x_mm <= ax + 1e-6
                    or ay + ah + settings.gap_y_mm <= by + 1e-6
                    or by + bh + settings.gap_y_mm <= ay + 1e-6
                )
                if not separated:
                    errors.append(f"第 {sheet_no} 张版第 {ia} 与第 {ib} 件发生重叠或间距不足")

    if expected_keys is None and layout.get("expected_keys"):
        expected_keys = {(int(a), int(b)) for a, b in layout["expected_keys"]}
    if expected_keys is not None:
        missing = expected_keys - seen
        extra = seen - expected_keys
        if missing:
            errors.append(f"手工版位缺少 {len(missing)} 件")
        if extra:
            errors.append(f"手工版位包含 {len(extra)} 件未知项目")

    return {"errors": errors, "warnings": warnings}


def _packing_from_manual_layout(layout: dict, specs: Sequence[_PackSpec], settings: ImpositionSettings) -> PackingSummary:
    spec_map = {(s.job_index, s.unit_index): s for s in specs}
    check = validate_manual_layout(layout, settings, set(spec_map))
    if check["errors"]:
        raise ValueError("手工版位无效：" + "；".join(check["errors"][:8]))

    sheets: list[list[PackedPlacement]] = []
    usable_area = (settings.sheet_width_mm - 2 * settings.margin_x_mm) * (settings.sheet_height_mm - 2 * settings.margin_y_mm)
    per_sheet: list[float] = []
    for raw_sheet in layout["sheets"]:
        sheet: list[PackedPlacement] = []
        for raw in raw_sheet:
            key = (int(raw["job_index"]), int(raw["unit_index"]))
            spec = spec_map[key]
            rotation = int(raw.get("rotation", settings.rotation)) % 360
            base_w = spec.trim_width_mm + 2 * spec.bleed_mm
            base_h = spec.trim_height_mm + 2 * spec.bleed_mm
            expected_w, expected_h = (base_h, base_w) if rotation in (90, 270) else (base_w, base_h)
            rw = float(raw["footprint_width_mm"]); rh = float(raw["footprint_height_mm"])
            if abs(rw - expected_w) > 0.05 or abs(rh - expected_h) > 0.05:
                raise ValueError(f"手工版位尺寸与旋转不一致：款 {key[0]+1} 单元 {key[1]+1}")
            sheet.append(PackedPlacement(
                job_index=key[0], unit_index=key[1],
                x_mm=float(raw["x_mm"]), y_mm=float(raw["y_mm"]),
                footprint_width_mm=rw, footprint_height_mm=rh,
                trim_width_mm=spec.trim_width_mm, trim_height_mm=spec.trim_height_mm,
                bleed_mm=spec.bleed_mm, rotation=rotation,
            ))
        sheets.append(sheet)
        area = sum(p.footprint_width_mm * p.footprint_height_mm for p in sheet)
        per_sheet.append(0.0 if usable_area <= 0 else min(100.0, area / usable_area * 100.0))
    return PackingSummary(
        sheets=sheets,
        total_items=sum(len(s) for s in sheets),
        utilization_percent=(sum(per_sheet) / len(per_sheet) if per_sheet else 0.0),
        per_sheet_utilization=per_sheet,
    )


def preflight_jobs(jobs: Sequence[InputJob], settings: ImpositionSettings) -> dict:
    errors: list[str] = []
    warnings: list[str] = []
    infos: list[str] = []
    if not jobs:
        return {"errors": ["尚未添加文件"], "warnings": [], "infos": []}

    try:
        settings.validate()
    except Exception as exc:
        errors.append(str(exc))
        return {"errors": errors, "warnings": warnings, "infos": infos}

    usable_w = settings.sheet_width_mm - 2 * settings.margin_x_mm
    usable_h = settings.sheet_height_mm - 2 * settings.margin_y_mm
    lib = SourceLibrary()
    expected_variable_items = 0
    try:
        for idx, job in enumerate(jobs, 1):
            try:
                job.validate()
                pages = list(lib.add(job.path))
            except Exception as exc:
                errors.append(f"[{idx}] {Path(job.path).name}：无法读取：{exc}")
                continue
            if not pages:
                errors.append(f"[{idx}] {Path(job.path).name}：没有可用页面")
                continue

            name = job.name or Path(job.path).stem
            trim_w, trim_h, bleed = job.effective_trim(settings)
            fw = trim_w + 2 * bleed
            fh = trim_h + 2 * bleed

            if settings.duplex and len(pages) % 2:
                errors.append(f"[{idx}] {name}：双面模式要求偶数页，当前 {len(pages)} 页")
            expected_variable_items += (len(pages) // 2 if settings.duplex else len(pages)) * job.quantity

            if settings.smart_mixed_sizes:
                orientations = [(fw, fh)]
                if settings.auto_rotate:
                    orientations.append((fh, fw))
                if not any(w <= usable_w + 1e-8 and h <= usable_h + 1e-8 for w, h in orientations):
                    errors.append(f"[{idx}] {name}：{fw:.2f}×{fh:.2f} mm 无法放入纸张可用区域")

            missing_special_box = settings.source_box in {"trim", "bleed"} and not _box_exists(pages[0], settings.source_box)
            if missing_special_box:
                warnings.append(f"[{idx}] {name}：没有 {settings.source_box.title()}Box，将回退到 CropBox")

            targets = []
            base_rot = settings.rotation
            if base_rot in (90, 270):
                targets.append((fh, fw))
            else:
                targets.append((fw, fh))
            if settings.auto_rotate:
                targets.append((targets[0][1], targets[0][0]))

            sample_pages = pages if len(pages) <= 20 else pages[:20]
            for pno, page in enumerate(sample_pages, 1):
                sw, sh = page_size_mm(page, settings.source_box)
                if settings.scale_mode == "actual":
                    matches = any(
                        abs(sw - tw) <= settings.actual_size_tolerance_mm
                        and abs(sh - th) <= settings.actual_size_tolerance_mm
                        for tw, th in targets
                    )
                    if not matches:
                        errors.append(
                            f"[{idx}] {name} 第{pno}页：1:1 尺寸 {sw:.2f}×{sh:.2f} mm 与目标含出血尺寸不符"
                        )
                        break
                else:
                    # warn on heavy scaling or aspect-ratio mismatch
                    ratios = []
                    for tw, th in targets:
                        ratios.append(min(tw / sw, th / sh))
                    scale = min(ratios, key=lambda r: abs(1.0 - r))
                    if scale < 0.80 or scale > 1.20:
                        warnings.append(f"[{idx}] {name} 第{pno}页：预计缩放到 {scale * 100:.1f}%")
                        break

            # Deep PDF/raster production checks.
            try:
                suffix = Path(job.path).suffix.lower()
                if suffix == ".pdf":
                    deep = analyze_pdf_prepress(job.path)
                    if settings.preflight_fonts and deep["unembedded_fonts"]:
                        names = "、".join(deep["unembedded_fonts"][:8])
                        warnings.append(f"[{idx}] {name}：检测到未嵌入字体：{names}")
                    if settings.preflight_pdfx:
                        pdfx = deep.get("pdfx", {})
                        if pdfx.get("declared"):
                            label = pdfx.get("version") or "PDF/X（版本未写明）"
                            oi = pdfx.get("output_intents") or []
                            profile = any(x.get("has_profile") for x in oi)
                            infos.append(f"[{idx}] {name}：检测到 {label}" + ("，含 OutputIntent ICC Profile" if profile else ""))
                            if not profile:
                                warnings.append(f"[{idx}] {name}：声明了 PDF/X，但未检测到嵌入的 OutputIntent ICC Profile")
                        else:
                            if settings.require_pdfx:
                                errors.append(f"[{idx}] {name}：当前生产模板要求 PDF/X，但文件未检测到 PDF/X 声明")
                            else:
                                infos.append(f"[{idx}] {name}：未检测到 PDF/X 声明")
                    if settings.preflight_colors:
                        colors = set(deep["colors"])
                        if "DeviceRGB" in colors:
                            warnings.append(f"[{idx}] {name}：检测到 DeviceRGB 内容，印刷前请确认是否需要转 CMYK")
                        if "Separation" in colors or "DeviceN" in colors:
                            infos.append(f"[{idx}] {name}：检测到专色/DeviceN 颜色空间")
                        if "DeviceCMYK" in colors:
                            infos.append(f"[{idx}] {name}：检测到 DeviceCMYK 内容")
                    if settings.preflight_graphics:
                        inks = deep.get("production_inks", {})
                        if inks.get("cut"):
                            infos.append(f"[{idx}] {name}：刀线/模切专色：" + "、".join(inks["cut"][:8]))
                        if inks.get("white"):
                            infos.append(f"[{idx}] {name}：白墨专色：" + "、".join(inks["white"][:8]))
                        if inks.get("varnish"):
                            infos.append(f"[{idx}] {name}：光油/Spot UV 专色：" + "、".join(inks["varnish"][:8]))
                        if inks.get("other"):
                            infos.append(f"[{idx}] {name}：其他专色：" + "、".join(inks["other"][:8]))
                        if deep.get("overprint"):
                            infos.append(f"[{idx}] {name}：检测到 Overprint（叠印）图形状态，请确认黑色叠印/专色叠印符合工艺")
                        if deep.get("transparency"):
                            signals = "、".join(deep.get("transparency_signals", [])[:5])
                            pdfx_ver = str(deep.get("pdfx", {}).get("version", "")).lower()
                            if "x-1" in pdfx_ver:
                                warnings.append(f"[{idx}] {name}：检测到透明度（{signals or '透明图形状态'}），与 PDF/X-1a 的扁平化生产流程需重点核对")
                            else:
                                infos.append(f"[{idx}] {name}：检测到透明度（{signals or '透明图形状态'}）")
                    if settings.preflight_images and deep["images"]:
                        # Page fitting scales raster content with the page. Estimate the worst final DPI.
                        scale_candidates = []
                        sw0, sh0 = page_size_mm(pages[0], settings.source_box)
                        for tw, th in targets:
                            scale_candidates.append(min(tw / sw0, th / sh0))
                        page_scale = min(scale_candidates, key=lambda r: abs(1.0-r)) if scale_candidates else 1.0
                        min_dpi = min(x["min_dpi"] / max(page_scale, 1e-9) for x in deep["images"])
                        if min_dpi < settings.min_image_dpi:
                            warnings.append(f"[{idx}] {name}：检测到低分辨率图片，预计最低约 {min_dpi:.0f} DPI（阈值 {settings.min_image_dpi} DPI）")
                        else:
                            infos.append(f"[{idx}] {name}：栅格图片预计最低约 {min_dpi:.0f} DPI")
                elif suffix in {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".webp", ".bmp"} and settings.preflight_images:
                    raster = analyze_raster_prepress(job.path, fw, fh)
                    dpi = raster["effective_dpi"]
                    if dpi is not None and dpi < settings.min_image_dpi:
                        warnings.append(f"[{idx}] {name}：位图 {raster['pixels'][0]}×{raster['pixels'][1]} px，按成品预计仅 {dpi:.0f} DPI")
                    elif dpi is not None:
                        infos.append(f"[{idx}] {name}：位图预计 {dpi:.0f} DPI")
                    if settings.preflight_colors and raster["mode"] in {"RGB", "RGBA", "P"}:
                        warnings.append(f"[{idx}] {name}：位图颜色模式为 {raster['mode']}，印刷前请确认 CMYK 转换策略")
            except Exception as exc:
                warnings.append(f"[{idx}] {name}：深度印前检查未完成：{exc}")

            if settings.duplex:
                for p in range(0, len(pages), 2):
                    if p + 1 >= len(pages):
                        break
                    fw0, fh0 = page_size_mm(pages[p], settings.source_box)
                    bw0, bh0 = page_size_mm(pages[p + 1], settings.source_box)
                    if abs(fw0 - bw0) > 0.5 or abs(fh0 - bh0) > 0.5:
                        warnings.append(
                            f"[{idx}] {name}：正反页尺寸不一致（{fw0:.2f}×{fh0:.2f} vs {bw0:.2f}×{bh0:.2f} mm）"
                        )
                        break

            infos.append(f"[{idx}] {name}：{len(pages)} 页 × 数量 {job.quantity}，成品 {trim_w:.2f}×{trim_h:.2f} mm，出血 {bleed:.2f} mm")

        if settings.variable_data_path and (settings.item_qr_enabled or settings.item_serial_enabled or settings.item_text_template.strip()):
            try:
                records = load_variable_records(settings.variable_data_path)
                if not records:
                    errors.append("变量数据文件没有可用记录")
                elif len(records) < expected_variable_items:
                    msg = f"变量数据只有 {len(records)} 行，但本次需要 {expected_variable_items} 件"
                    if settings.variable_data_strict:
                        errors.append(msg)
                    else:
                        warnings.append(msg + "；不足部分将回退为流水号/空字段")
                else:
                    infos.append(f"变量数据：{len(records)} 行，可覆盖本次 {expected_variable_items} 件")
            except Exception as exc:
                errors.append(f"变量数据读取失败：{exc}")

        if settings.smart_mixed_sizes and not errors:
            try:
                estimate = estimate_smart_layout(jobs, settings)
                infos.append(
                    f"智能混拼预计：{estimate['sheet_count']} 张纸，平均有效面积利用率 {estimate['utilization_percent']:.1f}%"
                )
            except Exception as exc:
                errors.append(f"智能混拼计算失败：{exc}")
    finally:
        lib.close()

    return {"errors": errors, "warnings": warnings, "infos": infos}


def _smart_impose_jobs(
    loaded_jobs: list[tuple[InputJob, list]],
    output_path: str | Path,
    settings: ImpositionSettings,
    library: SourceLibrary,
    layout_override: dict | None = None,
) -> dict:
    specs: list[_PackSpec] = []
    source_units = 0
    job_summaries = []
    front_units: dict[tuple[int, int], object] = {}
    back_units: dict[tuple[int, int], object] = {}

    for job_index, (job, pages) in enumerate(loaded_jobs):
        trim_w, trim_h, bleed = job.effective_trim(settings)
        unit_index = 0
        if settings.duplex:
            if len(pages) % 2:
                raise ValueError(f"双面模式要求每个源文件页数为偶数：{Path(job.path).name} 当前为 {len(pages)} 页")
            pair_count = len(pages) // 2
            source_units += pair_count
            placed = pair_count * job.quantity
            job_summaries.append({
                "path": str(job.path), "name": job.name or Path(job.path).stem,
                "quantity": job.quantity, "source_units": pair_count, "placed_items": placed,
                "trim_width_mm": trim_w, "trim_height_mm": trim_h, "bleed_mm": bleed,
            })
            for p in range(0, len(pages), 2):
                for _copy in range(job.quantity):
                    specs.append(_PackSpec(job_index, unit_index, trim_w, trim_h, bleed))
                    front_units[(job_index, unit_index)] = pages[p]
                    back_units[(job_index, unit_index)] = pages[p + 1]
                    unit_index += 1
        else:
            source_units += len(pages)
            placed = len(pages) * job.quantity
            job_summaries.append({
                "path": str(job.path), "name": job.name or Path(job.path).stem,
                "quantity": job.quantity, "source_units": len(pages), "placed_items": placed,
                "trim_width_mm": trim_w, "trim_height_mm": trim_h, "bleed_mm": bleed,
            })
            for page in pages:
                for _copy in range(job.quantity):
                    specs.append(_PackSpec(job_index, unit_index, trim_w, trim_h, bleed))
                    front_units[(job_index, unit_index)] = page
                    unit_index += 1

    packed = _packing_from_manual_layout(layout_override, specs, settings) if layout_override is not None else _pack_specs(specs, settings)
    writer = PdfWriter()
    sheet_w_pt = mm(settings.sheet_width_mm)
    sheet_h_pt = mm(settings.sheet_height_mm)
    sheet_count = len(packed.sheets)

    for sheet_idx, placements in enumerate(packed.sheets, 1):
        util = packed.per_sheet_utilization[sheet_idx - 1]
        if settings.duplex:
            front = writer.add_blank_page(width=sheet_w_pt, height=sheet_h_pt)
            back = writer.add_blank_page(width=sheet_w_pt, height=sheet_h_pt)
            back_placements = []
            for placement in placements:
                key = (placement.job_index, placement.unit_index)
                _place_packed_page(front, front_units[key], placement, settings)
                back_p = _mirror_packed_placement(placement, settings)
                back_placements.append(back_p)
                _place_packed_page(back, back_units[key], back_p, settings)

            if settings.crop_marks or settings.registration_marks or settings.center_marks or settings.sheet_info or settings.barcode_enabled or settings.qr_enabled or settings.item_qr_enabled or settings.item_serial_enabled or settings.item_text_template.strip():
                front_marks = _marks_overlay(
                    settings, trim_rects=[p.trim_rect for p in placements], sheet_index=sheet_idx,
                    total_sheets=sheet_count, side="正面", utilization=util, item_serial_base=sum(len(x) for x in packed.sheets[:sheet_idx-1]),
                ).pages[0]
                back_marks = _marks_overlay(
                    settings, trim_rects=[p.trim_rect for p in back_placements], sheet_index=sheet_idx,
                    total_sheets=sheet_count, side="反面", utilization=util, item_serial_base=sum(len(x) for x in packed.sheets[:sheet_idx-1]),
                ).pages[0]
                front.merge_page(front_marks, over=True, expand=False)
                back.merge_page(back_marks, over=True, expand=False)
        else:
            dest = writer.add_blank_page(width=sheet_w_pt, height=sheet_h_pt)
            for placement in placements:
                key = (placement.job_index, placement.unit_index)
                _place_packed_page(dest, front_units[key], placement, settings)
            if settings.crop_marks or settings.registration_marks or settings.center_marks or settings.sheet_info or settings.barcode_enabled or settings.qr_enabled or settings.item_qr_enabled or settings.item_serial_enabled or settings.item_text_template.strip():
                marks = _marks_overlay(
                    settings, trim_rects=[p.trim_rect for p in placements], sheet_index=sheet_idx,
                    total_sheets=sheet_count, side="单面", utilization=util, item_serial_base=sum(len(x) for x in packed.sheets[:sheet_idx-1]),
                ).pages[0]
                dest.merge_page(marks, over=True, expand=False)

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("wb") as f:
        writer.write(f)

    total_items = packed.total_items
    separate_sheet_estimate = 0
    # Conservative separate-design estimate: pack each job alone with same smart algorithm.
    for job_index, item in enumerate(job_summaries):
        job_specs = [s for s in specs if s.job_index == job_index]
        separate_sheet_estimate += len(_pack_specs(job_specs, settings).sheets) if job_specs else 0

    return {
        "output": str(output_path),
        "source_pages": len(library.pages),
        "source_units": source_units,
        "total_items": total_items,
        "rows": None,
        "cols": None,
        "capacity_per_sheet": None,
        "sheet_count": sheet_count,
        "output_pages": sheet_count * (2 if settings.duplex else 1),
        "rotation": "mixed" if settings.auto_rotate else settings.rotation,
        "duplex": settings.duplex,
        "duplex_alignment": "镜像Y轴位置" if ((settings.duplex_flip == "long") == (settings.sheet_width_mm >= settings.sheet_height_mm)) else "镜像X轴位置",
        "bleed_mm": None,
        "job_count": len(loaded_jobs),
        "job_summaries": job_summaries,
        "separate_sheet_estimate": separate_sheet_estimate,
        "sheets_saved_by_mixing": max(0, separate_sheet_estimate - sheet_count),
        "smart_mixed_sizes": True,
        "manual_layout": layout_override is not None,
        "utilization_percent": packed.utilization_percent,
        "per_sheet_utilization": packed.per_sheet_utilization,
        "max_items_on_sheet": max((len(s) for s in packed.sheets), default=0),
    }


def impose_jobs(jobs: Sequence[InputJob], output_path: str | Path, settings: ImpositionSettings, layout_override: dict | None = None) -> dict:
    if not jobs:
        raise ValueError("请先添加至少一个 PDF 或图片文件")
    for job in jobs:
        job.validate()

    settings.validate()
    library = SourceLibrary()

    try:
        loaded_jobs: list[tuple[InputJob, list]] = []
        for job in jobs:
            pages = list(library.add(job.path))
            if not pages:
                raise ValueError(f"文件中没有可用页面：{job.path}")
            loaded_jobs.append((job, pages))

        # Align cropbox with the operator-selected box so pypdf clipping honors it.
        for page in library.pages:
            selected_box = copy.deepcopy(_source_box(page, settings.source_box))
            page.cropbox = selected_box

        if settings.smart_mixed_sizes:
            return _smart_impose_jobs(loaded_jobs, output_path, settings, library, layout_override=layout_override)
        if layout_override is not None:
            raise ValueError("手工版位仅支持异尺寸智能混拼模式")

        grid = calculate_grid(settings)
        writer = PdfWriter()
        sheet_w_pt = mm(settings.sheet_width_mm)
        sheet_h_pt = mm(settings.sheet_height_mm)
        job_summaries = []

        if settings.duplex:
            pairs = []
            source_units = 0
            for job, pages in loaded_jobs:
                if len(pages) % 2:
                    raise ValueError(
                        f"双面模式要求每个源文件页数为偶数：{Path(job.path).name} 当前为 {len(pages)} 页"
                    )
                pair_count = len(pages) // 2
                source_units += pair_count
                produced = pair_count * job.quantity
                job_summaries.append({
                    "path": str(job.path), "quantity": job.quantity,
                    "source_units": pair_count, "placed_items": produced,
                })
                for i in range(0, len(pages), 2):
                    for _ in range(job.quantity):
                        pairs.append((pages[i], pages[i + 1]))

            sheet_count = math.ceil(len(pairs) / grid.capacity)
            per_sheet_util = []
            usable_area = (settings.sheet_width_mm - 2 * settings.margin_x_mm) * (settings.sheet_height_mm - 2 * settings.margin_y_mm)
            item_area = grid.footprint_width_mm * grid.footprint_height_mm
            for sheet_index in range(sheet_count):
                front = writer.add_blank_page(width=sheet_w_pt, height=sheet_h_pt)
                back = writer.add_blank_page(width=sheet_w_pt, height=sheet_h_pt)
                chunk = pairs[sheet_index * grid.capacity : (sheet_index + 1) * grid.capacity]

                for slot_index, (front_page, back_page) in enumerate(chunk):
                    row = slot_index // grid.cols
                    col = slot_index % grid.cols
                    _place_page(front, front_page, row, col, settings, grid)
                    back_row, back_col = _mapped_back_slot(row, col, grid, settings)
                    _place_page(back, back_page, back_row, back_col, settings, grid)

                util = min(100.0, len(chunk) * item_area / usable_area * 100.0) if usable_area > 0 else 0.0
                per_sheet_util.append(util)
                if settings.crop_marks or settings.registration_marks or settings.center_marks or settings.sheet_info or settings.barcode_enabled or settings.qr_enabled or settings.item_qr_enabled or settings.item_serial_enabled or settings.item_text_template.strip():
                    front_item_rects = []
                    back_item_rects = []
                    for slot_index in range(len(chunk)):
                        row = slot_index // grid.cols; col = slot_index % grid.cols
                        front_item_rects.append(_trim_rect(settings, grid, row, col))
                        br, bc = _mapped_back_slot(row, col, grid, settings)
                        back_item_rects.append(_trim_rect(settings, grid, br, bc))
                    front_marks = _marks_overlay(settings, grid=grid, sheet_index=sheet_index + 1, total_sheets=sheet_count, side="正面", utilization=util, item_serial_base=sheet_index * grid.capacity, item_rects=front_item_rects).pages[0]
                    back_marks = _marks_overlay(settings, grid=grid, sheet_index=sheet_index + 1, total_sheets=sheet_count, side="反面", utilization=util, item_serial_base=sheet_index * grid.capacity, item_rects=back_item_rects).pages[0]
                    front.merge_page(front_marks, over=True, expand=False)
                    back.merge_page(back_marks, over=True, expand=False)

            total_items = len(pairs)
            output_pages = sheet_count * 2
        else:
            sequence = []
            source_units = 0
            for job, pages in loaded_jobs:
                source_units += len(pages)
                produced = len(pages) * job.quantity
                job_summaries.append({
                    "path": str(job.path), "quantity": job.quantity,
                    "source_units": len(pages), "placed_items": produced,
                })
                for page in pages:
                    sequence.extend([page] * job.quantity)

            sheet_count = math.ceil(len(sequence) / grid.capacity)
            per_sheet_util = []
            usable_area = (settings.sheet_width_mm - 2 * settings.margin_x_mm) * (settings.sheet_height_mm - 2 * settings.margin_y_mm)
            item_area = grid.footprint_width_mm * grid.footprint_height_mm
            for sheet_index in range(sheet_count):
                dest = writer.add_blank_page(width=sheet_w_pt, height=sheet_h_pt)
                chunk = sequence[sheet_index * grid.capacity : (sheet_index + 1) * grid.capacity]
                for slot_index, source_page in enumerate(chunk):
                    row = slot_index // grid.cols
                    col = slot_index % grid.cols
                    _place_page(dest, source_page, row, col, settings, grid)
                util = min(100.0, len(chunk) * item_area / usable_area * 100.0) if usable_area > 0 else 0.0
                per_sheet_util.append(util)
                if settings.crop_marks or settings.registration_marks or settings.center_marks or settings.sheet_info or settings.barcode_enabled or settings.qr_enabled or settings.item_qr_enabled or settings.item_serial_enabled or settings.item_text_template.strip():
                    item_rects = [_trim_rect(settings, grid, i // grid.cols, i % grid.cols) for i in range(len(chunk))]
                    marks = _marks_overlay(settings, grid=grid, sheet_index=sheet_index + 1, total_sheets=sheet_count, side="单面", utilization=util, item_serial_base=sheet_index * grid.capacity, item_rects=item_rects).pages[0]
                    dest.merge_page(marks, over=True, expand=False)

            total_items = len(sequence)
            output_pages = sheet_count

        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with output_path.open("wb") as f:
            writer.write(f)

        separate_sheet_estimate = 0
        for item in job_summaries:
            separate_sheet_estimate += math.ceil(item["placed_items"] / grid.capacity)
        sheets_saved_by_mixing = max(0, separate_sheet_estimate - sheet_count)
        avg_util = sum(per_sheet_util) / len(per_sheet_util) if per_sheet_util else 0.0

        return {
            "output": str(output_path),
            "source_pages": len(library.pages),
            "source_units": source_units,
            "total_items": total_items,
            "rows": grid.rows,
            "cols": grid.cols,
            "capacity_per_sheet": grid.capacity,
            "sheet_count": sheet_count,
            "output_pages": output_pages,
            "rotation": grid.effective_rotation,
            "duplex": settings.duplex,
            "duplex_alignment": "网格镜像",
            "bleed_mm": settings.bleed_mm,
            "job_count": len(jobs),
            "job_summaries": job_summaries,
            "separate_sheet_estimate": separate_sheet_estimate,
            "sheets_saved_by_mixing": sheets_saved_by_mixing,
            "smart_mixed_sizes": False,
            "utilization_percent": avg_util,
            "per_sheet_utilization": per_sheet_util,
            "max_items_on_sheet": grid.capacity,
        }
    finally:
        library.close()


def impose(input_paths: Sequence[str | Path], output_path: str | Path, settings: ImpositionSettings) -> dict:
    """Backward-compatible helper: apply settings.copies_per_page to every source file."""
    jobs = [InputJob(path=path, quantity=settings.copies_per_page) for path in input_paths]
    return impose_jobs(jobs, output_path, settings)
