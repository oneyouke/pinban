from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
import json
import xml.etree.ElementTree as ET

JDF_NS='http://www.CIP4.org/JDFSchema_1_1'
ET.register_namespace('',JDF_NS)

def q(name): return f'{{{JDF_NS}}}{name}'

@dataclass(frozen=True)
class JDFJob:
    job_id:str
    job_part_id:str='Part-1'
    customer:str=''
    amount:int=1
    media_name:str=''
    sheet_width_mm:float=0.0
    sheet_height_mm:float=0.0
    output_pdf:str=''
    device_id:str=''


def build_jdf(job:JDFJob)->bytes:
    """Build a conservative JDF 1.6-style job ticket subset.

    This is an interoperability baseline, not CIP4 certification. Device/RIP
    vendors may require additional resources and namespaces.
    """
    if not job.job_id: raise ValueError('job_id 不能为空')
    root=ET.Element(q('JDF'),{
        'Type':'Product','JobID':job.job_id,'JobPartID':job.job_part_id,
        'Status':'Waiting','Version':'1.6','DescriptiveName':job.customer or job.job_id,
    })
    audit=ET.SubElement(root,q('AuditPool'))
    ET.SubElement(audit,q('Created'),{'TimeStamp':datetime.now(timezone.utc).isoformat(timespec='seconds')})
    pool=ET.SubElement(root,q('ResourcePool'))
    comp=ET.SubElement(pool,q('Component'),{'ID':'OutputComponent','Class':'Quantity','Status':'Available','Amount':str(max(1,job.amount))})
    if job.output_pdf: comp.set('FileSpecURL',Path(job.output_pdf).as_uri() if Path(job.output_pdf).is_absolute() else job.output_pdf)
    media=ET.SubElement(pool,q('Media'),{'ID':'Media','Class':'Consumable','Status':'Available','DescriptiveName':job.media_name or 'Sheet'})
    if job.sheet_width_mm>0 and job.sheet_height_mm>0:
        media.set('Dimension',f'{job.sheet_width_mm*72/25.4:.3f} {job.sheet_height_mm*72/25.4:.3f}')
    if job.device_id:
        ET.SubElement(pool,q('Device'),{'ID':'Device','Class':'Implementation','Status':'Available','DeviceID':job.device_id})
    return ET.tostring(root,encoding='utf-8',xml_declaration=True)


def save_jdf(job:JDFJob,path:str|Path):
    Path(path).write_bytes(build_jdf(job)); return str(path)


def build_cip3_ppf_metadata(job:JDFJob)->str:
    """Generate a minimal CIP3 PPF metadata header for downstream adapters.

    Ink-zone bitmap generation is RIP-specific and intentionally not faked here.
    """
    return '\n'.join([
        '%!PS-Adobe-3.0',
        '%%CIP3-File Version 2.1',
        f'%%CIP3-JobName: {job.job_id}',
        f'%%CIP3-Customer: {job.customer}',
        f'%%CIP3-SheetSizeMM: {job.sheet_width_mm:.3f} {job.sheet_height_mm:.3f}',
        f'%%CIP3-Amount: {max(1,job.amount)}',
        '%%CIP3-Note: Metadata baseline only; no ink-zone preview encoded',
        '%%EOF',
    ])+'\n'
