from pathlib import Path
from tempfile import TemporaryDirectory
from datetime import datetime, timedelta, timezone
from storage import ProductionDB
from device_center import DeviceRegistry, DeviceProfile
from inventory import InventoryManager, StockItem
from routing import RoutingManager, RouteStep
from logistics import LogisticsManager
from tooling import ToolLifeManager
from smart_factory import SmartFactoryOptimizer


def main():
  with TemporaryDirectory() as td:
    td=Path(td); db=ProductionDB(td/'factory.sqlite3')
    reg=DeviceRegistry(td/'devices.json')
    reg.save([
      DeviceProfile(id='press1',name='Press',kind='press',production_speed_sph=6000,setup_minutes=15,hourly_cost=300,max_sheet_width_mm=740,max_sheet_height_mm=520),
      DeviceProfile(id='lam1',name='Laminator',kind='finishing',production_speed_sph=3000,setup_minutes=10,hourly_cost=120,capabilities={'laminate':True}),
      DeviceProfile(id='die1',name='DieCutter',kind='finishing',production_speed_sph=2500,setup_minutes=12,hourly_cost=150,capabilities={'diecut':True}),
    ])
    inv=InventoryManager(db); inv.upsert(StockItem('PAPER-SRA3','SRA3 铜版纸',on_hand=1000,reorder_point=300,reorder_qty=1000)); inv.receive('PAPER-SRA3',500,'LOT-A','Supplier')
    inv.reserve('PAPER-SRA3',200,'JOB1'); assert inv.get('PAPER-SRA3').available==1300
    inv.reserve('PAPER-SRA3',1100,'JOB2'); assert inv.reorder_suggestions()[0]['sku']=='PAPER-SRA3'
    assert inv.create_purchase_requests()
    jid=db.enqueue('Job','out.pdf',{'settings':{'sheet_width_mm':450,'sheet_height_mm':320},'jobs':[{'quantity':1000}]})
    routing=RoutingManager(db,reg); routing.save_route('卡盒',[RouteStep(10,'print','press',15),RouteStep(20,'laminate','finishing',10,20,'laminate'),RouteStep(30,'diecut','finishing',12,25,'diecut')])
    plan=routing.plan_job(jid,'卡盒',1000); assert [x['operation'] for x in plan]==['print','laminate','diecut']; assert len(routing.gantt(jid))==3
    tool=ToolLifeManager(db); tool.upsert('DIE-1','卡盒刀模',10000,8900); d=tool.add_cycles('DIE-1',200); assert d['status']=='service_due'; d=tool.add_cycles('DIE-1',1000); assert d['status']=='expired'
    log=LogisticsManager(db); log.create_unit('PAL-001','O1',500,'LOT-1','P1'); log.scan('PAL-001','SHIP','Dock A'); assert log.qr_payload('PAL-001','DELIVER').startswith('DILOG1|')
    opt=SmartFactoryOptimizer(db,inv,routing); due=(datetime.now(timezone.utc)+timedelta(hours=8)).isoformat(); s=opt.score_path(jid,'卡盒',1000,{'PAPER-SRA3':100},due_at=due,margin=25); assert s.inventory_ok and s.total_minutes>0
    print('V1.7 PASS')
if __name__=='__main__': main()
