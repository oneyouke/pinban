from __future__ import annotations
from datetime import datetime, timezone
from storage import ProductionDB


def utc_now(): return datetime.now(timezone.utc).isoformat(timespec='seconds')

class LogisticsManager:
    def __init__(self, db: ProductionDB):
        self.db=db; self._init_schema()
    def _init_schema(self):
        with self.db.connect() as c:
            c.executescript('''
            CREATE TABLE IF NOT EXISTS logistics_units(id INTEGER PRIMARY KEY AUTOINCREMENT,unit_code TEXT UNIQUE NOT NULL,order_id TEXT NOT NULL DEFAULT '',lot_no TEXT NOT NULL DEFAULT '',pallet_no TEXT NOT NULL DEFAULT '',qty INTEGER NOT NULL DEFAULT 0,status TEXT NOT NULL DEFAULT 'packed',location TEXT NOT NULL DEFAULT '',updated_at TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS logistics_events(id INTEGER PRIMARY KEY AUTOINCREMENT,unit_code TEXT NOT NULL,event TEXT NOT NULL,location TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL);
            ''')
    def create_unit(self,unit_code:str,order_id:str,qty:int,lot_no:str='',pallet_no:str=''):
        with self.db.connect() as c:
            c.execute('INSERT INTO logistics_units(unit_code,order_id,lot_no,pallet_no,qty,updated_at) VALUES(?,?,?,?,?,?)',(unit_code,order_id,lot_no,pallet_no,int(qty),utc_now()))
            c.execute('INSERT INTO logistics_events(unit_code,event,created_at) VALUES(?,?,?)',(unit_code,'packed',utc_now()))
    def scan(self,unit_code:str,event:str,location:str=''):
        status_map={'PACK':'packed','WAREHOUSE':'stored','LOAD':'loaded','SHIP':'shipped','DELIVER':'delivered'}
        status=status_map.get(event.upper(),event.lower())
        with self.db.connect() as c:
            if not c.execute('SELECT 1 FROM logistics_units WHERE unit_code=?',(unit_code,)).fetchone(): raise ValueError('物流单元不存在')
            c.execute('UPDATE logistics_units SET status=?,location=?,updated_at=? WHERE unit_code=?',(status,location,utc_now(),unit_code))
            c.execute('INSERT INTO logistics_events(unit_code,event,location,created_at) VALUES(?,?,?,?)',(unit_code,event.upper(),location,utc_now()))
    @staticmethod
    def qr_payload(unit_code:str,event:str='WAREHOUSE')->str:
        return f'DILOG1|{unit_code}|{event.upper()}'
