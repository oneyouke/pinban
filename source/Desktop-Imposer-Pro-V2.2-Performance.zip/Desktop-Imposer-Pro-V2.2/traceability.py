from __future__ import annotations
from datetime import datetime, timezone
import uuid

def utc_now(): return datetime.now(timezone.utc).isoformat(timespec='seconds')

class TraceabilityManager:
    def __init__(self, db):
        self.db=db
        with db.connect() as c:
            c.executescript('''
            CREATE TABLE IF NOT EXISTS production_lots(
              id INTEGER PRIMARY KEY AUTOINCREMENT, lot_code TEXT NOT NULL UNIQUE, run_id INTEGER NOT NULL,
              quantity INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'open', created_at TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS pallets(
              id INTEGER PRIMARY KEY AUTOINCREMENT, pallet_code TEXT NOT NULL UNIQUE, lot_id INTEGER NOT NULL,
              quantity INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'open', created_at TEXT NOT NULL);
            ''')
    def new_lot(self, run_id:int, quantity:int, lot_code:str='') -> str:
        code=lot_code or ('LOT-'+uuid.uuid4().hex[:10].upper())
        with self.db.connect() as c:
            c.execute('INSERT INTO production_lots(lot_code,run_id,quantity,created_at) VALUES(?,?,?,?)',(code,run_id,max(0,quantity),utc_now()))
        return code
    def new_pallet(self, lot_code:str, quantity:int, pallet_code:str='') -> str:
        with self.db.connect() as c:
            row=c.execute('SELECT id FROM production_lots WHERE lot_code=?',(lot_code,)).fetchone()
            if not row: raise ValueError('lot not found')
            code=pallet_code or ('PLT-'+uuid.uuid4().hex[:10].upper())
            c.execute('INSERT INTO pallets(pallet_code,lot_id,quantity,created_at) VALUES(?,?,?,?)',(code,int(row['id']),max(0,quantity),utc_now()))
        return code
