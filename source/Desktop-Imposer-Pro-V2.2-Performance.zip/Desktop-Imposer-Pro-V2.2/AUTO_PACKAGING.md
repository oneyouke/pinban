# V2.1 Windows 自动封装

V2.1 在原有自动封装链上增加 `test_v21.py`。构建顺序为 Core → Commercial → V1.1…V1.9 → V2.0 → V2.1 → release gate → PyInstaller → frozen self-test → Portable/NSIS/signing。任一回归失败均停止发布。

# Windows 自动封装

V1.5 的 `BUILD_WINDOWS_DESKTOP.bat` 会依次运行 V1.0～V1.5 回归测试、发布闸门、PyInstaller 封装、自检、Portable ZIP 和 NSIS 安装包。生产控制台、调度器、ERP/JMF 模块均通过 `app.py` 自动进入 PyInstaller 依赖图。


## 最简单用法

在 Windows 10/11 x64 上解压源码后，双击：

```text
BUILD_WINDOWS_DESKTOP.bat
```

脚本会自动：

1. 创建独立 `.venv-build` 构建环境；
2. 安装运行依赖与固定版本 PyInstaller；
3. 执行编译检查、拼版引擎测试和商用基础测试；
4. 运行发布闸门；
5. 使用 PyInstaller `onedir` 封装桌面程序；
6. 启动封装后的 EXE 进行 Qt/PDF 无界面自检；
7. 生成 Portable ZIP、SHA-256 和 release manifest；
8. 如果电脑安装了 NSIS，再自动生成 `Setup-x64.exe`。

最终文件统一放在：

```text
release\
```

## 为什么使用 onedir

本软件依赖 QtPdf / QtPdfWidgets、字体/图形组件、Pillow、cryptography 等动态模块。`onedir` 启动更快，也更容易验证 Qt 插件完整性。对客户而言仍然通过 Setup.exe 安装，安装后就是普通 Windows 桌面软件。

## NSIS

安装 NSIS 后，一键脚本会自动发现 `makensis.exe` 并生成安装包。若没有 NSIS，构建不会白跑：仍然会生成可直接解压运行的 Portable ZIP。

## 正式商业签名版

先完成：

- `product.py` 中真实公司/品牌/App ID/售后邮箱；
- 正式 EULA；
- Windows 代码签名证书已导入当前用户/机器证书库；
- Windows SDK 中 `signtool.exe` 可用。

然后双击：

```text
BUILD_SIGNED_COMMERCIAL_RELEASE.bat
```

该模式会启用 `release_gate.py --strict`，并对 EXE 和 Setup.exe 执行 SHA-256 Authenticode 签名与时间戳。

## GitHub 自动构建

项目包含 `.github/workflows/windows-desktop-release.yml`。推送 `v*` 标签或手动运行 workflow 时，会在 GitHub 的 Windows runner 上自动构建桌面 EXE、Portable ZIP 和 NSIS Setup.exe，并上传构建产物。标签构建还会自动创建/更新 GitHub Release。

> 代码签名证书属于私密资产，不应提交到仓库。CI 正式签名应通过 GitHub Secrets + 硬件/云签名服务接入。


V1.8 构建前增加 `test_v18.py` 商业运营回归测试。


## V1.9 回归闸门

Windows 自动封装现在按顺序执行 `test_engine.py`、`test_commercial.py`、`test_v11.py` ... `test_v19.py`，任何失败都会终止发布。
