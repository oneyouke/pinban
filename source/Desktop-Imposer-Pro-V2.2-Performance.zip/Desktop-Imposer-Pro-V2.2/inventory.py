from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any
from storage import ProductionDB


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


@dataclass(frozen=True)
class StockItem:
    sku: str
    name: str
    category: str = "paper"
    unit: str = "sheet"
    on_hand: float = 0.0
    reserved: float = 0.0
    reorder_point: float = 0.0
    reorder_qty: float = 0.0
    lot_tracking: bool = True

    @property
    def available(self) -> float:
        return self.on_hand - self.reserved


class InventoryManager:
    def __init__(self, db: ProductionDB):
        self.db = db
        self._init_schema()

    def _init_schema(self) -> None:
        with self.db.connect() as c:
            c.executescript('''
            CREATE TABLE IF NOT EXISTS inventory_items(
              sku TEXT PRIMARY KEY, name TEXT NOT NULL, category TEXT NOT NULL,
              unit TEXT NOT NULL, on_hand REAL NOT NULL DEFAULT 0,
              reserved REAL NOT NULL DEFAULT 0, reorder_point REAL NOT NULL DEFAULT 0,
              reorder_qty REAL NOT NULL DEFAULT 0, lot_tracking INTEGER NOT NULL DEFAULT 1,
              updated_at TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS inventory_lots(
              id INTEGER PRIMARY KEY AUTOINCREMENT, sku TEXT NOT NULL, lot_no TEXT NOT NULL,
              qty REAL NOT NULL DEFAULT 0, supplier TEXT NOT NULL DEFAULT '', received_at TEXT NOT NULL,
              UNIQUE(sku,lot_no));
            CREATE TABLE IF NOT EXISTS inventory_moves(
              id INTEGER PRIMARY KEY AUTOINCREMENT, sku TEXT NOT NULL, move_type TEXT NOT NULL,
              qty REAL NOT NULL, lot_no TEXT NOT NULL DEFAULT '', ref TEXT NOT NULL DEFAULT '',
              created_at TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS purchase_requests(
              id INTEGER PRIMARY KEY AUTOINCREMENT, sku TEXT NOT NULL, qty REAL NOT NULL,
              status TEXT NOT NULL DEFAULT 'open', reason TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL);
            ''')

    def upsert(self, item: StockItem) -> None:
        with self.db.connect() as c:
            c.execute('''INSERT INTO inventory_items(sku,name,category,unit,on_hand,reserved,reorder_point,reorder_qty,lot_tracking,updated_at)
            VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(sku) DO UPDATE SET name=excluded.name,category=excluded.category,
            unit=excluded.unit,reorder_point=excluded.reorder_point,reorder_qty=excluded.reorder_qty,lot_tracking=excluded.lot_tracking,updated_at=excluded.updated_at''',
            (item.sku,item.name,item.category,item.unit,item.on_hand,item.reserved,item.reorder_point,item.reorder_qty,int(item.lot_tracking),utc_now()))

    def get(self, sku: str) -> StockItem | None:
        with self.db.connect() as c:
            r=c.execute('SELECT * FROM inventory_items WHERE sku=?',(sku,)).fetchone()
        if not r: return None
        d=dict(r)
        return StockItem(d['sku'],d['name'],d['category'],d['unit'],d['on_hand'],d['reserved'],d['reorder_point'],d['reorder_qty'],bool(d['lot_tracking']))

    def receive(self, sku: str, qty: float, lot_no: str='', supplier: str='') -> None:
        if qty <= 0: raise ValueError('收货数量必须大于 0')
        now=utc_now()
        with self.db.connect() as c:
            if not c.execute('SELECT 1 FROM inventory_items WHERE sku=?',(sku,)).fetchone():
                raise ValueError(f'库存物料不存在: {sku}')
            c.execute('UPDATE inventory_items SET on_hand=on_hand+?,updated_at=? WHERE sku=?',(qty,now,sku))
            if lot_no:
                c.execute('''INSERT INTO inventory_lots(sku,lot_no,qty,supplier,received_at) VALUES(?,?,?,?,?)
                ON CONFLICT(sku,lot_no) DO UPDATE SET qty=qty+excluded.qty''',(sku,lot_no,qty,supplier,now))
            c.execute('INSERT INTO inventory_moves(sku,move_type,qty,lot_no,created_at) VALUES(?,?,?,?,?)',(sku,'receive',qty,lot_no,now))

    def reserve(self, sku: str, qty: float, ref: str='') -> None:
        item=self.get(sku)
        if not item: raise ValueError(f'库存物料不存在: {sku}')
        if qty <= 0: raise ValueError('预留数量必须大于 0')
        if item.available + 1e-9 < qty: raise ValueError(f'{sku} 库存不足：可用 {item.available:g}，需要 {qty:g}')
        with self.db.connect() as c:
            c.execute('UPDATE inventory_items SET reserved=reserved+?,updated_at=? WHERE sku=?',(qty,utc_now(),sku))
            c.execute('INSERT INTO inventory_moves(sku,move_type,qty,ref,created_at) VALUES(?,?,?,?,?)',(sku,'reserve',qty,ref,utc_now()))

    def consume(self, sku: str, qty: float, ref: str='') -> None:
        item=self.get(sku)
        if not item or item.on_hand + 1e-9 < qty: raise ValueError(f'{sku} 实物库存不足')
        with self.db.connect() as c:
            c.execute('UPDATE inventory_items SET on_hand=on_hand-?,reserved=MAX(0,reserved-?),updated_at=? WHERE sku=?',(qty,qty,utc_now(),sku))
            c.execute('INSERT INTO inventory_moves(sku,move_type,qty,ref,created_at) VALUES(?,?,?,?,?)',(sku,'consume',qty,ref,utc_now()))

    def reorder_suggestions(self) -> list[dict[str, Any]]:
        with self.db.connect() as c:
            rows=c.execute('SELECT * FROM inventory_items WHERE (on_hand-reserved)<=reorder_point ORDER BY category,sku').fetchall()
        out=[]
        for r in rows:
            d=dict(r); available=d['on_hand']-d['reserved']; qty=max(d['reorder_qty'], d['reorder_point']-available)
            out.append({'sku':d['sku'],'name':d['name'],'available':available,'suggest_qty':max(0,qty)})
        return out

    def create_purchase_requests(self) -> list[int]:
        ids=[]
        with self.db.connect() as c:
            for s in self.reorder_suggestions():
                exists=c.execute("SELECT 1 FROM purchase_requests WHERE sku=? AND status='open'",(s['sku'],)).fetchone()
                if exists: continue
                cur=c.execute('INSERT INTO purchase_requests(sku,qty,reason,created_at) VALUES(?,?,?,?)',(s['sku'],s['suggest_qty'],'低于补货点',utc_now()))
                ids.append(int(cur.lastrowid))
        return ids
