# V2.1.6 Installation smoke-test fix

现场已经确认：
- Python 检测成功；
- 虚拟环境成功；
- pip / setuptools / wheel 安装成功；
- 失败发生在 `test_engine.py` 开发回归测试。

产品安装器不应该用完整开发回归测试作为安装门槛。

V2.1.6 改为：
- 安装阶段只运行 `install_smoke_test.py`；
- 检查 PySide6 / QtPdf / pypdf / ReportLab / Pillow；
- 实际生成一页 PDF；
- 通过拼版核心输出一页生产 PDF；
- 再用 pypdf 重新读取验证；
- 完整 `test_engine.py` 及 V1.x/V2.x 回归仅在 `-FullTests` 或正式发布机执行。
