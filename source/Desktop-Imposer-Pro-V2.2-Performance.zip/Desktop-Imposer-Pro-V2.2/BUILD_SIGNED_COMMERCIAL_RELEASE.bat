@echo off
setlocal
cd /d %~dp0

echo 正式签名发布模式。
echo 请先在 product.py / EULA_TEMPLATE.txt 填好真实品牌与法律信息。
echo.
set /p CERT=请输入 Windows 代码签名证书 Thumbprint（留空取消）: 
if "%CERT%"=="" exit /b 1
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0auto_package_windows.ps1" -Strict -CertThumbprint "%CERT%"
set ERR=%ERRORLEVEL%
if not "%ERR%"=="0" pause
exit /b %ERR%
