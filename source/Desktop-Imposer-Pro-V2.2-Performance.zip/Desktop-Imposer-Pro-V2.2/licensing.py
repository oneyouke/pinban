from __future__ import annotations

import base64
import hashlib
import json
import os
import platform
import socket
import subprocess
import sys
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

from app_paths import license_path, state_path
from product import APP_ID, APP_VERSION, DEFAULT_TRIAL_DAYS, LICENSE_SCHEMA_VERSION


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _iso(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).isoformat(timespec="seconds")


def canonical_bytes(payload: dict[str, Any]) -> bytes:
    return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def sign_payload(payload: dict[str, Any], private_key_pem: bytes) -> str:
    key = serialization.load_pem_private_key(private_key_pem, password=None)
    if not isinstance(key, Ed25519PrivateKey):
        raise TypeError("需要 Ed25519 私钥")
    return base64.b64encode(key.sign(canonical_bytes(payload))).decode("ascii")


def verify_payload(payload: dict[str, Any], signature_b64: str, public_key_pem: bytes) -> bool:
    try:
        key = serialization.load_pem_public_key(public_key_pem)
        if not isinstance(key, Ed25519PublicKey):
            return False
        key.verify(base64.b64decode(signature_b64), canonical_bytes(payload))
        return True
    except Exception:
        return False


def generate_keypair() -> tuple[bytes, bytes]:
    private = Ed25519PrivateKey.generate()
    public = private.public_key()
    private_pem = private.private_bytes(
        serialization.Encoding.PEM,
        serialization.PrivateFormat.PKCS8,
        serialization.NoEncryption(),
    )
    public_pem = public.public_bytes(
        serialization.Encoding.PEM,
        serialization.PublicFormat.SubjectPublicKeyInfo,
    )
    return private_pem, public_pem


def _platform_machine_id() -> str:
    candidates: list[str] = []
    if sys.platform.startswith("win"):
        try:
            import winreg  # type: ignore
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography") as key:
                value, _ = winreg.QueryValueEx(key, "MachineGuid")
                candidates.append(str(value))
        except Exception:
            pass
    elif sys.platform == "darwin":
        try:
            out = subprocess.check_output(["ioreg", "-rd1", "-c", "IOPlatformExpertDevice"], text=True, timeout=2)
            for line in out.splitlines():
                if "IOPlatformUUID" in line and "=" in line:
                    candidates.append(line.split("=", 1)[1].strip().strip('"'))
        except Exception:
            pass
    else:
        for path in (Path("/etc/machine-id"), Path("/var/lib/dbus/machine-id")):
            try:
                value = path.read_text(encoding="utf-8").strip()
                if value:
                    candidates.append(value)
                    break
            except Exception:
                pass
    candidates.extend([platform.node(), socket.gethostname(), platform.system(), platform.machine()])
    return "|".join(x for x in candidates if x)


def machine_fingerprint() -> str:
    raw = f"{APP_ID}|{_platform_machine_id()}".encode("utf-8", errors="ignore")
    return hashlib.sha256(raw).hexdigest()


@dataclass(frozen=True)
class LicenseStatus:
    mode: str  # licensed/trial/expired/invalid
    valid: bool
    customer: str = ""
    edition: str = "Trial"
    license_id: str = ""
    expires_at: str = ""
    days_remaining: int = 0
    message: str = ""
    features: tuple[str, ...] = ()


class LicenseManager:
    def __init__(self, public_key_path: str | Path | None = None) -> None:
        self.public_key_path = Path(public_key_path) if public_key_path else Path(__file__).with_name("vendor_public_key.pem")

    def _public_key(self) -> bytes | None:
        try:
            return self.public_key_path.read_bytes()
        except Exception:
            return None

    def install_license(self, src: str | Path) -> LicenseStatus:
        raw = json.loads(Path(src).read_text(encoding="utf-8"))
        status = self.validate_document(raw)
        if not status.valid or status.mode != "licensed":
            raise ValueError(status.message or "许可证无效")
        dst = license_path()
        dst.parent.mkdir(parents=True, exist_ok=True)
        tmp = dst.with_suffix(".tmp")
        tmp.write_text(json.dumps(raw, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(tmp, dst)
        return status

    def validate_document(self, doc: dict[str, Any]) -> LicenseStatus:
        payload = doc.get("payload")
        signature = doc.get("signature")
        public = self._public_key()
        if not isinstance(payload, dict) or not isinstance(signature, str) or not public:
            return LicenseStatus("invalid", False, message="许可证结构无效或产品公钥未配置")
        if not verify_payload(payload, signature, public):
            return LicenseStatus("invalid", False, message="许可证签名校验失败")
        if payload.get("schema_version") != LICENSE_SCHEMA_VERSION or payload.get("product_id") != APP_ID:
            return LicenseStatus("invalid", False, message="许可证不属于当前产品")
        bound = str(payload.get("machine_fingerprint") or "").strip()
        if bound and bound != machine_fingerprint():
            return LicenseStatus("invalid", False, message="许可证已绑定到另一台设备")
        expires = str(payload.get("expires_at") or "").strip()
        days = 999999
        if expires:
            try:
                expiry = datetime.fromisoformat(expires.replace("Z", "+00:00"))
                delta = expiry - _utc_now()
                days = max(0, int(delta.total_seconds() // 86400) + (1 if delta.total_seconds() > 0 else 0))
                if delta.total_seconds() <= 0:
                    return LicenseStatus(
                        "expired", False, customer=str(payload.get("customer") or ""),
                        edition=str(payload.get("edition") or "Pro"), license_id=str(payload.get("license_id") or ""),
                        expires_at=expires, days_remaining=0, message="商业许可证已过期",
                        features=tuple(payload.get("features") or ()),
                    )
            except Exception:
                return LicenseStatus("invalid", False, message="许可证到期时间格式错误")
        return LicenseStatus(
            "licensed", True, customer=str(payload.get("customer") or ""),
            edition=str(payload.get("edition") or "Pro"), license_id=str(payload.get("license_id") or ""),
            expires_at=expires, days_remaining=days, message="商业许可证有效",
            features=tuple(payload.get("features") or ()),
        )

    def _trial_status(self) -> LicenseStatus:
        path = state_path()
        now = _utc_now()
        state: dict[str, Any] = {}
        existed = path.exists()
        if existed:
            try:
                state = json.loads(path.read_text(encoding="utf-8"))
            except Exception:
                return LicenseStatus("invalid", False, edition="Trial", message="试用状态文件损坏；请联系软件供应商")
        first = state.get("trial_started_at")
        fingerprint = machine_fingerprint()
        stored_fp = str(state.get("machine_fingerprint") or "")
        if stored_fp and stored_fp != fingerprint:
            return LicenseStatus("invalid", False, edition="Trial", message="试用状态与当前设备不匹配")
        if not first:
            if existed:
                return LicenseStatus("invalid", False, edition="Trial", message="试用状态缺少首次运行时间；请联系软件供应商")
            first = _iso(now)
            state = {"trial_started_at": first, "machine_fingerprint": fingerprint, "app_version": APP_VERSION, "last_seen_at": first}
            path.parent.mkdir(parents=True, exist_ok=True)
            tmp = path.with_suffix(".tmp")
            tmp.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
            os.replace(tmp, path)
        try:
            started = datetime.fromisoformat(str(first).replace("Z", "+00:00"))
        except Exception:
            return LicenseStatus("invalid", False, edition="Trial", message="试用状态时间无效；请联系软件供应商")
        last_text = str(state.get("last_seen_at") or first)
        try:
            last_seen = datetime.fromisoformat(last_text.replace("Z", "+00:00"))
        except Exception:
            last_seen = started
        if now + timedelta(minutes=5) < last_seen:
            return LicenseStatus("invalid", False, edition="Trial", message="检测到系统时间明显回拨，试用生产输出已停用")
        expiry = started + timedelta(days=DEFAULT_TRIAL_DAYS)
        remaining_seconds = (expiry - now).total_seconds()
        remaining = max(0, int(remaining_seconds // 86400) + (1 if remaining_seconds > 0 else 0))
        # Persist the furthest observed time. This is a best-effort offline trial guard.
        state.update({"machine_fingerprint": fingerprint, "last_seen_at": _iso(max(now, last_seen)), "app_version": APP_VERSION})
        try:
            tmp = path.with_suffix(".tmp")
            tmp.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
            os.replace(tmp, path)
        except Exception:
            pass
        if remaining_seconds <= 0:
            return LicenseStatus("expired", False, edition="Trial", expires_at=_iso(expiry), message="试用期已结束")
        return LicenseStatus(
            "trial", True, edition="Trial", expires_at=_iso(expiry), days_remaining=remaining,
            message=f"试用版剩余 {remaining} 天", features=("core", "preflight", "hotfolder", "variable_data"),
        )

    def status(self) -> LicenseStatus:
        try:
            doc = json.loads(license_path().read_text(encoding="utf-8"))
            status = self.validate_document(doc)
            if status.mode == "licensed":
                return status
            # A malformed/expired installed license should not silently become a fresh trial.
            return status
        except FileNotFoundError:
            return self._trial_status()
        except Exception as exc:
            return LicenseStatus("invalid", False, message=f"许可证读取失败：{exc}")


def issue_license(private_key_pem: bytes, *, license_id: str, customer: str, edition: str = "Pro",
                  expires_at: str = "", machine: str = "", features: list[str] | None = None) -> dict[str, Any]:
    payload = {
        "schema_version": LICENSE_SCHEMA_VERSION,
        "product_id": APP_ID,
        "license_id": license_id,
        "customer": customer,
        "edition": edition,
        "issued_at": _iso(_utc_now()),
        "expires_at": expires_at,
        "machine_fingerprint": machine,
        "features": features or ["core", "preflight", "hotfolder", "variable_data", "queue"],
    }
    return {"payload": payload, "signature": sign_payload(payload, private_key_pem)}
