from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from product import APP_NAME, APP_VERSION, PROJECT_SCHEMA_VERSION


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def build_project_snapshot(jobs, settings, layout_override=None, automation=None, ui=None) -> dict[str, Any]:
    job_rows = []
    for job in jobs:
        job_rows.append({
            "path": str(Path(job.path).resolve()),
            "quantity": int(job.quantity),
            "trim_width_mm": float(job.trim_width_mm) if job.trim_width_mm is not None else None,
            "trim_height_mm": float(job.trim_height_mm) if job.trim_height_mm is not None else None,
            "bleed_mm": float(job.bleed_mm) if job.bleed_mm is not None else None,
            "name": str(job.name or Path(job.path).stem),
        })
    return {
        "schema_version": PROJECT_SCHEMA_VERSION,
        "app": APP_NAME,
        "app_version": APP_VERSION,
        "saved_at": utc_now(),
        "jobs": job_rows,
        "settings": settings.to_dict(),
        "layout": layout_override,
        "automation": automation or {},
        "ui": ui or {},
    }


def save_project(path: str | Path, snapshot: dict[str, Any]) -> Path:
    dst = Path(path)
    if dst.suffix.lower() != ".imposeproj":
        dst = dst.with_suffix(".imposeproj")
    dst.parent.mkdir(parents=True, exist_ok=True)
    payload = dict(snapshot)
    payload["saved_at"] = utc_now()
    tmp = dst.with_suffix(dst.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8", newline="\n") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, dst)
    return dst


def load_project(path: str | Path) -> dict[str, Any]:
    src = Path(path)
    data = json.loads(src.read_text(encoding="utf-8"))
    version = int(data.get("schema_version", 0))
    if version != PROJECT_SCHEMA_VERSION:
        raise ValueError(f"不支持的项目文件版本：{version}，当前支持 {PROJECT_SCHEMA_VERSION}")
    if not isinstance(data.get("jobs"), list) or not isinstance(data.get("settings"), dict):
        raise ValueError("项目文件缺少 jobs/settings")
    return data
