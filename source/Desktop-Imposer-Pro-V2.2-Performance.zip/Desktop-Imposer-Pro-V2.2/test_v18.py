from tempfile import TemporaryDirectory
from pathlib import Path
from storage import ProductionDB
from commercial import CommercialManager, QuoteLine

def main():
    with TemporaryDirectory() as td:
        db=ProductionDB(Path(td)/'db.sqlite'); m=CommercialManager(db)
        m.upsert_customer('C001','测试客户',payment_terms_days=30)
        q=m.create_quote('Q001','C001',[QuoteLine('名片',1000,0.5,0.28,0.06)])
        assert q['total']==530.0 and q['estimated_margin']>0.4
        o=m.accept_quote('Q001','SO001','2026-09-01T12:00:00+00:00'); assert o['status']=='confirmed'
        m.set_order_actual_costs('SO001',material_cost=120,press_cost=70,finishing_cost=30,labor_cost=20,logistics_cost=10)
        p=m.order_profit('SO001'); assert p['actual_cost']==250 and p['profit']==280
        inv=m.create_invoice('INV001','SO001','2026-09-30'); assert inv['amount']==530
        inv=m.record_payment('INV001',200); assert inv['status']=='partial' and inv['paid']==200
        inv=m.record_payment('INV001',330); assert inv['status']=='paid'
        po=m.create_purchase_order('PO001','纸张供应商',[{'sku':'PAPER-SRA3','qty':1000,'unit_cost':0.45}]); assert po['total']==450
        m.receive_material_batch('B001','PAPER-SRA3',100,0.4); m.receive_material_batch('B002','PAPER-SRA3',100,0.5)
        assert m.consume_material_fifo('PAPER-SRA3',150)==65.0
        d=m.dashboard(); assert d['revenue']==530 and d['actual_profit']==280 and d['accounts_receivable']==0
        print('V1.8 PASS')
if __name__=='__main__': main()
