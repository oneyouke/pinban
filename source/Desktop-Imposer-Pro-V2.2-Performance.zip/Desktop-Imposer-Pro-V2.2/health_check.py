from __future__ import annotations

import json
import shutil
import sqlite3
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any

from app_paths import data_dir, config_dir, database_path
from backup_scheduler import ScheduledBackupService
from runtime_resilience import AuditTrail


@dataclass(frozen=True)
class CheckResult:
    name: str
    status: str
    detail: str


def run_health_checks(min_free_mb: int = 1024) -> dict[str, Any]:
    results: list[CheckResult] = []
    db_path = database_path()
    try:
        if db_path.exists():
            with sqlite3.connect(db_path) as db:
                integrity = db.execute("PRAGMA integrity_check").fetchone()[0]
            results.append(CheckResult("database", "ok" if str(integrity).lower() == "ok" else "error", str(integrity)))
        else:
            results.append(CheckResult("database", "warning", "database not created yet"))
    except Exception as exc:
        results.append(CheckResult("database", "error", str(exc)))

    usage = shutil.disk_usage(data_dir())
    free_mb = usage.free // (1024 * 1024)
    results.append(CheckResult("disk_space", "ok" if free_mb >= min_free_mb else "warning", f"free={free_mb} MB"))

    try:
        svc = ScheduledBackupService()
        policy = svc.load_policy()
        results.append(CheckResult("automatic_backup", "ok" if policy.enabled else "warning", f"enabled={policy.enabled}, interval={policy.interval_hours}h"))
    except Exception as exc:
        results.append(CheckResult("automatic_backup", "error", str(exc)))

    try:
        audit = AuditTrail(db_path)
        verified = audit.verify()
        results.append(CheckResult("audit_chain", "ok" if verified.get("ok") else "error", json.dumps(verified, ensure_ascii=False)))
    except Exception as exc:
        results.append(CheckResult("audit_chain", "error", str(exc)))

    overall = "ok"
    if any(x.status == "error" for x in results):
        overall = "error"
    elif any(x.status == "warning" for x in results):
        overall = "warning"
    return {"overall": overall, "checks": [asdict(x) for x in results]}
