@echo off
setlocal
cd /d %~dp0

python -m pip install --upgrade pip
python -m pip install -r requirements.txt pyinstaller
python test_engine.py || exit /b 1
python test_commercial.py || exit /b 1
python test_v11.py || exit /b 1
python test_v12.py || exit /b 1
python test_v13.py || exit /b 1
python test_v14.py || exit /b 1
python test_v15.py || exit /b 1
python test_v16.py || exit /b 1
python test_v17.py || exit /b 1
python test_v18.py || exit /b 1
python test_v19.py
if errorlevel 1 exit /b 1
python test_v20.py || exit /b 1
python release_gate.py || exit /b 1
pyinstaller --noconfirm --clean DesktopImposer.spec || exit /b 1

echo.
echo Build complete: dist\DesktopImposerPro\DesktopImposerPro.exe
echo For a customer installer, configure and run build_release.ps1.
endlocal
