from __future__ import annotations
from dataclasses import dataclass, asdict
from math import ceil

@dataclass(frozen=True)
class Spread:
    sheet: int
    side: str
    left: int | None
    right: int | None
    signature: int = 1
    creep_mm: float = 0.0

    def to_dict(self):
        return asdict(self)


def _pad_pages(page_count:int, multiple:int) -> int:
    if page_count < 1:
        raise ValueError('页数必须大于 0')
    if multiple < 1:
        raise ValueError('补页倍数必须大于 0')
    return int(ceil(page_count / multiple) * multiple)


def saddle_stitch(page_count:int, creep_per_sheet_mm:float=0.0) -> list[Spread]:
    """2-up saddle-stitch page order. None represents a blank page.

    Creep is reported as metadata (positive value means inner sheet compensation).
    Actual geometric creep application is left to the page-placement layer.
    """
    total = _pad_pages(page_count, 4)
    def p(n): return n if n <= page_count else None
    out=[]
    sheets=total//4
    for i in range(sheets):
        creep = max(0.0, float(creep_per_sheet_mm)) * i
        out.append(Spread(i+1,'front',p(total-2*i),p(1+2*i),1,creep))
        out.append(Spread(i+1,'back',p(2+2*i),p(total-1-2*i),1,creep))
    return out


def signatures(page_count:int, signature_pages:int=16, creep_per_sheet_mm:float=0.0) -> list[list[Spread]]:
    """Split a book into independent saddle-style signatures (sections).

    Common values are 8/12/16/24/32 pages. The final section is padded to a
    multiple of four rather than silently stealing pages from the prior section.
    """
    if signature_pages < 4 or signature_pages % 4:
        raise ValueError('每帖页数必须是 4 的倍数且至少为 4')
    if page_count < 1:
        raise ValueError('页数必须大于 0')
    result=[]
    first=1
    signature_no=1
    while first<=page_count:
        actual=min(signature_pages,page_count-first+1)
        local_total=_pad_pages(actual,4)
        local=saddle_stitch(local_total, creep_per_sheet_mm)
        mapped=[]
        for s in local:
            def m(v):
                if v is None: return None
                g=first+v-1
                return g if g<=page_count else None
            mapped.append(Spread(s.sheet,s.side,m(s.left),m(s.right),signature_no,s.creep_mm))
        result.append(mapped)
        first += actual
        signature_no += 1
    return result


def perfect_bound_sections(page_count:int, signature_pages:int=16, creep_per_sheet_mm:float=0.0) -> list[list[Spread]]:
    """Section-sewn / perfect-bound signature planning baseline.

    This produces independent folded sections; binding/trim/creep geometry is
    exposed as metadata and can be consumed by a press-specific fold template.
    """
    return signatures(page_count, signature_pages, creep_per_sheet_mm)


def flat_sheet_pairs(page_count:int, duplex:bool=True) -> list[Spread]:
    """Sequential 2-up flat-sheet pairs for loose-leaf/digital jobs."""
    if page_count < 1:
        raise ValueError('页数必须大于 0')
    total=_pad_pages(page_count, 2)
    out=[]
    sheet=1
    i=1
    while i<=total:
        left=i if i<=page_count else None
        right=i+1 if i+1<=page_count else None
        out.append(Spread(sheet,'front',left,right))
        if duplex:
            # The next pair is the reverse side of the same physical sheet.
            i += 2
            if i<=total:
                left=i if i<=page_count else None
                right=i+1 if i+1<=page_count else None
                out.append(Spread(sheet,'back',left,right))
        sheet += 1
        i += 2
    return out
