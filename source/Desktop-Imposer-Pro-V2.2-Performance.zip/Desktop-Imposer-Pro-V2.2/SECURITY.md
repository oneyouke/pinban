# Security Notes

## Secrets

- The application must never contain a license-signing private key.
- Windows code-signing PFX/P12 files must not be stored in the source tree or release artifact.
- `release_gate.py` blocks common private-key/certificate file patterns.
- The runtime public key is not secret.

## Customer artwork

- PDF/image artwork is processed locally.
- The production SQLite database stores metadata and snapshots, not PDF bytes.
- Support bundles intentionally omit customer artwork and the production database.
- `.production.json` sidecars include local input paths and file hashes for traceability; treat them as production records.

## External professional preflight

`DESKTOP_IMPOSER_PREFLIGHT_CLI` executes an administrator-configured local command. Configure it only to a trusted executable installed by the print shop/vendor.

## Updates

Update manifests are signed with the vendor Ed25519 key and must be fetched over HTTPS. A future downloader must verify both manifest signature and downloaded package SHA-256 before execution.
