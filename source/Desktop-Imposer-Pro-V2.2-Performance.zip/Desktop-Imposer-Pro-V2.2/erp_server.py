from __future__ import annotations

from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from threading import Thread
from urllib.parse import urlparse
import json
import queue
import uuid

from integration import ProductionTicket


@dataclass(frozen=True)
class ERPRequest:
    request_id: str
    ticket: ProductionTicket


class ERPBridge:
    """Local-only ERP intake queue suitable for LAN reverse-proxy integration."""
    def __init__(self):
        self.queue: queue.Queue[ERPRequest] = queue.Queue()

    def submit(self, payload: dict) -> ERPRequest:
        ticket = ProductionTicket(**payload)
        if not ticket.order_id:
            raise ValueError("order_id 不能为空")
        req = ERPRequest(uuid.uuid4().hex, ticket)
        self.queue.put(req)
        return req


class _Handler(BaseHTTPRequestHandler):
    bridge: ERPBridge | None = None
    api_token: str = ""

    def _json(self, status: int, payload: dict):
        raw = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers(); self.wfile.write(raw)

    def _authorized(self) -> bool:
        if not self.api_token:
            return True
        return self.headers.get("Authorization", "") == f"Bearer {self.api_token}"

    def do_GET(self):
        if urlparse(self.path).path == "/health":
            self._json(200, {"ok": True, "service": "DesktopImposer ERP Bridge"})
        else:
            self._json(404, {"error": "not_found"})

    def do_POST(self):
        if urlparse(self.path).path != "/v1/jobs":
            return self._json(404, {"error": "not_found"})
        if not self._authorized():
            return self._json(401, {"error": "unauthorized"})
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length <= 0 or length > 5 * 1024 * 1024:
                raise ValueError("请求体为空或过大")
            payload = json.loads(self.rfile.read(length).decode("utf-8"))
            req = self.bridge.submit(payload) if self.bridge else None
            self._json(202, {"accepted": True, "request_id": req.request_id if req else ""})
        except Exception as exc:
            self._json(400, {"error": "invalid_job", "message": str(exc)})

    def log_message(self, format, *args):
        return


class ERPApiServer:
    def __init__(self, bridge: ERPBridge | None = None):
        self.bridge = bridge or ERPBridge()
        self.server: ThreadingHTTPServer | None = None
        self.thread: Thread | None = None

    def start(self, host: str = "127.0.0.1", port: int = 0, api_token: str = "") -> tuple[str, int]:
        if self.server:
            raise RuntimeError("ERP API 已启动")
        handler = type("ERPHandler", (_Handler,), {"bridge": self.bridge, "api_token": api_token})
        self.server = ThreadingHTTPServer((host, int(port)), handler)
        self.thread = Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        addr = self.server.server_address
        return str(addr[0]), int(addr[1])

    def stop(self):
        if self.server:
            self.server.shutdown(); self.server.server_close()
        if self.thread:
            self.thread.join(timeout=2)
        self.server = None; self.thread = None
