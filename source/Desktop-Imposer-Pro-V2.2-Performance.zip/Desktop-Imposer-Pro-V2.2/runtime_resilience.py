from __future__ import annotations

import hashlib
import json
import os
import sqlite3
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from app_paths import data_dir, database_path
from product import APP_NAME, APP_VERSION


def _utc() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


@dataclass(frozen=True)
class RecoveryState:
    previous_unclean_shutdown: bool
    marker_path: str
    started_at: str


class CrashMarker:
    """Detect unclean application shutdowns without storing customer content."""

    def __init__(self, path: str | Path | None = None) -> None:
        self.path = Path(path) if path else data_dir() / "runtime" / "running.json"
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def begin(self) -> RecoveryState:
        previous = self.path.exists()
        started = _utc()
        temp = self.path.with_suffix(".tmp")
        temp.write_text(json.dumps({
            "app": APP_NAME,
            "version": APP_VERSION,
            "pid": os.getpid(),
            "started_at": started,
        }, ensure_ascii=False, indent=2), encoding="utf-8")
        temp.replace(self.path)
        return RecoveryState(previous, str(self.path), started)

    def clean_shutdown(self) -> None:
        self.path.unlink(missing_ok=True)


class AuditTrail:
    """Tamper-evident local administrative audit trail using a SHA-256 hash chain."""

    def __init__(self, db_path: str | Path | None = None) -> None:
        self.path = Path(db_path) if db_path else database_path()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(self.path) as db:
            db.execute("""
                CREATE TABLE IF NOT EXISTS security_audit_v21 (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    occurred_at TEXT NOT NULL,
                    actor TEXT NOT NULL,
                    action TEXT NOT NULL,
                    target TEXT NOT NULL DEFAULT '',
                    details_json TEXT NOT NULL,
                    previous_hash TEXT NOT NULL,
                    entry_hash TEXT NOT NULL UNIQUE
                )
            """)

    @staticmethod
    def _hash(payload: dict[str, Any]) -> str:
        raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
        return hashlib.sha256(raw).hexdigest()

    def append(self, actor: str, action: str, target: str = "", details: dict[str, Any] | None = None) -> str:
        with sqlite3.connect(self.path, timeout=15) as db:
            row = db.execute("SELECT entry_hash FROM security_audit_v21 ORDER BY id DESC LIMIT 1").fetchone()
            prev = row[0] if row else "0" * 64
            payload = {
                "occurred_at": _utc(),
                "actor": actor or "system",
                "action": action,
                "target": target,
                "details": details or {},
                "previous_hash": prev,
            }
            digest = self._hash(payload)
            db.execute(
                "INSERT INTO security_audit_v21(occurred_at,actor,action,target,details_json,previous_hash,entry_hash) VALUES(?,?,?,?,?,?,?)",
                (payload["occurred_at"], payload["actor"], action, target,
                 json.dumps(payload["details"], ensure_ascii=False, sort_keys=True), prev, digest),
            )
            return digest

    def verify(self) -> dict[str, Any]:
        previous = "0" * 64
        checked = 0
        with sqlite3.connect(self.path) as db:
            rows = db.execute(
                "SELECT id,occurred_at,actor,action,target,details_json,previous_hash,entry_hash FROM security_audit_v21 ORDER BY id"
            ).fetchall()
        for row in rows:
            details = json.loads(row[5])
            payload = {
                "occurred_at": row[1], "actor": row[2], "action": row[3], "target": row[4],
                "details": details, "previous_hash": previous,
            }
            expected = self._hash(payload)
            if row[6] != previous or row[7] != expected:
                return {"ok": False, "checked": checked, "bad_id": row[0]}
            previous = row[7]
            checked += 1
        return {"ok": True, "checked": checked, "head_hash": previous}
