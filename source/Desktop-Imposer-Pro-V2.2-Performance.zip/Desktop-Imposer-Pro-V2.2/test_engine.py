from pathlib import Path
from tempfile import TemporaryDirectory

from reportlab.pdfgen import canvas
from pypdf import PdfReader, PdfWriter
from pypdf.generic import ArrayObject, BooleanObject, DecodedStreamObject, DictionaryObject, FloatObject, NameObject, NullObject, NumberObject, TextStringObject
from PIL import Image

from imposition import (
    InputJob, ImpositionSettings, calculate_grid, estimate_smart_layout,
    impose, impose_jobs, mm, preflight_jobs, plan_smart_layout, validate_manual_layout,
    analyze_pdf_prepress,
)
from hotfolder import HotFolderProcessor


def make_sample(path: Path, pages: int = 1, w_mm: float = 90, h_mm: float = 54):
    c = canvas.Canvas(str(path), pagesize=(mm(w_mm), mm(h_mm)))
    for i in range(pages):
        c.setFont("Helvetica-Bold", 18)
        c.drawString(mm(8), mm(max(8, h_mm / 2)), f"PAGE {i+1}")
        c.rect(mm(0.5), mm(0.5), mm(w_mm-1), mm(h_mm-1))
        c.showPage()
    c.save()




def make_prepress_signals_pdf(path: Path):
    writer = PdfWriter()
    page = writer.add_blank_page(width=200, height=200)
    resources = DictionaryObject()
    resources[NameObject("/ColorSpace")] = DictionaryObject({
        NameObject("/CS1"): ArrayObject([NameObject("/Separation"), NameObject("/CutContour"), NameObject("/DeviceCMYK"), NullObject()])
    })
    resources[NameObject("/ExtGState")] = DictionaryObject({
        NameObject("/GS1"): DictionaryObject({
            NameObject("/Type"): NameObject("/ExtGState"),
            NameObject("/OP"): BooleanObject(True),
            NameObject("/op"): BooleanObject(True),
            NameObject("/ca"): FloatObject(0.5),
        })
    })
    page[NameObject("/Resources")] = resources
    content = DecodedStreamObject()
    content.set_data(b"q /GS1 gs /CS1 cs 0.5 scn 10 10 50 50 re f Q")
    page[NameObject("/Contents")] = writer._add_object(content)

    profile = DecodedStreamObject(); profile.set_data(b"dummy-icc"); profile[NameObject("/N")] = NumberObject(4)
    output_intent = DictionaryObject({
        NameObject("/Type"): NameObject("/OutputIntent"),
        NameObject("/S"): NameObject("/GTS_PDFX"),
        NameObject("/OutputConditionIdentifier"): TextStringObject("FOGRA39"),
        NameObject("/DestOutputProfile"): writer._add_object(profile),
    })
    writer._root_object[NameObject("/GTS_PDFXVersion")] = TextStringObject("PDF/X-4")
    writer._root_object[NameObject("/OutputIntents")] = ArrayObject([writer._add_object(output_intent)])
    with path.open("wb") as f:
        writer.write(f)


def main():
    with TemporaryDirectory() as tmp_dir:
        tmp = Path(tmp_dir)
        one = tmp / "one.pdf"; two = tmp / "two.pdf"
        make_sample(one, 1); make_sample(two, 2)

        # Test 1: classic 90x54 on SRA3.
        s1 = ImpositionSettings(copies_per_page=20)
        g1 = calculate_grid(s1)
        assert g1.capacity == 20, g1
        out1 = tmp / "simplex.pdf"
        r1 = impose([one], out1, s1)
        assert len(PdfReader(str(out1)).pages) == 1
        assert r1["total_items"] == 20

        # Test 2: exact 1:1 production mode.
        s2 = ImpositionSettings(copies_per_page=5, scale_mode="actual", actual_size_tolerance_mm=0.2)
        out2 = tmp / "actual.pdf"
        impose([one], out2, s2)
        assert out2.stat().st_size > 0

        # Test 3: duplex mode; 2 source pages are front/back.
        s3 = ImpositionSettings(copies_per_page=25, duplex=True, duplex_flip="long")
        out3 = tmp / "duplex.pdf"
        r3 = impose([two], out3, s3)
        assert r3["sheet_count"] == 2
        assert r3["output_pages"] == 4
        assert len(PdfReader(str(out3)).pages) == 4

        # Test 4: bleed changes footprint/grid safely.
        s4 = ImpositionSettings(bleed_mm=3, gap_x_mm=4, gap_y_mm=4, auto_rotate=True)
        g4 = calculate_grid(s4)
        assert g4.capacity > 0

        # Test 5: production marks + sheet info + barcode.
        s5 = ImpositionSettings(
            copies_per_page=2, registration_marks=True, center_marks=True,
            sheet_info=True, barcode_enabled=True, order_no="SO-2026-001", customer_name="测试客户",
        )
        out5 = tmp / "marks.pdf"
        impose([one], out5, s5)
        assert out5.stat().st_size > 0

        # Test 6: same-size multi-design quantities share leftover sheet capacity.
        other = tmp / "other.pdf"; make_sample(other, 1)
        mix_out = tmp / "mixed.pdf"
        mix = impose_jobs([InputJob(one, 5), InputJob(other, 5)], mix_out, ImpositionSettings())
        assert mix["total_items"] == 10
        assert mix["sheet_count"] == 1
        assert mix["separate_sheet_estimate"] == 2
        assert mix["sheets_saved_by_mixing"] == 1

        # Test 7: exact mode rejects wrong source size.
        wrong = tmp / "wrong.pdf"; make_sample(wrong, 1, 80, 50)
        try:
            impose([wrong], tmp / "wrong_out.pdf", s2)
        except ValueError as exc:
            assert "1:1" in str(exc)
        else:
            raise AssertionError("Expected actual-size validation failure")

        # Test 8: true heterogeneous mixed-size packing.
        tag = tmp / "tag.pdf"; sticker = tmp / "sticker.pdf"
        make_sample(tag, 1, 50, 90)
        make_sample(sticker, 1, 40, 40)
        smart_settings = ImpositionSettings(
            smart_mixed_sizes=True, auto_rotate=True,
            gap_x_mm=3, gap_y_mm=3, margin_x_mm=8, margin_y_mm=8,
            crop_marks=True,
        )
        smart_jobs = [
            InputJob(one, 8, 90, 54, 0, "名片"),
            InputJob(tag, 6, 50, 90, 0, "吊牌"),
            InputJob(sticker, 12, 40, 40, 0, "贴纸"),
        ]
        est = estimate_smart_layout(smart_jobs, smart_settings, page_counts=[1, 1, 1])
        assert est["sheet_count"] >= 1
        assert est["total_items"] == 26
        assert 0 < est["utilization_percent"] <= 100
        smart_out = tmp / "smart.pdf"
        smart = impose_jobs(smart_jobs, smart_out, smart_settings)
        assert smart["smart_mixed_sizes"] is True
        assert smart["total_items"] == 26
        assert len(PdfReader(str(smart_out)).pages) == smart["sheet_count"]

        # Test 9: smart mixed-size duplex supports mirrored back placements.
        business_duplex = tmp / "business_duplex.pdf"
        tag_duplex = tmp / "tag_duplex.pdf"
        make_sample(business_duplex, 2, 90, 54)
        make_sample(tag_duplex, 2, 50, 90)
        smart_duplex_settings = ImpositionSettings(
            smart_mixed_sizes=True, auto_rotate=True, duplex=True, duplex_flip="long",
            crop_marks=True,
        )
        smart_duplex_out = tmp / "smart_duplex.pdf"
        smart_duplex = impose_jobs([
            InputJob(business_duplex, 5, 90, 54, 0, "名片双面"),
            InputJob(tag_duplex, 4, 50, 90, 0, "吊牌双面"),
        ], smart_duplex_out, smart_duplex_settings)
        assert smart_duplex["duplex"] is True
        assert smart_duplex["output_pages"] == smart_duplex["sheet_count"] * 2
        assert len(PdfReader(str(smart_duplex_out)).pages) == smart_duplex["output_pages"]

        # Test 10: editable manual layout can drive final production output.
        layout = plan_smart_layout(smart_jobs, smart_settings, page_counts=[1, 1, 1])
        check = validate_manual_layout(layout, smart_settings)
        assert not check["errors"], check
        manual_out = tmp / "manual_layout.pdf"
        manual = impose_jobs(smart_jobs, manual_out, smart_settings, layout_override=layout)
        assert manual["manual_layout"] is True
        assert manual["total_items"] == 26
        assert len(PdfReader(str(manual_out)).pages) == manual["sheet_count"]

        # Test 11: layout validator catches accidental overlap.
        import copy
        bad_layout = copy.deepcopy(layout)
        if len(bad_layout["sheets"][0]) >= 2:
            bad_layout["sheets"][0][1]["x_mm"] = bad_layout["sheets"][0][0]["x_mm"]
            bad_layout["sheets"][0][1]["y_mm"] = bad_layout["sheets"][0][0]["y_mm"]
            bad = validate_manual_layout(bad_layout, smart_settings)
            assert any("重叠" in msg or "间距" in msg for msg in bad["errors"]), bad

        # Test 12: QR + serial number marks render without breaking output.
        qr_settings = ImpositionSettings(
            copies_per_page=2, sheet_info=True, qr_enabled=True,
            serial_prefix="P-", serial_start=100, order_no="SO-QR-001",
        )
        qr_out = tmp / "qr_marks.pdf"
        impose([one], qr_out, qr_settings)
        assert qr_out.stat().st_size > 0

        # Test 13: preflight catches odd duplex page count and reports size/scaling info.
        odd = tmp / "odd.pdf"; make_sample(odd, 3, 90, 54)
        pf = preflight_jobs([InputJob(odd, 1, 90, 54, 0, "奇数页")], ImpositionSettings(duplex=True))
        assert any("偶数页" in msg for msg in pf["errors"])

        # Test 14: PDF deep preflight estimates effective image DPI and RGB usage.
        img = tmp / "lowdpi.png"
        Image.new("RGB", (300, 150), "white").save(img)
        image_pdf = tmp / "image.pdf"
        c = canvas.Canvas(str(image_pdf), pagesize=(mm(100), mm(50)))
        c.drawImage(str(img), 0, 0, width=mm(100), height=mm(50))
        c.showPage(); c.save()
        deep = analyze_pdf_prepress(image_pdf)
        assert deep["images"]
        assert 70 <= deep["min_image_dpi"] <= 80, deep
        assert "DeviceRGB" in deep["colors"]
        pf_dpi = preflight_jobs([InputJob(image_pdf, 1, 100, 50, 0, "低DPI")], ImpositionSettings(min_image_dpi=200))
        assert any("DPI" in msg for msg in pf_dpi["warnings"]), pf_dpi

        # Test 15: per-item QR / serial marks render in final production PDF.
        variable_settings = ImpositionSettings(
            smart_mixed_sizes=True, auto_rotate=True, item_qr_enabled=True, item_serial_enabled=True,
            serial_prefix="ITEM-", serial_start=1000, order_no="SO-VAR-001", crop_marks=True,
        )
        variable_out = tmp / "variable.pdf"
        variable = impose_jobs([InputJob(one, 3, 90, 54, 0, "可变码")], variable_out, variable_settings)
        assert variable["total_items"] == 3
        assert variable_out.stat().st_size > 0

        # Test 16: Hot Folder processes stable files and skips unchanged sources.
        hot_in = tmp / "hot_in"; hot_out = tmp / "hot_out"
        hot_in.mkdir(); hot_out.mkdir()
        watched = hot_in / "watch.pdf"
        make_sample(watched, 1, 90, 54)
        processor = HotFolderProcessor(settle_seconds=0)
        hot1 = processor.scan_once(hot_in, hot_out, ImpositionSettings(), quantity=2)
        assert len(hot1["processed"]) == 1, hot1
        assert (hot_out / "watch_imposed.pdf").exists()
        hot2 = processor.scan_once(hot_in, hot_out, ImpositionSettings(), quantity=2)
        assert len(hot2["processed"]) == 0, hot2

        # Test 17: PDF/X, spot cut line, overprint and transparency are detected.
        signals_pdf = tmp / "prepress_signals.pdf"
        make_prepress_signals_pdf(signals_pdf)
        signals = analyze_pdf_prepress(signals_pdf)
        assert signals["pdfx"]["declared"] is True, signals
        assert "CutContour" in signals["spot_colors"], signals
        assert "CutContour" in signals["production_inks"]["cut"], signals
        assert signals["overprint"] is True, signals
        assert signals["transparency"] is True, signals
        pf_signals = preflight_jobs([InputJob(signals_pdf, 1, 90, 54, 0, "印前信号")], ImpositionSettings())
        assert any("PDF/X-4" in msg for msg in pf_signals["infos"]), pf_signals
        assert any("刀线" in msg or "模切" in msg for msg in pf_signals["infos"]), pf_signals

        # Test 18: strict per-item variable data mapping validates row count and renders.
        variable_csv = tmp / "variable-data.csv"
        variable_csv.write_text("sku,name\nA001,张三\nA002,李四\n", encoding="utf-8-sig")
        mapped_settings = ImpositionSettings(
            smart_mixed_sizes=True, item_qr_enabled=True, item_serial_enabled=True,
            variable_data_path=str(variable_csv), item_qr_template="{sku}|{name}|{serial}",
            item_text_template="{name} {sku}", variable_data_strict=True, order_no="SO-DATA-001",
        )
        pf_var = preflight_jobs([InputJob(one, 2, 90, 54, 0, "变量")], mapped_settings)
        assert not pf_var["errors"], pf_var
        mapped_out = tmp / "mapped-variable.pdf"
        mapped = impose_jobs([InputJob(one, 2, 90, 54, 0, "变量")], mapped_out, mapped_settings)
        assert mapped["total_items"] == 2 and mapped_out.stat().st_size > 0
        short_csv = tmp / "short-variable.csv"
        short_csv.write_text("sku,name\nA001,张三\n", encoding="utf-8-sig")
        short_settings = ImpositionSettings(smart_mixed_sizes=True, item_qr_enabled=True, variable_data_path=str(short_csv), variable_data_strict=True)
        pf_short = preflight_jobs([InputJob(one, 2, 90, 54, 0, "变量不足")], short_settings)
        assert any("变量数据只有" in msg for msg in pf_short["errors"]), pf_short

        # Test 19: Hot Folder can archive success, isolate failure and append JSONL logs.
        hot7_in = tmp / "hot7_in"; hot7_out = tmp / "hot7_out"; archive = tmp / "archive"; failed = tmp / "failed"
        hot7_in.mkdir(); hot7_out.mkdir()
        good = hot7_in / "good.pdf"; make_sample(good, 1, 90, 54)
        log_path = tmp / "hotfolder.jsonl"
        processor7 = HotFolderProcessor(settle_seconds=0)
        hot_good = processor7.scan_once(hot7_in, hot7_out, ImpositionSettings(), archive_dir=archive, failed_dir=failed, log_path=log_path, move_success=True, move_failure=True)
        assert len(hot_good["processed"]) == 1, hot_good
        assert (archive / "good.pdf").exists() and not good.exists()
        bad_pdf = hot7_in / "broken.pdf"
        empty_writer = PdfWriter()
        with bad_pdf.open("wb") as f:
            empty_writer.write(f)
        hot_bad = processor7.scan_once(hot7_in, hot7_out, ImpositionSettings(), archive_dir=archive, failed_dir=failed, log_path=log_path, move_success=True, move_failure=True)
        assert hot_bad["errors"], hot_bad
        assert (failed / "broken.pdf").exists() and not bad_pdf.exists()
        log_text = log_path.read_text(encoding="utf-8")
        assert '"event": "success"' in log_text and '"event": "failure"' in log_text

        print("PASS")
        print({
            "simplex": r1,
            "duplex": r3,
            "same_size_mixed": mix,
            "smart_mixed": smart,
            "smart_duplex": smart_duplex,
            "smart_estimate": est,
            "preflight": pf,
        })


if __name__ == "__main__":
    main()
