from __future__ import annotations

from datetime import datetime, timedelta, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from tempfile import TemporaryDirectory
from threading import Thread
import json

from device_center import DeviceProfile, DeviceRegistry
from mes import MESManager
from production_scheduler import ProductionScheduler
from storage import ProductionDB
from workflow import ProductionWorkflow


def snapshot(qty=1000, sheet=(450, 320), colors=4, duplex=False):
    return {
        "jobs": [{"path": "dummy.pdf", "quantity": qty, "trim_width_mm": 90, "trim_height_mm": 54, "name": "Card"}],
        "settings": {"sheet_width_mm": sheet[0], "sheet_height_mm": sheet[1], "rows": 4, "cols": 5, "duplex": duplex},
        "required_colors": colors,
    }


def make_env(tmp: Path):
    db = ProductionDB(tmp / "mes.sqlite3")
    reg = DeviceRegistry(tmp / "devices.json")
    reg.save([
        DeviceProfile(id="press-a", name="A机", max_sheet_width_mm=520, max_sheet_height_mm=380, colors=4,
                      production_speed_sph=10000, setup_minutes=10, hourly_cost=800),
        DeviceProfile(id="press-b", name="B机", max_sheet_width_mm=520, max_sheet_height_mm=380, colors=4,
                      production_speed_sph=6000, setup_minutes=6, hourly_cost=650),
    ])
    scheduler = ProductionScheduler(db, reg)
    mes = MESManager(db, reg, scheduler)
    return db, reg, scheduler, mes


def test_gantt_and_changeover(tmp: Path):
    db, reg, sch, mes = make_env(tmp)
    j1 = db.enqueue("A-001", str(tmp / "a.pdf"), snapshot(1000, (450,320)))
    j2 = db.enqueue("A-002", str(tmp / "b.pdf"), snapshot(500, (450,320)))
    j3 = db.enqueue("B-001", str(tmp / "c.pdf"), snapshot(800, (500,350)))
    for i,j in enumerate((j1,j2,j3),1): sch.assign_job(j,"press-a",priority=i*10)
    order = mes.optimize_sequence("press-a", [j1,j3,j2])
    assert order.index(j2) < order.index(j3), order
    estimates = mes.build_gantt(start=datetime(2026,8,27,0,0,tzinfo=timezone.utc), persist=True)
    assert len(estimates) == 3
    assert estimates[0].planned_start.startswith("2026-08-27T00:00")
    runs = mes.list_runs(); assert len(runs) == 3
    assert all(r["planned_end"] for r in runs)


def test_auto_balance(tmp: Path):
    db, reg, sch, mes = make_env(tmp)
    ids = [db.enqueue(f"JOB-{i}", str(tmp/f"{i}.pdf"), snapshot(20000)) for i in range(3)]
    assigned = mes.auto_balance()
    assert len(assigned) == 3
    devices = {a["device_id"] for a in assigned}
    assert devices == {"press-a", "press-b"}, assigned


def test_reporting_oee_scan(tmp: Path):
    db, reg, sch, mes = make_env(tmp)
    jid = db.enqueue("OEE-1", str(tmp/"oee.pdf"), snapshot(1000))
    sch.assign_job(jid, "press-a", priority=1)
    rid = mes.ensure_run(jid, "press-a")
    code = mes.scan_code(rid, "START")
    assert mes.parse_scan(code) == (rid, "START")
    mes.execute_scan(code, operator="张三")
    mes.report_progress(rid, completed_sheets=100, good_count=950, waste_count=50)
    # Force a deterministic one-hour production window and 10 minute downtime.
    now = datetime.now(timezone.utc)
    start = now - timedelta(hours=1)
    with db.connect() as conn:
        conn.execute("UPDATE mes_runs SET actual_start=?, actual_end=?, status='completed', completed_sheets=100, good_count=950, waste_count=50 WHERE id=?",
                     (start.isoformat(timespec='seconds'), now.isoformat(timespec='seconds'), rid))
        conn.execute("INSERT INTO mes_downtime(run_id,device_id,reason_code,reason_text,started_at,ended_at,minutes,created_at) VALUES(?,?,?,?,?,?,?,?)",
                     (rid,'press-a','PAPER','换纸',(start+timedelta(minutes=20)).isoformat(timespec='seconds'),(start+timedelta(minutes=30)).isoformat(timespec='seconds'),10.0,start.isoformat(timespec='seconds')))
    rep = mes.oee('press-a', since=start-timedelta(seconds=1), until=now+timedelta(seconds=1))
    assert 82 <= rep.availability <= 84, rep
    assert rep.quality == 95.0
    assert 0 <= rep.oee <= 100


class CallbackHandler(BaseHTTPRequestHandler):
    payload = None
    def do_POST(self):
        n=int(self.headers.get('Content-Length','0')); type(self).payload=json.loads(self.rfile.read(n).decode('utf-8'))
        body=b'{"ok":true}'; self.send_response(200); self.send_header('Content-Length',str(len(body))); self.end_headers(); self.wfile.write(body)
    def log_message(self,*args): return


def test_workflow_callback(tmp: Path):
    db, reg, sch, mes = make_env(tmp)
    server=ThreadingHTTPServer(('127.0.0.1',0),CallbackHandler); th=Thread(target=server.serve_forever,daemon=True); th.start()
    try:
        url=f"http://127.0.0.1:{server.server_address[1]}/status"
        snap=snapshot(100); snap['erp']={'ticket':{'order_id':'ERP-15','metadata':{'status_callback_url':url}}}
        jid=db.enqueue('ERP-15',str(tmp/'erp.pdf'),snap); sch.assign_job(jid,'press-a')
        rid=mes.ensure_run(jid,'press-a'); mes.start_run(rid,'李四'); mes.complete_run(rid,good_count=99,waste_count=1,completed_sheets=5)
        wf=ProductionWorkflow(db,mes); st=wf.status(jid); assert st.state=='completed' and st.good_count==99
        result=wf.publish_to_erp(jid); assert result['status']==200
        assert CallbackHandler.payload['state']=='completed' and CallbackHandler.payload['order_id']=='ERP-15'
    finally:
        server.shutdown(); server.server_close(); th.join(timeout=2)


def main():
    # Use separate temp dirs to avoid cross-test scheduling state.
    with TemporaryDirectory() as td:
        p=Path(td); test_gantt_and_changeover(p)
    with TemporaryDirectory() as td:
        p=Path(td); test_auto_balance(p)
    with TemporaryDirectory() as td:
        p=Path(td); test_reporting_oee_scan(p)
    with TemporaryDirectory() as td:
        p=Path(td); test_workflow_callback(p)
    print('V1.5 PASS')

if __name__=='__main__': main()
