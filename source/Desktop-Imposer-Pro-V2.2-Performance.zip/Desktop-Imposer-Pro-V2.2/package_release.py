from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import zipfile
from datetime import datetime, timezone
from pathlib import Path

from product import APP_NAME, APP_SHORT_NAME, APP_VERSION, VENDOR_NAME


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def zip_directory(source: Path, output: Path) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists():
        output.unlink()
    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for path in sorted(source.rglob("*")):
            if path.is_file():
                zf.write(path, Path(source.name) / path.relative_to(source))


def main() -> int:
    parser = argparse.ArgumentParser(description="Create portable release ZIP and hash manifest.")
    parser.add_argument("--dist", default=f"dist/{APP_SHORT_NAME}")
    parser.add_argument("--release", default="release")
    parser.add_argument("--installer", default="")
    args = parser.parse_args()

    dist = Path(args.dist).resolve()
    release = Path(args.release).resolve()
    if not dist.is_dir():
        raise SystemExit(f"Frozen application not found: {dist}")

    exe = dist / f"{APP_SHORT_NAME}.exe"
    if os.name == "nt" and not exe.exists():
        raise SystemExit(f"Frozen executable not found: {exe}")

    release.mkdir(parents=True, exist_ok=True)
    portable = release / f"{APP_SHORT_NAME}-{APP_VERSION}-Windows-x64-Portable.zip"
    zip_directory(dist, portable)

    artifacts = [portable]
    if exe.exists():
        artifacts.insert(0, exe)
    installer = Path(args.installer).resolve() if args.installer else None
    if installer and installer.exists():
        artifacts.append(installer)

    manifest = {
        "schema": 1,
        "app_name": APP_NAME,
        "app_short_name": APP_SHORT_NAME,
        "version": APP_VERSION,
        "vendor": VENDOR_NAME,
        "platform": "windows-x64",
        "created_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "artifacts": [],
    }
    for artifact in artifacts:
        manifest["artifacts"].append({
            "name": artifact.name,
            "size": artifact.stat().st_size,
            "sha256": sha256_file(artifact),
        })
        (release / f"{artifact.name}.sha256").write_text(
            f"{sha256_file(artifact)}  {artifact.name}\n", encoding="utf-8"
        )

    manifest_path = release / f"{APP_SHORT_NAME}-{APP_VERSION}-release.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(manifest, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
