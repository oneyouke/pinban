from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta, timezone
from typing import Any
import json
from storage import ProductionDB
from device_center import DeviceRegistry, DeviceProfile


def utc_now_dt(): return datetime.now(timezone.utc)
def utc_now(): return utc_now_dt().isoformat(timespec='seconds')

@dataclass(frozen=True)
class RouteStep:
    seq: int
    operation: str
    device_kind: str
    setup_minutes: float = 0.0
    run_minutes_per_1000: float = 0.0
    capability: str = ''

class RoutingManager:
    def __init__(self, db: ProductionDB, registry: DeviceRegistry):
        self.db=db; self.registry=registry; self._init_schema()
    def _init_schema(self):
        with self.db.connect() as c:
            c.executescript('''
            CREATE TABLE IF NOT EXISTS process_routes(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE NOT NULL,steps_json TEXT NOT NULL,created_at TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS operation_runs(id INTEGER PRIMARY KEY AUTOINCREMENT,queue_job_id INTEGER NOT NULL,route_name TEXT NOT NULL,seq INTEGER NOT NULL,operation TEXT NOT NULL,device_id TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'planned',planned_start TEXT NOT NULL DEFAULT '',planned_end TEXT NOT NULL DEFAULT '',actual_start TEXT NOT NULL DEFAULT '',actual_end TEXT NOT NULL DEFAULT '',qty INTEGER NOT NULL DEFAULT 0,UNIQUE(queue_job_id,seq));
            ''')
    def save_route(self,name:str,steps:list[RouteStep]):
        if not steps: raise ValueError('工艺路线不能为空')
        steps=sorted(steps,key=lambda x:x.seq)
        with self.db.connect() as c:
            c.execute('''INSERT INTO process_routes(name,steps_json,created_at) VALUES(?,?,?)
            ON CONFLICT(name) DO UPDATE SET steps_json=excluded.steps_json''',(name,json.dumps([asdict(s) for s in steps],ensure_ascii=False),utc_now()))
    def load_route(self,name:str)->list[RouteStep]:
        with self.db.connect() as c:r=c.execute('SELECT steps_json FROM process_routes WHERE name=?',(name,)).fetchone()
        if not r: raise ValueError(f'工艺路线不存在: {name}')
        return [RouteStep(**x) for x in json.loads(r[0])]
    def _device_for_step(self, step:RouteStep)->DeviceProfile:
        candidates=[]
        for d in self.registry.load():
            if not d.enabled: continue
            if d.kind!=step.device_kind and not d.capabilities.get(step.operation): continue
            if step.capability and not d.capabilities.get(step.capability): continue
            candidates.append(d)
        if not candidates: raise ValueError(f'工序 {step.operation} 没有可用设备')
        return min(candidates,key=lambda d:(d.setup_minutes, -d.production_speed_sph, d.hourly_cost))
    def plan_job(self,queue_job_id:int,route_name:str,qty:int,start=None)->list[dict[str,Any]]:
        cursor=start or utc_now_dt(); planned=[]
        for step in self.load_route(route_name):
            d=self._device_for_step(step)
            setup=max(0,step.setup_minutes or d.setup_minutes)
            runtime=max(0,step.run_minutes_per_1000)*(max(0,qty)/1000.0)
            if runtime<=0 and d.production_speed_sph>0: runtime=max(0,qty)/d.production_speed_sph*60
            end=cursor+timedelta(minutes=setup+runtime)
            row={'queue_job_id':queue_job_id,'route_name':route_name,'seq':step.seq,'operation':step.operation,'device_id':d.id,'status':'planned','planned_start':cursor.isoformat(timespec='seconds'),'planned_end':end.isoformat(timespec='seconds'),'qty':qty}
            planned.append(row); cursor=end
        with self.db.connect() as c:
            for r in planned:
                c.execute('''INSERT INTO operation_runs(queue_job_id,route_name,seq,operation,device_id,status,planned_start,planned_end,qty)
                VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(queue_job_id,seq) DO UPDATE SET route_name=excluded.route_name,operation=excluded.operation,device_id=excluded.device_id,status='planned',planned_start=excluded.planned_start,planned_end=excluded.planned_end,qty=excluded.qty''',tuple(r[k] for k in ('queue_job_id','route_name','seq','operation','device_id','status','planned_start','planned_end','qty')))
        return planned
    def gantt(self,queue_job_id:int)->list[dict[str,Any]]:
        with self.db.connect() as c: rows=c.execute('SELECT * FROM operation_runs WHERE queue_job_id=? ORDER BY seq',(queue_job_id,)).fetchall()
        return [dict(r) for r in rows]
