param(
  [switch]$Strict,
  [switch]$SkipInstaller,
  [switch]$SkipTests,
  [string]$CertThumbprint = "",
  [string]$PythonCommand = "",
  [string]$NsisCompiler = ""
)

$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

function Write-Step([string]$Text) {
  Write-Host "`n==> $Text" -ForegroundColor Cyan
}

function Find-Python {
  if ($PythonCommand) { return $PythonCommand }
  if (Get-Command py.exe -ErrorAction SilentlyContinue) { return "py -3.12" }
  if (Get-Command python.exe -ErrorAction SilentlyContinue) { return "python" }
  throw "未找到 Python。请先安装 Python 3.10+（推荐 3.12 x64）。"
}

function Invoke-Python([string]$Args) {
  $cmd = Find-Python
  if ($cmd.StartsWith("py ")) {
    $parts = $cmd.Split(" ", 2)
    & $parts[0] $parts[1] $Args.Split(" ")
  } else {
    & $cmd $Args.Split(" ")
  }
  if ($LASTEXITCODE -ne 0) { throw "Python command failed: $Args" }
}

function Find-NSIS {
  if ($NsisCompiler -and (Test-Path $NsisCompiler)) { return $NsisCompiler }
  $cmd = Get-Command makensis.exe -ErrorAction SilentlyContinue
  if ($cmd) { return $cmd.Source }
  $candidates = @(
    "$env:ProgramFiles\NSIS\makensis.exe",
    "${env:ProgramFiles(x86)}\NSIS\makensis.exe"
  )
  return ($candidates | Where-Object { Test-Path $_ } | Select-Object -First 1)
}

$basePython = Find-Python
$venv = Join-Path $PSScriptRoot ".venv-build"
$venvPython = Join-Path $venv "Scripts\python.exe"

Write-Step "准备独立构建环境"
if (-not (Test-Path $venvPython)) {
  if ($basePython.StartsWith("py ")) {
    & py.exe -3.12 -m venv $venv
  } else {
    & $basePython -m venv $venv
  }
  if ($LASTEXITCODE -ne 0) { throw "创建虚拟环境失败" }
}
& $venvPython -m pip install --upgrade pip
& $venvPython -m pip install -r requirements-build.txt

Write-Step "编译检查与自动测试"
& $venvPython -m compileall -q .
if (-not $SkipTests) {
  & $venvPython test_engine.py
  if ($LASTEXITCODE -ne 0) { throw "拼版引擎测试失败" }
  & $venvPython test_commercial.py
  if ($LASTEXITCODE -ne 0) { throw "商用基础测试失败" }
  & $venvPython test_v11.py
  if ($LASTEXITCODE -ne 0) { throw "V1.1 测试失败" }
  & $venvPython test_v12.py
  if ($LASTEXITCODE -ne 0) { throw "V1.2 测试失败" }
  & $venvPython test_v13.py
  if ($LASTEXITCODE -ne 0) { throw "V1.3 测试失败" }
  & $venvPython test_v14.py
  if ($LASTEXITCODE -ne 0) { throw "V1.4 测试失败" }
  & $venvPython test_v15.py
  if ($LASTEXITCODE -ne 0) { throw "V1.5 测试失败" }
  & $venvPython test_v16.py
  if ($LASTEXITCODE -ne 0) { throw "V1.6 测试失败" }
  & $venvPython test_v17.py
  if ($LASTEXITCODE -ne 0) { throw "V1.7 测试失败" }
  & $venvPython test_v18.py
  if ($LASTEXITCODE -ne 0) { throw "V1.8 测试失败" }
  & $venvPython test_v19.py
  if ($LASTEXITCODE -ne 0) { throw "V1.9 测试失败" }
  & $venvPython test_v20.py
  if ($LASTEXITCODE -ne 0) { throw "V2.0 产品化测试失败" }
  & $venvPython test_v21.py
  if ($LASTEXITCODE -ne 0) { throw "V2.1 发布强化测试失败" }
}
if ($Strict) {
  & $venvPython release_gate.py --strict
} else {
  & $venvPython release_gate.py
}
if ($LASTEXITCODE -ne 0) { throw "发布闸门未通过" }

Write-Step "封装 Windows 桌面程序"
Remove-Item -Recurse -Force build, dist, release -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Path release -Force | Out-Null
& $venvPython -m PyInstaller --noconfirm --clean DesktopImposer.spec
if ($LASTEXITCODE -ne 0) { throw "PyInstaller 构建失败" }

$exe = Join-Path $PSScriptRoot "dist\DesktopImposerPro\DesktopImposerPro.exe"
if (-not (Test-Path $exe)) { throw "未找到封装后的 EXE：$exe" }

Write-Step "执行封装后自检"
$selfTest = Join-Path $env:TEMP "desktop-imposer-selftest.json"
Remove-Item $selfTest -ErrorAction SilentlyContinue
$env:DESKTOP_IMPOSER_SELFTEST_FILE = $selfTest
$proc = Start-Process -FilePath $exe -ArgumentList "--packaging-self-test" -Wait -PassThru
Remove-Item Env:DESKTOP_IMPOSER_SELFTEST_FILE -ErrorAction SilentlyContinue
if ($proc.ExitCode -ne 0 -or -not (Test-Path $selfTest)) {
  throw "封装后的程序自检失败"
}
$selfTestData = Get-Content $selfTest -Raw | ConvertFrom-Json
if (-not $selfTestData.ok) { throw "Qt/PDF 自检未通过" }
Write-Host "Self-test OK: $($selfTestData.app) $($selfTestData.version)"

if ($CertThumbprint) {
  Write-Step "代码签名主程序"
  $signtool = (Get-Command signtool.exe -ErrorAction SilentlyContinue).Source
  if (-not $signtool) { throw "指定了证书 Thumbprint，但未找到 signtool.exe。请安装 Windows SDK。" }
  & $signtool sign /sha1 $CertThumbprint /fd SHA256 /tr http://timestamp.digicert.com /td SHA256 $exe
  if ($LASTEXITCODE -ne 0) { throw "EXE 代码签名失败" }
}

Write-Step "生成便携版 ZIP 与 SHA-256"
& $venvPython package_release.py
if ($LASTEXITCODE -ne 0) { throw "便携版打包失败" }

$installer = $null
if (-not $SkipInstaller) {
  $nsis = Find-NSIS
  if ($nsis) {
    Write-Step "生成 Windows 安装程序"
    $version = & $venvPython -c "import product; print(product.APP_VERSION)"
    $publisher = & $venvPython -c "import product; print(product.VENDOR_NAME)"
    & $nsis "/DAPP_VERSION=$version" "/DAPP_PUBLISHER=$publisher" installer_nsis.nsi
    if ($LASTEXITCODE -ne 0) { throw "NSIS 安装包构建失败" }
    $installer = Get-ChildItem "$PSScriptRoot\release\DesktopImposerPro-*-Setup-x64.exe" | Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if ($CertThumbprint -and $installer) {
      Write-Step "代码签名安装程序"
      $signtool = (Get-Command signtool.exe -ErrorAction SilentlyContinue).Source
      & $signtool sign /sha1 $CertThumbprint /fd SHA256 /tr http://timestamp.digicert.com /td SHA256 $installer.FullName
      if ($LASTEXITCODE -ne 0) { throw "安装包代码签名失败" }
    }
    & $venvPython package_release.py --installer $installer.FullName
  } else {
    Write-Warning "未安装 NSIS，因此已生成可直接运行的 Portable ZIP，但没有 Setup.exe。安装 NSIS 后重新双击 BUILD_WINDOWS_DESKTOP.bat 即可。"
  }
}

Write-Step "完成"
Get-ChildItem "$PSScriptRoot\release" | Select-Object Name,Length,LastWriteTime | Format-Table -AutoSize
Write-Host "`n输出目录：$PSScriptRoot\release" -ForegroundColor Green
