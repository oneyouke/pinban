# Third-Party Notices

This product is built with third-party components. Before shipping a commercial build, verify the exact versions actually bundled by the release build and retain their corresponding license texts.

- **Qt / PySide6 (Qt for Python)** — available under LGPLv3/GPLv3 and the Qt commercial license. Your distribution model must comply with the license option you choose.
- **pypdf** — BSD-3-Clause.
- **ReportLab** — BSD-style open-source license (verify the exact packaged release).
- **Pillow** — HPND license (verify the exact packaged release).
- **openpyxl** — MIT license.
- **cryptography** — Apache-2.0 OR BSD-3-Clause licensing; verify the bundled release notices.
- **Python / standard library** — Python Software Foundation license and bundled notices.
- **SQLite** — public domain.
- **PyInstaller** — GPLv2 with a special exception permitting commercial application bundles; PyInstaller itself is a build dependency and is not intentionally shipped as a runtime library.

The release engineer should create a final dependency inventory/SBOM from the actual clean build environment and archive it with each release.
