from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import json
import urllib.request
import xml.etree.ElementTree as ET

JMF_NS = "http://www.CIP4.org/JDFSchema_1_1"
ET.register_namespace("", JMF_NS)


def q(name: str) -> str:
    return f"{{{JMF_NS}}}{name}"


@dataclass(frozen=True)
class JMFStatus:
    device_id: str = ""
    device_status: str = "Unknown"
    job_id: str = ""
    job_part_id: str = ""
    job_status: str = "Unknown"
    percent_completed: float | None = None
    raw_message: str = ""


def build_status_query(device_id: str = "", query_id: str = "StatusQuery") -> bytes:
    root = ET.Element(q("JMF"), {
        "SenderID": "DesktopImposerPro",
        "TimeStamp": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "Version": "1.6",
    })
    query = ET.SubElement(root, q("Query"), {"ID": query_id, "Type": "Status"})
    if device_id:
        query.set("DeviceID", device_id)
    ET.SubElement(query, q("StatusQuParams"), {"DeviceDetails": "Full"})
    return ET.tostring(root, encoding="utf-8", xml_declaration=True)


def build_stop_command(job_id: str, job_part_id: str = "", device_id: str = "") -> bytes:
    if not job_id:
        raise ValueError("job_id 不能为空")
    root = ET.Element(q("JMF"), {
        "SenderID": "DesktopImposerPro",
        "TimeStamp": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "Version": "1.6",
    })
    cmd = ET.SubElement(root, q("Command"), {"ID": "StopPersistentChannel", "Type": "Stop"})
    params = ET.SubElement(cmd, q("StopPersChParams"), {"JobID": job_id})
    if job_part_id:
        params.set("JobPartID", job_part_id)
    if device_id:
        params.set("DeviceID", device_id)
    return ET.tostring(root, encoding="utf-8", xml_declaration=True)


def parse_status_response(xml_data: bytes | str) -> JMFStatus:
    if isinstance(xml_data, str):
        xml_data = xml_data.encode("utf-8")
    root = ET.fromstring(xml_data)
    device_id = root.attrib.get("SenderID", "")
    device_status = "Unknown"
    job_id = ""
    job_part_id = ""
    job_status = "Unknown"
    percent = None

    for elem in root.iter():
        name = elem.tag.split("}")[-1]
        if name in {"DeviceInfo", "Device"}:
            device_id = elem.attrib.get("DeviceID", device_id)
            device_status = elem.attrib.get("DeviceStatus", elem.attrib.get("Status", device_status))
        elif name in {"JobPhase", "JobInfo"}:
            job_id = elem.attrib.get("JobID", job_id)
            job_part_id = elem.attrib.get("JobPartID", job_part_id)
            job_status = elem.attrib.get("Status", elem.attrib.get("JobStatus", job_status))
            raw_pct = elem.attrib.get("PercentCompleted") or elem.attrib.get("PercentComplete")
            if raw_pct is not None:
                try:
                    percent = float(raw_pct)
                except ValueError:
                    pass
    return JMFStatus(device_id, device_status, job_id, job_part_id, job_status, percent, xml_data.decode("utf-8", "replace"))


def post_jmf(url: str, payload: bytes, timeout: float = 10.0) -> tuple[int, bytes]:
    req = urllib.request.Request(url, data=payload, headers={"Content-Type": "application/vnd.cip4-jmf+xml"}, method="POST")
    with urllib.request.urlopen(req, timeout=timeout) as response:
        return int(response.status), response.read()
