from __future__ import annotations
from dataclasses import dataclass, asdict
from math import ceil

@dataclass(frozen=True)
class CostInput:
    order_qty:int
    ups:int
    spoilage_rate:float=0.03
    setup_sheets:int=20
    paper_cost_per_sheet:float=0.0
    plate_count:int=0
    plate_cost_each:float=0.0
    click_cost_per_side:float=0.0
    sides:int=1
    press_setup_cost:float=0.0
    finishing_cost_per_item:float=0.0
    packing_cost:float=0.0
    delivery_cost:float=0.0
    tax_rate:float=0.0
    target_margin_rate:float=0.0

@dataclass(frozen=True)
class CostResult:
    net_sheets:int
    spoilage_sheets:int
    total_sheets:int
    paper_cost:float
    plate_cost:float
    click_cost:float
    press_setup_cost:float
    finishing_cost:float
    packing_cost:float
    delivery_cost:float
    subtotal:float
    tax:float
    total_cost:float
    unit_cost:float
    suggested_price:float

    def to_dict(self): return asdict(self)


def calculate_cost(c:CostInput)->CostResult:
    if c.order_qty<1 or c.ups<1: raise ValueError('订单数量和模数必须大于 0')
    net=ceil(c.order_qty/c.ups)
    spoil=ceil(net*max(0,c.spoilage_rate))+max(0,c.setup_sheets)
    total=net+spoil
    paper=total*max(0,c.paper_cost_per_sheet)
    plate=max(0,c.plate_count)*max(0,c.plate_cost_each)
    click=total*max(1,c.sides)*max(0,c.click_cost_per_side)
    setup=max(0,c.press_setup_cost)
    finishing=c.order_qty*max(0,c.finishing_cost_per_item)
    packing=max(0,c.packing_cost); delivery=max(0,c.delivery_cost)
    subtotal=paper+plate+click+setup+finishing+packing+delivery
    tax=subtotal*max(0,c.tax_rate)
    all_cost=subtotal+tax
    margin=min(max(0,c.target_margin_rate),0.95)
    suggested=all_cost/(1-margin) if margin else all_cost
    return CostResult(net,spoil,total,paper,plate,click,setup,finishing,packing,delivery,subtotal,tax,all_cost,all_cost/c.order_qty,suggested)
