from __future__ import annotations
from datetime import datetime, timezone, timedelta

def utc_now(): return datetime.now(timezone.utc).isoformat(timespec='seconds')

class MaintenanceManager:
    def __init__(self, db):
        self.db=db
        with db.connect() as c:
            c.executescript('''
            CREATE TABLE IF NOT EXISTS maintenance_tasks(
              id INTEGER PRIMARY KEY AUTOINCREMENT, device_id TEXT NOT NULL, title TEXT NOT NULL, due_at TEXT NOT NULL DEFAULT '',
              meter_due INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'open', notes TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL, completed_at TEXT NOT NULL DEFAULT '');
            ''')
    def schedule(self, device_id:str, title:str, *, due_at:str='', meter_due:int=0, notes:str='') -> int:
        with self.db.connect() as c:
            cur=c.execute('INSERT INTO maintenance_tasks(device_id,title,due_at,meter_due,notes,created_at) VALUES(?,?,?,?,?,?)',(device_id,title,due_at,max(0,meter_due),notes,utc_now()))
            return int(cur.lastrowid)
    def complete(self, task_id:int):
        with self.db.connect() as c:
            c.execute("UPDATE maintenance_tasks SET status='completed',completed_at=? WHERE id=?",(utc_now(),task_id))
    def due(self, device_id:str, current_meter:int=0):
        now=utc_now()
        with self.db.connect() as c:
            rows=c.execute("SELECT * FROM maintenance_tasks WHERE device_id=? AND status='open' ORDER BY id",(device_id,)).fetchall()
        out=[]
        for r in rows:
            d=dict(r)
            if (d['due_at'] and d['due_at'] <= now) or (d['meter_due'] and current_meter >= d['meter_due']): out.append(d)
        return out
