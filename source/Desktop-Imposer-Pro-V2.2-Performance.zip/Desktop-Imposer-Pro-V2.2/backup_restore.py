from __future__ import annotations

import hashlib
import json
import os
import shutil
import sqlite3
import tempfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path

from app_paths import config_dir, data_dir, database_path
from product import APP_NAME, APP_VERSION

BACKUP_FORMAT = 1


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def create_backup(destination: str | Path, include_logs: bool = False) -> dict:
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    temp = destination.with_suffix(destination.suffix + ".tmp")
    temp.unlink(missing_ok=True)

    files: list[tuple[Path, str]] = []
    db_path = database_path()
    db_snapshot: Path | None = None
    if db_path.exists():
        fd, name = tempfile.mkstemp(prefix="imposer_db_backup_", suffix=".sqlite3")
        os.close(fd)
        db_snapshot = Path(name)
        with sqlite3.connect(db_path) as src, sqlite3.connect(db_snapshot) as dst:
            src.backup(dst)
        files.append((db_snapshot, "data/production.sqlite3"))

    for root, prefix in [(config_dir(), "config"), (data_dir(), "data")]:
        for p in root.rglob("*"):
            if not p.is_file():
                continue
            if p == db_path or p.name.endswith(("-wal", "-shm")):
                continue
            rel = p.relative_to(root)
            if not include_logs and rel.parts and rel.parts[0] == "logs":
                continue
            files.append((p, f"{prefix}/{rel.as_posix()}"))

    manifest = {
        "backup_format": BACKUP_FORMAT,
        "product": APP_NAME,
        "app_version": APP_VERSION,
        "created_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "files": [],
    }
    with zipfile.ZipFile(temp, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for source, arcname in files:
            zf.write(source, arcname)
            manifest["files"].append({"path": arcname, "size": source.stat().st_size, "sha256": _sha256(source)})
        zf.writestr("backup_manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2))
    temp.replace(destination)
    if db_snapshot:
        db_snapshot.unlink(missing_ok=True)
    return {"path": str(destination), "files": len(manifest["files"]), "sha256": _sha256(destination)}


def inspect_backup(path: str | Path) -> dict:
    path = Path(path)
    with zipfile.ZipFile(path, "r") as zf:
        manifest = json.loads(zf.read("backup_manifest.json"))
        if int(manifest.get("backup_format", 0)) != BACKUP_FORMAT:
            raise ValueError("unsupported backup format")
        for item in manifest.get("files", []):
            data = zf.read(item["path"])
            if len(data) != int(item["size"]):
                raise ValueError(f"backup size mismatch: {item['path']}")
            if hashlib.sha256(data).hexdigest() != item["sha256"]:
                raise ValueError(f"backup checksum mismatch: {item['path']}")
    return manifest


def restore_backup(path: str | Path, target_data: str | Path | None = None, target_config: str | Path | None = None) -> dict:
    manifest = inspect_backup(path)
    droot = Path(target_data) if target_data else data_dir()
    croot = Path(target_config) if target_config else config_dir()
    droot.mkdir(parents=True, exist_ok=True)
    croot.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory(prefix="imposer_restore_") as td:
        stage = Path(td)
        with zipfile.ZipFile(path, "r") as zf:
            zf.extractall(stage)
        # Validate SQLite before replacing production data.
        staged_db = stage / "data" / "production.sqlite3"
        if staged_db.exists():
            with sqlite3.connect(staged_db) as db:
                result = db.execute("PRAGMA integrity_check").fetchone()[0]
                if str(result).lower() != "ok":
                    raise ValueError("backup database integrity check failed")
        for prefix, target in [("data", droot), ("config", croot)]:
            source_root = stage / prefix
            if not source_root.exists():
                continue
            for source in source_root.rglob("*"):
                if source.is_file():
                    rel = source.relative_to(source_root)
                    dest = target / rel
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    tmp = dest.with_suffix(dest.suffix + ".restoretmp")
                    shutil.copy2(source, tmp)
                    tmp.replace(dest)
    return {"restored": len(manifest.get("files", [])), "from_version": manifest.get("app_version")}
