# V2.2 Performance optimization

Primary bottleneck fixed: `inspect_source()` previously sent files through `SourceLibrary`, which deep-copied every PDF page merely to determine page count and first-page size.

V2.2 now:
- opens PDF metadata only;
- reads page count and only the first page for dimensions/boxes;
- handles page rotation without cloning all pages;
- caches by absolute path + mtime_ns + file size + source box;
- caches deep preflight scans separately;
- reads raster pixel dimensions directly instead of converting to a temporary PDF.

Synthetic 400-page PDF benchmark in the development environment:
- previous inspection: ~30.56 s
- optimized first inspection: ~0.033 s
- cached repeat: ~0.0001 s

The benchmark isolates source metadata parsing, not total end-to-end preview/export time.
