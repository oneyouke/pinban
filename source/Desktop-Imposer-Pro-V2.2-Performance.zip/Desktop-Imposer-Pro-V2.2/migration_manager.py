from __future__ import annotations

import shutil
import sqlite3
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable

from product import DATABASE_SCHEMA_VERSION

MigrationFn = Callable[[sqlite3.Connection], None]

@dataclass(frozen=True)
class Migration:
    version: int
    name: str
    apply: MigrationFn


def _v3_access_indexes(db: sqlite3.Connection) -> None:
    # RBAC tables are also created lazily by UserStore; migration records the
    # version and provides indexes useful in larger installations.
    db.execute("CREATE INDEX IF NOT EXISTS idx_audit_event_created ON audit_log(event,created_at)")
    db.execute("CREATE INDEX IF NOT EXISTS idx_jobs_updated ON production_jobs(updated_at)")

MIGRATIONS = [Migration(3, "v2_productization_indexes", _v3_access_indexes)]

class MigrationManager:
    def __init__(self, path: str | Path):
        self.path = Path(path)

    def current_version(self) -> int:
        if not self.path.exists():
            return 0
        with sqlite3.connect(self.path) as db:
            try:
                row = db.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()
                return int(row[0]) if row else 0
            except sqlite3.DatabaseError:
                return 0

    def backup_before_migration(self) -> Path | None:
        if not self.path.exists():
            return None
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        dest = self.path.with_name(f"{self.path.stem}.pre-v2-migration-{stamp}{self.path.suffix}")
        # SQLite backup API produces a consistent copy even when WAL is active.
        with sqlite3.connect(self.path) as src, sqlite3.connect(dest) as dst:
            src.backup(dst)
        return dest

    def migrate(self, target: int = DATABASE_SCHEMA_VERSION) -> dict:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        backup = self.backup_before_migration()
        applied: list[dict] = []
        with sqlite3.connect(self.path) as db:
            db.execute("CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY,value TEXT NOT NULL)")
            db.execute("CREATE TABLE IF NOT EXISTS schema_migrations(version INTEGER PRIMARY KEY,name TEXT NOT NULL,applied_at TEXT NOT NULL)")
            row = db.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()
            current = int(row[0]) if row else 0
            for migration in MIGRATIONS:
                if current < migration.version <= target:
                    migration.apply(db)
                    db.execute(
                        "INSERT OR REPLACE INTO schema_migrations(version,name,applied_at) VALUES(?,?,?)",
                        (migration.version, migration.name, datetime.now(timezone.utc).isoformat(timespec="seconds")),
                    )
                    current = migration.version
                    applied.append({"version": current, "name": migration.name})
            db.execute(
                "INSERT INTO meta(key,value) VALUES('schema_version',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (str(max(current, target)),),
            )
            db.commit()
        return {"from": self.current_version() if not applied else applied[0]["version"] - 1, "to": target, "applied": applied, "backup": str(backup) if backup else None}
