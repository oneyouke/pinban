# V2.2.0 Performance Release

- Replaced import-time PDF inspection that deep-copied every page with metadata-only first-page inspection.
- Added file-signature cache for page count / first-page size / page-box metadata.
- Added file-signature cache for deep PDF prepress analysis.
- Raster source inspection no longer creates a temporary PDF just to read dimensions.
- 400-page synthetic PDF benchmark: ~30.56s old inspection vs ~0.033s first optimized inspection; cached repeat ~0.0001s.
- Existing core regression remains PASS.

# V2.1.0

- 新增 CrashMarker，识别进程崩溃/断电导致的非正常退出；
- 新增 SHA-256 哈希链安全审计；
- 新增自动 `.dibackup` 定时备份、保留策略和桌面设置入口；
- 新增数据库/磁盘/备份/审计链系统健康检查；
- 更新下载改为签名清单后 HTTPS 下载并强制 SHA-256 staging，不静默执行安装包；
- 支持诊断包新增 health-check 与 audit-chain 结果；
- Windows 发布闸门新增 `test_v21.py`；
- V1.x / V2.0 全量回归保持通过。

# V2.0.0

- 正式商业产品化基线。
- 新增本地 RBAC 用户/角色/权限。
- 新增首次管理员创建与登录界面。
- 新增产品工作台和角色感知模块入口。
- 新增 `.dibackup` 备份格式、SHA-256 完整性校验与安全恢复。
- 新增数据库迁移管理与迁移前 SQLite 一致性备份。
- 新增品牌配置、基础中英文 i18n、离线帮助中心。
- 关键生产/设备/MES/商业操作增加底层权限门禁。
- Windows 自动封装链新增 V2.0 回归测试。

# Changelog

## 1.9.0

- 新增客户专属价、数量阶梯价和最低毛利红线；
- 新增报价审批流与审批审计；
- 新增客户信用检查、逾期风险和订单 `credit_hold`；
- 新增业务员档案、订单归属和多种提成基数；
- 新增客户/供应商对账和供应商付款；
- 新增 90 天现金流预测；
- 新增订单盈亏排行和老板经营驾驶舱；
- 商业运营桌面控制台升级到 V1.9；
- Windows 自动封装链增加 V1.9 全量回归。

## 1.7.0 - 智能生产与质量追溯

- 新增统一设备遥测 Telemetry Adapter 与 HTTP/JSON 采集。
- 新增设备计数器自动报工桥接，计数器回退/跳变/设备不匹配自动告警。
- 新增质量抽检、Hold/Fail、缺陷代码与返工单闭环。
- 新增 Lot / Pallet 批次追溯。
- 新增按日期或设备累计计数器触发的维护保养任务。
- 新增统一告警中心数据层。
- 新增交期风险评分，结合预计完工、优先级和毛利权重。
- Windows 自动封装增加 V1.7 回归测试。

# CHANGELOG

## 1.5.0 - 车间 MES 与 OEE

- 新增持久化 MES Run、甘特排程数据与预计完工时间。
- 新增换纸/换版顺序优化和多机负载平衡。
- 新增良品/废品/印张报工、停机原因与 OEE 计算。
- 新增 DIMES V1 扫码开工/完工/报工。
- 新增 ERP 全流程状态解析与 HTTP 状态回写。
- 新增 Qt 车间 MES 控制台。
- Windows 一键封装链新增 V1.5 回归测试。

# Changelog

## 1.4.0 - 生产控制台与自动派机

- 新增生产控制台：设备看板、生产排程、CIP3 墨键、刀版库、ERP 自动接单。
- 新增持久 `production_schedule` 调度表和设备运行状态表。
- 自动派机支持纸张、色数、单双面、能力、设备负载、速度、换单时间和小时成本评分。
- JMF 状态可定时轮询并持久化；离线/错误设备不会被自动派机。
- 队列支持按排程优先级处理指定任务。
- 已派机任务生产成功后可自动投递 RIP Hot Folder 与 JDF Hot Folder。
- ERP API 工单可自动转换为生产队列任务并自动派机。
- 设备配置新增生产速度、换单时间、小时成本。
- Windows 一键封装链新增 V1.4 回归测试。

# CHANGELOG

## 1.3.0 - 设备生产闭环

- 新增设备配置中心：纸张范围、色数、咬口、规矩、双面、RIP/JDF/JMF 参数。
- 新增 JMF Status Query 与设备/作业状态解析基线。
- 新增 CIP3 墨键区覆盖率算法，以及 Ghostscript CMYK 分色 Provider。
- 新增风琴折、卷折、对门折、十字折模板。
- 新增 SHA-256 去重刀版库。
- 新增本机 ERP REST Bridge：`/health`、`/v1/jobs` 与 Bearer Token。
- Windows 一键封装链新增 V1.1/V1.2/V1.3 全量回归测试。
- NSIS 安装器版本号同步到 1.3.0。

# Changelog


## 1.2.0 - Production 功能矩阵

- AI/EPS/PS 可插拔导入 Provider（Ghostscript 基线）。
- 真实多边形不规则 Nesting 引擎。
- 骑马订与分帖页序引擎。
- 咬口/拖梢/左右规可打印区域模型。
- 基础生产成本模型。
- RIP Hot Folder + ProductionTicket sidecar。
- ERP/MIS JSON/HTTP 适配层。
- 新增 FEATURE_ACCEPTANCE.md，逐项对应商用功能验收表。

## V1.0.0 — Commercial baseline

- 新增 `.imposeproj` 项目文件
- 新增 60 秒自动恢复快照与异常退出恢复判断
- 新增本地 SQLite 设置/最近项目/生产队列/审计数据库
- 新增 queued/running/succeeded/failed/canceled 持久队列
- 新增后台自动连续生产队列
- 新增崩溃后 running 队列自动恢复
- 新增损坏 SQLite 自动隔离并重建
- 新增事务式生产导出：临时文件 → 重新打开验证 → SHA-256 → 原子提交
- 新增 `*.pdf.production.json` 可追溯生产清单
- 新增 Ed25519 离线签名商业许可证
- 新增设备绑定、到期时间、edition/features
- 新增 14 天离线试用、设备匹配和明显时间回拨检测
- 新增许可证管理 UI 和机器指纹显示
- 新增签名更新 manifest 校验接口与离线签发工具
- 新增 rotating log / uncaught exception hook
- 新增隐私收敛的支持诊断 ZIP
- 新增 Built-in / External Professional Preflight Provider 分层
- 内置 preflight 明确标记 `certified=false`
- 新增专业 preflight CLI JSON 协议
- Hot Folder 改用事务式导出和生产清单
- 新增 PyInstaller 商业发布 spec
- 新增 Windows PowerShell 发布/代码签名/安装器流水线
- 新增 Inno Setup installer script
- 新增 release gate，阻止私钥进入客户端；严格模式拦截品牌/EULA 占位符
- 新增第三方 notices、EULA 模板、隐私、安全、架构和发布清单
- 新增 SBOM 生成脚本
- 新增 `test_commercial.py`

## V0.7.0

- PDF/X / OutputIntent 信号识别
- 专色/刀线/白墨/光油分类
- Overprint / 透明度风险检查
- CSV/XLSX 逐件变量字段映射
- Hot Folder 成功归档/失败隔离/JSONL 日志

## V0.6.0

- 吸附、对齐、撤销重做、跨版移动
- 字体/颜色空间/图片有效 DPI 风险检查
- 逐件 QR / 流水码
- Hot Folder 自动生产

## V0.5.0

- 手工版位编辑器
- 正反透明叠加
- CSV/XLSX 订单导入
- QR/流水号
- 版面清单

## V0.4.0

- 异尺寸智能混拼
- MaxRects 风格装箱
- 异尺寸双面
- 利用率统计

## 1.0.1 - Windows 自动桌面封装

- 新增 `BUILD_WINDOWS_DESKTOP.bat`：双击完成独立构建环境、测试、PyInstaller、EXE 自检、Portable ZIP、SHA-256 和安装包构建。
- 新增 `auto_package_windows.ps1`：完整 Windows 自动封装流水线，支持严格发布与 Authenticode 代码签名。
- 安装器切换/新增 NSIS 方案，降低安装器商业许可负担。
- 新增 `.imposeproj` Windows 文件关联，资源管理器双击项目可直接打开。
- 新增封装后 `--packaging-self-test`，验证 QtWidgets/QtPdf 可正常初始化。
- 新增 GitHub Actions Windows 自动构建；推送 `v*` 标签可自动生成 Release 资产。
- 固定 PyInstaller 6.22.2 构建版本，提高构建可重复性。
- 新增 Portable ZIP 和 SHA-256/release manifest 自动生成。

## 1.7.0
- 新增纸张/耗材库存、批次、预留、消耗和补货建议。
- 新增跨工序工艺路线与印后设备排程。
- 新增刀模寿命管理。
- 新增托盘/物流二维码追踪。
- 新增交期/库存/成本/毛利综合生产路径评分。

## 1.8.0

- 新增商业运营控制台。
- 新增客户、报价、销售订单、应收、收款与采购订单模型。
- 新增原材料批次成本与 FIFO 耗用成本。
- 新增订单预计成本/实际成本/实际毛利分析。
- 新增经营看板：销售额、应收、逾期、采购和实际利润。
- Windows 自动封装增加 V1.8 回归测试。
