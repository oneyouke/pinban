from __future__ import annotations
from dataclasses import dataclass, replace

@dataclass(frozen=True)
class PressGeometry:
    sheet_width_mm: float
    sheet_height_mm: float
    gripper_mm: float = 0.0
    tail_mm: float = 0.0
    side_left_mm: float = 0.0
    side_right_mm: float = 0.0
    name: str = ''

    def validate(self):
        for label, value in (
            ('纸张宽', self.sheet_width_mm), ('纸张高', self.sheet_height_mm),
        ):
            if value <= 0: raise ValueError(f'{label}必须大于 0')
        for label, value in (
            ('咬口', self.gripper_mm), ('拖梢', self.tail_mm),
            ('左规', self.side_left_mm), ('右规', self.side_right_mm),
        ):
            if value < 0: raise ValueError(f'{label}不能小于 0')
        self.printable_rect()

    def printable_rect(self):
        x=self.side_left_mm
        y=self.gripper_mm
        w=self.sheet_width_mm-self.side_left_mm-self.side_right_mm
        h=self.sheet_height_mm-self.gripper_mm-self.tail_mm
        if w<=0 or h<=0: raise ValueError('咬口/拖梢/左右规设置超过纸张尺寸')
        return (x,y,w,h)

    @property
    def printable_area_mm2(self):
        _,_,w,h=self.printable_rect(); return w*h


def calculate_grid_for_press(settings, press:PressGeometry):
    """Run the existing grid engine inside the asymmetric press printable area.

    Returns (grid, printable_rect). Grid origin is translated back to physical
    sheet coordinates, so downstream PDF placement can use it directly.
    """
    from imposition import calculate_grid, GridResult
    press.validate()
    x,y,w,h=press.printable_rect()
    local=replace(settings, sheet_width_mm=w, sheet_height_mm=h)
    grid=calculate_grid(local)
    translated=GridResult(
        rows=grid.rows, cols=grid.cols, capacity=grid.capacity,
        origin_x_mm=grid.origin_x_mm+x, origin_y_mm=grid.origin_y_mm+y,
        used_width_mm=grid.used_width_mm, used_height_mm=grid.used_height_mm,
        effective_rotation=grid.effective_rotation,
        footprint_width_mm=grid.footprint_width_mm,
        footprint_height_mm=grid.footprint_height_mm,
    )
    return translated,(x,y,w,h)
