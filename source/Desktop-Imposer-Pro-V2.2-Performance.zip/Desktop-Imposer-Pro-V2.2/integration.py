from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
import json, shutil, urllib.request

@dataclass
class ProductionTicket:
    order_id:str
    customer:str=''
    input_files:list[str]|None=None
    quantities:list[int]|None=None
    sheet_width_mm:float|None=None
    sheet_height_mm:float|None=None
    device_kind:str=''
    required_colors:int|None=None
    output_dir:str=''
    product_width_mm:float|None=None
    product_height_mm:float|None=None
    substrate:str=''
    machine:str=''
    output_profile:str=''
    metadata:dict|None=None
    def to_dict(self): return asdict(self)


def load_erp_ticket(path:str|Path)->ProductionTicket:
    data=json.loads(Path(path).read_text(encoding='utf-8'))
    return ProductionTicket(**data)


def save_erp_ticket(ticket:ProductionTicket,path:str|Path):
    Path(path).write_text(json.dumps(ticket.to_dict(),ensure_ascii=False,indent=2),encoding='utf-8')


def submit_http_json(url:str,ticket:ProductionTicket,timeout:float=10.0):
    body=json.dumps(ticket.to_dict(),ensure_ascii=False).encode('utf-8')
    req=urllib.request.Request(url,data=body,headers={'Content-Type':'application/json'},method='POST')
    with urllib.request.urlopen(req,timeout=timeout) as r:
        return r.status, r.read().decode('utf-8','replace')


def send_to_rip_hotfolder(pdf_path:str|Path,rip_folder:str|Path,ticket:ProductionTicket|None=None):
    src=Path(pdf_path); dst_dir=Path(rip_folder); dst_dir.mkdir(parents=True,exist_ok=True)
    dst=dst_dir/src.name
    tmp=dst.with_suffix(dst.suffix+'.partial')
    shutil.copy2(src,tmp); tmp.replace(dst)
    if ticket:
        sidecar=dst.with_suffix(dst.suffix+'.ticket.json')
        sidecar.write_text(json.dumps(ticket.to_dict(),ensure_ascii=False,indent=2),encoding='utf-8')
    return str(dst)
