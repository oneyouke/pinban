from booklet import saddle_stitch, signatures
from press_geometry import PressGeometry
from costing import CostInput, calculate_cost
from nesting import NestItem, nest_polygons
from integration import ProductionTicket

def main():
    s=saddle_stitch(8)
    assert [(x.left,x.right) for x in s]==[(8,1),(2,7),(6,3),(4,5)]
    assert len(signatures(32,16))==2
    g=PressGeometry(450,320,12,8,5,5)
    assert g.printable_rect()==(5,12,440,300)
    c=calculate_cost(CostInput(order_qty=1000,ups=10,spoilage_rate=.05,setup_sheets=10,paper_cost_per_sheet=.5))
    assert c.net_sheets==100 and c.total_sheets==115
    items=[NestItem('L',[(0,0),(40,0),(40,10),(10,10),(10,40),(0,40)],2)]
    p=nest_polygons(items,100,100,gap_mm=2,step_mm=1)
    assert len(p)==2
    assert ProductionTicket('A001').order_id=='A001'
    print('V1.1 PASS')
if __name__=='__main__': main()
