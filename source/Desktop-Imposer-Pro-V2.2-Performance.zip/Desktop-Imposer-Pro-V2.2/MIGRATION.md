# Upgrade from V0.7

V1.0 keeps the existing imposition engine concepts and JSON parameter-template loader. Existing PDF/image source files remain unchanged.

New V1.0 project files use `.imposeproj` and include source rows, settings, manual layout and Hot Folder configuration. V0.7 did not have this project format, so the first V1.0 session should load the old JSON template (if used), add/import the source files, then save a new `.imposeproj` project.

V1.0 stores queue/audit/settings data in a local SQLite database under the per-user application data directory; this does not modify V0.7 source folders.


## V1.3 -> V1.4

- 原有 `.imposeproj` 文件继续兼容，项目 schema 未变化。
- 本机数据库 schema 标识升级到 2；首次进入 V1.4 时会按需创建 `production_schedule` 和 `device_runtime_status`。
- 原有未派机队列保持 queued，可在生产控制台执行“自动派机”。
- 设备档案新增速度/换单时间/小时成本字段，旧档案缺少这些字段时默认按 0 处理，不影响原有设备配置。
