# V2.1.5 Direct Python Path Fix

针对现场现象：

- winget 明确显示 Python 3.12 已安装；
- 旧脚本仍进入安装流程；
- 说明“运行 Python 来探测 Python”的方法在该 Windows 环境中不可靠。

V2.1.5 改成：

1. 第一优先直接检查：
   `%LOCALAPPDATA%\Programs\Python\Python312\python.exe`
2. 文件存在就直接使用，不先执行版本探测。
3. 然后检查 Python 注册表安装路径。
4. PATH / py launcher 只作为后备。
5. winget 返回“已经安装 / 无升级”不再视为失败。
6. 真正的 Python 可用性在创建 venv 时验证。
