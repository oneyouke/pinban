from __future__ import annotations

from dataclasses import dataclass, asdict
from datetime import datetime, timedelta, timezone
from typing import Any
import json

from device_center import DeviceProfile, DeviceRegistry
from production_scheduler import ProductionScheduler
from storage import ProductionDB


def utc_now_dt() -> datetime:
    return datetime.now(timezone.utc)


def utc_now() -> str:
    return utc_now_dt().isoformat(timespec="seconds")


def _parse_dt(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
        return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
    except Exception:
        return None


@dataclass(frozen=True)
class RunEstimate:
    queue_job_id: int
    device_id: str
    planned_start: str
    planned_end: str
    setup_minutes: float
    run_minutes: float
    total_minutes: float
    estimated_sheets: int
    reason: str = ""


@dataclass(frozen=True)
class OEEReport:
    device_id: str
    availability: float
    performance: float
    quality: float
    oee: float
    planned_minutes: float
    run_minutes: float
    downtime_minutes: float
    good_count: int
    waste_count: int
    total_count: int


class MESManager:
    """Shop-floor execution layer above prepress scheduling.

    A prepress queue job can be turned into a press run. Runs carry planned and
    actual timestamps, quantities, downtime and operator reporting. All state is
    persistent in the same ProductionDB and can survive application restarts.
    """

    def __init__(self, db: ProductionDB, registry: DeviceRegistry, scheduler: ProductionScheduler | None = None):
        self.db = db
        self.registry = registry
        self.scheduler = scheduler or ProductionScheduler(db, registry)
        self._init_schema()

    def _init_schema(self) -> None:
        with self.db.connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS mes_runs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    queue_job_id INTEGER NOT NULL UNIQUE,
                    device_id TEXT NOT NULL DEFAULT '',
                    order_id TEXT NOT NULL DEFAULT '',
                    status TEXT NOT NULL DEFAULT 'planned',
                    planned_start TEXT NOT NULL DEFAULT '',
                    planned_end TEXT NOT NULL DEFAULT '',
                    actual_start TEXT NOT NULL DEFAULT '',
                    actual_end TEXT NOT NULL DEFAULT '',
                    operator TEXT NOT NULL DEFAULT '',
                    target_sheets INTEGER NOT NULL DEFAULT 0,
                    completed_sheets INTEGER NOT NULL DEFAULT 0,
                    good_count INTEGER NOT NULL DEFAULT 0,
                    waste_count INTEGER NOT NULL DEFAULT 0,
                    setup_minutes REAL NOT NULL DEFAULT 0,
                    notes TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    FOREIGN KEY(queue_job_id) REFERENCES production_jobs(id) ON DELETE CASCADE
                );
                CREATE INDEX IF NOT EXISTS idx_mes_runs_device_status ON mes_runs(device_id,status,id);
                CREATE TABLE IF NOT EXISTS mes_downtime (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    run_id INTEGER NOT NULL,
                    device_id TEXT NOT NULL,
                    reason_code TEXT NOT NULL DEFAULT '',
                    reason_text TEXT NOT NULL DEFAULT '',
                    started_at TEXT NOT NULL,
                    ended_at TEXT NOT NULL DEFAULT '',
                    minutes REAL NOT NULL DEFAULT 0,
                    created_at TEXT NOT NULL,
                    FOREIGN KEY(run_id) REFERENCES mes_runs(id) ON DELETE CASCADE
                );
                CREATE INDEX IF NOT EXISTS idx_mes_downtime_run ON mes_downtime(run_id,id);
                CREATE TABLE IF NOT EXISTS mes_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    run_id INTEGER,
                    queue_job_id INTEGER,
                    device_id TEXT NOT NULL DEFAULT '',
                    event_type TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    payload_json TEXT NOT NULL DEFAULT '{}'
                );
                """
            )

    def _job_row(self, queue_job_id: int) -> dict[str, Any]:
        with self.db.connect() as conn:
            row = conn.execute("SELECT * FROM production_jobs WHERE id=?", (int(queue_job_id),)).fetchone()
        if not row:
            raise ValueError(f"生产队列任务不存在: {queue_job_id}")
        item = dict(row)
        try:
            item["snapshot"] = json.loads(item.get("snapshot_json") or "{}")
        except Exception:
            item["snapshot"] = {}
        try:
            item["summary"] = json.loads(item.get("summary_json") or "{}")
        except Exception:
            item["summary"] = {}
        return item

    @staticmethod
    def estimate_sheets(job: dict[str, Any]) -> int:
        summary = job.get("summary") or {}
        for key in ("sheet_count", "sheets", "total_sheets"):
            value = summary.get(key)
            if value:
                return max(1, int(value))
        snapshot = job.get("snapshot") or {}
        jobs = snapshot.get("jobs") or []
        total_qty = sum(max(0, int(x.get("quantity") or 0)) for x in jobs if isinstance(x, dict))
        settings = snapshot.get("settings") or {}
        rows = max(1, int(settings.get("rows") or 1))
        cols = max(1, int(settings.get("cols") or 1))
        capacity = max(1, rows * cols)
        if total_qty:
            return max(1, (total_qty + capacity - 1) // capacity)
        return 1

    @staticmethod
    def changeover_key(job: dict[str, Any]) -> tuple:
        snapshot = job.get("snapshot") or {}
        settings = snapshot.get("settings") or {}
        return (
            round(float(settings.get("sheet_width_mm") or 0), 2),
            round(float(settings.get("sheet_height_mm") or 0), 2),
            int(snapshot.get("required_colors") or settings.get("required_colors") or 4),
            bool(settings.get("duplex", False)),
        )

    @staticmethod
    def changeover_penalty(prev_job: dict[str, Any] | None, next_job: dict[str, Any], device: DeviceProfile) -> float:
        if not prev_job:
            return max(0.0, float(device.setup_minutes or 0))
        a, b = MESManager.changeover_key(prev_job), MESManager.changeover_key(next_job)
        base = max(0.0, float(device.setup_minutes or 0))
        penalty = base * 0.25
        if a[:2] != b[:2]:
            penalty += base * 0.55  # change paper / format
        if a[2] != b[2]:
            penalty += base * 0.20  # color configuration
        if a[3] != b[3]:
            penalty += base * 0.15  # duplex setup
        return round(penalty, 2)

    def estimate_job(self, queue_job_id: int, device_id: str, start: datetime | None = None,
                     previous_job: dict[str, Any] | None = None) -> RunEstimate:
        job = self._job_row(queue_job_id)
        device = self.registry.get(device_id)
        if not device:
            raise ValueError(f"设备不存在: {device_id}")
        start = start or utc_now_dt()
        sheets = self.estimate_sheets(job)
        setup = self.changeover_penalty(previous_job, job, device)
        speed = max(1.0, float(device.production_speed_sph or 1000.0))
        run_minutes = sheets / speed * 60.0
        total = setup + run_minutes
        end = start + timedelta(minutes=total)
        return RunEstimate(
            queue_job_id=int(queue_job_id), device_id=device_id,
            planned_start=start.isoformat(timespec="seconds"), planned_end=end.isoformat(timespec="seconds"),
            setup_minutes=round(setup, 2), run_minutes=round(run_minutes, 2), total_minutes=round(total, 2),
            estimated_sheets=sheets,
            reason=f"{sheets} 张 / {speed:g} 张每小时 + 换单 {setup:g} 分钟",
        )

    def optimize_sequence(self, device_id: str, queue_job_ids: list[int]) -> list[int]:
        """Greedy sequence minimizing changeover while respecting schedule priority."""
        device = self.registry.get(device_id)
        if not device:
            raise ValueError(f"设备不存在: {device_id}")
        remaining = [self._job_row(i) for i in queue_job_ids]
        if not remaining:
            return []
        schedule = {j["id"]: self.scheduler.assignment_for_job(j["id"]) or {} for j in remaining}
        remaining.sort(key=lambda j: (int(schedule[j["id"]].get("priority") or 100), j["id"]))
        ordered: list[dict[str, Any]] = [remaining.pop(0)]
        while remaining:
            prev = ordered[-1]
            remaining.sort(key=lambda j: (
                self.changeover_penalty(prev, j, device),
                int(schedule[j["id"]].get("priority") or 100),
                j["id"],
            ))
            ordered.append(remaining.pop(0))
        return [int(j["id"]) for j in ordered]

    def build_gantt(self, start: datetime | None = None, persist: bool = True) -> list[RunEstimate]:
        start = start or utc_now_dt()
        rows = self.scheduler.dispatchable_jobs()
        by_device: dict[str, list[int]] = {}
        for row in rows:
            device_id = str(row.get("device_id") or "")
            if row.get("status") != "queued" or not device_id:
                continue
            by_device.setdefault(device_id, []).append(int(row["id"]))

        estimates: list[RunEstimate] = []
        for device_id, ids in by_device.items():
            cursor = start
            previous: dict[str, Any] | None = None
            for job_id in self.optimize_sequence(device_id, ids):
                est = self.estimate_job(job_id, device_id, cursor, previous)
                estimates.append(est)
                cursor = _parse_dt(est.planned_end) or cursor
                previous = self._job_row(job_id)
                if persist:
                    self.ensure_run(job_id, device_id=device_id, estimate=est)
                    with self.db.connect() as conn:
                        conn.execute(
                            "UPDATE production_schedule SET planned_start=?,updated_at=? WHERE queue_job_id=?",
                            (est.planned_start, utc_now(), job_id),
                        )
        return sorted(estimates, key=lambda x: (x.planned_start, x.device_id, x.queue_job_id))

    def auto_balance(self) -> list[dict[str, Any]]:
        """Assign currently unassigned jobs using estimated earliest completion."""
        rows = self.scheduler.dispatchable_jobs()
        device_available: dict[str, datetime] = {d.id: utc_now_dt() for d in self.registry.load() if d.enabled}
        assigned: list[dict[str, Any]] = []
        for row in sorted(rows, key=lambda r: (int(r.get("priority") or 100), int(r["id"]))):
            if row.get("status") != "queued" or row.get("device_id"):
                continue
            req = self.scheduler.requirements_from_snapshot(self._job_row(int(row["id"])).get("snapshot") or {})
            candidates = [c for c in self.scheduler.rank_devices(req) if c.compatible]
            best = None
            for c in candidates:
                est = self.estimate_job(int(row["id"]), c.device_id, device_available.get(c.device_id, utc_now_dt()))
                end = _parse_dt(est.planned_end) or utc_now_dt()
                key = (end, -c.score)
                if best is None or key < best[0]:
                    best = (key, c, est)
            if not best:
                continue
            _, candidate, estimate = best
            self.scheduler.assign_job(int(row["id"]), candidate.device_id, priority=int(row.get("priority") or 100),
                                      planned_start=estimate.planned_start,
                                      reason="MES 多机负载平衡：预计最早完工")
            device_available[candidate.device_id] = _parse_dt(estimate.planned_end) or utc_now_dt()
            assigned.append({"job_id": int(row["id"]), "device_id": candidate.device_id, "planned_end": estimate.planned_end})
        if assigned:
            self.db.audit("mes.auto_balance", {"assignments": assigned})
        return assigned

    def ensure_run(self, queue_job_id: int, device_id: str = "", estimate: RunEstimate | None = None) -> int:
        job = self._job_row(queue_job_id)
        assignment = self.scheduler.assignment_for_job(queue_job_id) or {}
        device_id = device_id or str(assignment.get("device_id") or "")
        if not device_id:
            raise ValueError("任务尚未派机")
        if estimate is None:
            estimate = self.estimate_job(queue_job_id, device_id)
        snapshot = job.get("snapshot") or {}
        erp = snapshot.get("erp") or {}
        ticket = erp.get("ticket") or {}
        order_id = str(ticket.get("order_id") or job.get("title") or queue_job_id)
        now = utc_now()
        with self.db.connect() as conn:
            conn.execute(
                """
                INSERT INTO mes_runs(queue_job_id,device_id,order_id,status,planned_start,planned_end,target_sheets,setup_minutes,created_at,updated_at)
                VALUES(?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(queue_job_id) DO UPDATE SET
                    device_id=excluded.device_id,order_id=excluded.order_id,
                    planned_start=CASE WHEN mes_runs.status='planned' THEN excluded.planned_start ELSE mes_runs.planned_start END,
                    planned_end=CASE WHEN mes_runs.status='planned' THEN excluded.planned_end ELSE mes_runs.planned_end END,
                    target_sheets=CASE WHEN mes_runs.status='planned' THEN excluded.target_sheets ELSE mes_runs.target_sheets END,
                    setup_minutes=CASE WHEN mes_runs.status='planned' THEN excluded.setup_minutes ELSE mes_runs.setup_minutes END,
                    updated_at=excluded.updated_at
                """,
                (int(queue_job_id), device_id, order_id, "planned", estimate.planned_start, estimate.planned_end,
                 int(estimate.estimated_sheets), float(estimate.setup_minutes), now, now),
            )
            row = conn.execute("SELECT id FROM mes_runs WHERE queue_job_id=?", (int(queue_job_id),)).fetchone()
        return int(row["id"])

    def list_runs(self, limit: int = 500) -> list[dict[str, Any]]:
        with self.db.connect() as conn:
            rows = conn.execute(
                "SELECT * FROM mes_runs ORDER BY CASE status WHEN 'running' THEN 0 WHEN 'planned' THEN 1 ELSE 2 END, planned_start, id LIMIT ?",
                (int(limit),),
            ).fetchall()
        return [dict(r) for r in rows]

    def get_run(self, run_id: int) -> dict[str, Any] | None:
        with self.db.connect() as conn:
            row = conn.execute("SELECT * FROM mes_runs WHERE id=?", (int(run_id),)).fetchone()
        return dict(row) if row else None

    def _event(self, run_id: int | None, event_type: str, payload: dict[str, Any]) -> None:
        run = self.get_run(run_id) if run_id else None
        with self.db.connect() as conn:
            conn.execute(
                "INSERT INTO mes_events(run_id,queue_job_id,device_id,event_type,created_at,payload_json) VALUES(?,?,?,?,?,?)",
                (run_id, int(run["queue_job_id"]) if run else None, str(run["device_id"]) if run else "",
                 event_type, utc_now(), json.dumps(payload, ensure_ascii=False, default=str)),
            )
        self.db.audit(f"mes.{event_type}", {"run_id": run_id, **payload})

    def start_run(self, run_id: int, operator: str = "") -> None:
        run = self.get_run(run_id)
        if not run:
            raise ValueError("MES Run 不存在")
        if run["status"] not in {"planned", "paused"}:
            raise ValueError(f"当前状态无法开工: {run['status']}")
        now = utc_now()
        with self.db.connect() as conn:
            conn.execute(
                "UPDATE mes_runs SET status='running',actual_start=CASE WHEN actual_start='' THEN ? ELSE actual_start END,operator=?,updated_at=? WHERE id=?",
                (now, operator or run.get("operator", ""), now, int(run_id)),
            )
        self._event(run_id, "run_started", {"operator": operator})

    def report_progress(self, run_id: int, *, completed_sheets: int | None = None, good_count: int | None = None,
                        waste_count: int | None = None, operator: str = "") -> None:
        run = self.get_run(run_id)
        if not run:
            raise ValueError("MES Run 不存在")
        values = {
            "completed_sheets": int(run["completed_sheets"] if completed_sheets is None else max(0, completed_sheets)),
            "good_count": int(run["good_count"] if good_count is None else max(0, good_count)),
            "waste_count": int(run["waste_count"] if waste_count is None else max(0, waste_count)),
            "operator": operator or str(run.get("operator") or ""),
        }
        with self.db.connect() as conn:
            conn.execute(
                "UPDATE mes_runs SET completed_sheets=?,good_count=?,waste_count=?,operator=?,updated_at=? WHERE id=?",
                (values["completed_sheets"], values["good_count"], values["waste_count"], values["operator"], utc_now(), int(run_id)),
            )
        self._event(run_id, "progress_reported", values)

    def complete_run(self, run_id: int, *, good_count: int | None = None, waste_count: int | None = None,
                     completed_sheets: int | None = None, operator: str = "") -> None:
        run = self.get_run(run_id)
        if not run:
            raise ValueError("MES Run 不存在")
        self.report_progress(run_id, completed_sheets=completed_sheets, good_count=good_count, waste_count=waste_count, operator=operator)
        now = utc_now()
        with self.db.connect() as conn:
            conn.execute("UPDATE mes_runs SET status='completed',actual_end=?,updated_at=? WHERE id=?", (now, now, int(run_id)))
        self._event(run_id, "run_completed", {})

    def begin_downtime(self, run_id: int, reason_code: str, reason_text: str = "") -> int:
        run = self.get_run(run_id)
        if not run:
            raise ValueError("MES Run 不存在")
        with self.db.connect() as conn:
            open_row = conn.execute("SELECT id FROM mes_downtime WHERE run_id=? AND ended_at='' LIMIT 1", (int(run_id),)).fetchone()
            if open_row:
                raise ValueError("该工单已有未结束停机事件")
            now = utc_now()
            cur = conn.execute(
                "INSERT INTO mes_downtime(run_id,device_id,reason_code,reason_text,started_at,created_at) VALUES(?,?,?,?,?,?)",
                (int(run_id), str(run["device_id"]), reason_code, reason_text, now, now),
            )
        self._event(run_id, "downtime_started", {"reason_code": reason_code, "reason_text": reason_text})
        return int(cur.lastrowid)

    def open_downtime(self, run_id: int) -> dict[str, Any] | None:
        with self.db.connect() as conn:
            row = conn.execute("SELECT * FROM mes_downtime WHERE run_id=? AND ended_at='' ORDER BY id DESC LIMIT 1", (int(run_id),)).fetchone()
        return dict(row) if row else None

    def end_downtime(self, downtime_id: int) -> float:
        with self.db.connect() as conn:
            row = conn.execute("SELECT * FROM mes_downtime WHERE id=?", (int(downtime_id),)).fetchone()
            if not row:
                raise ValueError("停机事件不存在")
            if row["ended_at"]:
                return float(row["minutes"])
            end = utc_now_dt()
            start = _parse_dt(row["started_at"]) or end
            minutes = max(0.0, (end - start).total_seconds() / 60.0)
            conn.execute("UPDATE mes_downtime SET ended_at=?,minutes=? WHERE id=?", (end.isoformat(timespec="seconds"), minutes, int(downtime_id)))
        self._event(int(row["run_id"]), "downtime_ended", {"downtime_id": downtime_id, "minutes": round(minutes, 2)})
        return minutes

    def downtime_minutes(self, run_id: int) -> float:
        with self.db.connect() as conn:
            rows = conn.execute("SELECT started_at,ended_at,minutes FROM mes_downtime WHERE run_id=?", (int(run_id),)).fetchall()
        total = 0.0
        now = utc_now_dt()
        for r in rows:
            if r["ended_at"]:
                total += float(r["minutes"] or 0)
            else:
                start = _parse_dt(r["started_at"]) or now
                total += max(0.0, (now - start).total_seconds() / 60.0)
        return total

    def oee(self, device_id: str, since: datetime | None = None, until: datetime | None = None) -> OEEReport:
        until = until or utc_now_dt()
        since = since or (until - timedelta(hours=8))
        with self.db.connect() as conn:
            rows = conn.execute(
                "SELECT * FROM mes_runs WHERE device_id=? AND actual_start<>'' AND actual_start<? AND (actual_end='' OR actual_end>?)",
                (device_id, until.isoformat(timespec="seconds"), since.isoformat(timespec="seconds")),
            ).fetchall()
        planned = run_minutes = downtime = 0.0
        good = waste = 0
        device = self.registry.get(device_id)
        speed = max(1.0, float(device.production_speed_sph if device else 1000.0))
        ideal_minutes = 0.0
        for row in rows:
            start = max(_parse_dt(row["actual_start"]) or since, since)
            end = min(_parse_dt(row["actual_end"]) or until, until)
            elapsed = max(0.0, (end - start).total_seconds() / 60.0)
            if elapsed <= 0:
                continue
            planned += elapsed
            d = self.downtime_minutes(int(row["id"]))
            downtime += min(elapsed, d)
            run_minutes += max(0.0, elapsed - d)
            good += int(row["good_count"] or 0)
            waste += int(row["waste_count"] or 0)
            ideal_minutes += max(0, int(row["completed_sheets"] or 0)) / speed * 60.0
        availability = 1.0 if planned <= 0 else max(0.0, min(1.0, run_minutes / planned))
        performance = 1.0 if run_minutes <= 0 else max(0.0, min(1.0, ideal_minutes / run_minutes))
        total_count = good + waste
        quality = 1.0 if total_count <= 0 else max(0.0, min(1.0, good / total_count))
        return OEEReport(
            device_id=device_id,
            availability=round(availability * 100, 2), performance=round(performance * 100, 2), quality=round(quality * 100, 2),
            oee=round(availability * performance * quality * 100, 2), planned_minutes=round(planned, 2),
            run_minutes=round(run_minutes, 2), downtime_minutes=round(downtime, 2), good_count=good, waste_count=waste, total_count=total_count,
        )

    @staticmethod
    def scan_code(run_id: int, action: str) -> str:
        action = action.upper().strip()
        if action not in {"START", "FINISH", "REPORT", "DOWNTIME"}:
            raise ValueError("不支持的扫码动作")
        return f"DIMES|1|RUN={int(run_id)}|ACTION={action}"

    @staticmethod
    def parse_scan(code: str) -> tuple[int, str]:
        parts = [p.strip() for p in str(code).split("|") if p.strip()]
        if len(parts) < 4 or parts[0] != "DIMES" or parts[1] != "1":
            raise ValueError("不是有效的 DIMES V1 扫码")
        values = {}
        for p in parts[2:]:
            if "=" in p:
                k, v = p.split("=", 1); values[k.upper()] = v
        run_id = int(values.get("RUN") or 0)
        action = str(values.get("ACTION") or "").upper()
        if run_id <= 0 or action not in {"START", "FINISH", "REPORT", "DOWNTIME"}:
            raise ValueError("扫码内容不完整")
        return run_id, action

    def execute_scan(self, code: str, *, operator: str = "", good_count: int | None = None,
                     waste_count: int | None = None, completed_sheets: int | None = None) -> dict[str, Any]:
        run_id, action = self.parse_scan(code)
        if action == "START":
            self.start_run(run_id, operator=operator)
        elif action == "FINISH":
            self.complete_run(run_id, good_count=good_count, waste_count=waste_count,
                              completed_sheets=completed_sheets, operator=operator)
        elif action == "REPORT":
            self.report_progress(run_id, good_count=good_count, waste_count=waste_count,
                                 completed_sheets=completed_sheets, operator=operator)
        return {"run_id": run_id, "action": action, "run": self.get_run(run_id)}
