from __future__ import annotations
from datetime import datetime, timezone
from storage import ProductionDB


def utc_now(): return datetime.now(timezone.utc).isoformat(timespec='seconds')

class ToolLifeManager:
    def __init__(self,db:ProductionDB): self.db=db; self._init_schema()
    def _init_schema(self):
        with self.db.connect() as c:
            c.execute('''CREATE TABLE IF NOT EXISTS tool_life(tool_id TEXT PRIMARY KEY,name TEXT NOT NULL,max_cycles INTEGER NOT NULL DEFAULT 0,current_cycles INTEGER NOT NULL DEFAULT 0,status TEXT NOT NULL DEFAULT 'ready',last_service_at TEXT NOT NULL DEFAULT '',updated_at TEXT NOT NULL)''')
    def upsert(self,tool_id:str,name:str,max_cycles:int,current_cycles:int=0):
        with self.db.connect() as c:c.execute('''INSERT INTO tool_life(tool_id,name,max_cycles,current_cycles,updated_at) VALUES(?,?,?,?,?) ON CONFLICT(tool_id) DO UPDATE SET name=excluded.name,max_cycles=excluded.max_cycles,updated_at=excluded.updated_at''',(tool_id,name,max_cycles,current_cycles,utc_now()))
    def add_cycles(self,tool_id:str,cycles:int)->dict:
        with self.db.connect() as c:
            c.execute('UPDATE tool_life SET current_cycles=current_cycles+?,updated_at=? WHERE tool_id=?',(cycles,utc_now(),tool_id))
            r=c.execute('SELECT * FROM tool_life WHERE tool_id=?',(tool_id,)).fetchone()
            if not r: raise ValueError('刀模不存在')
            d=dict(r); ratio=(d['current_cycles']/d['max_cycles']) if d['max_cycles'] else 0
            status='expired' if d['max_cycles'] and d['current_cycles']>=d['max_cycles'] else ('service_due' if ratio>=0.9 else 'ready')
            c.execute('UPDATE tool_life SET status=? WHERE tool_id=?',(status,tool_id)); d['status']=status; d['life_ratio']=ratio; return d
