from __future__ import annotations

from pathlib import Path
from tempfile import TemporaryDirectory
import json
import urllib.request

from PIL import Image

from cip3_ink import calculate_zones_from_grayscale, build_ppf_with_ink_zones
from device_center import DeviceProfile, DeviceRegistry
from die_library import DieLibrary
from erp_server import ERPApiServer
from folding import accordion, roll_fold, gate_fold, cross_fold
from jmf import build_status_query, parse_status_response


def test_device_registry(tmp: Path):
    reg = DeviceRegistry(tmp / "devices.json")
    profiles = reg.load()
    assert profiles
    p = DeviceProfile(id="press-1", name="Press 1", max_sheet_width_mm=740, max_sheet_height_mm=1040, gripper_mm=12)
    reg.upsert(p)
    got = reg.get("press-1")
    assert got and got.gripper_mm == 12
    assert got.validate_sheet(800, 1000)
    assert not got.validate_sheet(700, 1000)


def test_jmf():
    query = build_status_query("Press-01")
    assert b"StatusQuParams" in query and b"Press-01" in query
    response = b'''<?xml version="1.0" encoding="UTF-8"?>
    <JMF xmlns="http://www.CIP4.org/JDFSchema_1_1" SenderID="RIP-1" Version="1.6">
      <Response Type="Status"><DeviceInfo DeviceID="Press-01" DeviceStatus="Running">
        <JobPhase JobID="JOB-100" JobPartID="Part-1" Status="InProgress" PercentCompleted="62.5" />
      </DeviceInfo></Response>
    </JMF>'''
    status = parse_status_response(response)
    assert status.device_id == "Press-01"
    assert status.device_status == "Running"
    assert status.job_id == "JOB-100"
    assert status.percent_completed == 62.5


def test_cip3_zones():
    img = Image.new("L", (100, 10), 255)
    px = img.load()
    for x in range(50):
        for y in range(10):
            px[x, y] = 0
    result = calculate_zones_from_grayscale(img, zones=2, channel="K")
    assert result.zones == [100.0, 0.0]
    assert result.average == 50.0
    ppf = build_ppf_with_ink_zones("JOB-1", 740, 1040, [result])
    assert "%%CIP3-InkZone-K: 100.00 0.00" in ppf


def test_folding():
    a = accordion(600, 6)
    assert len(a.fold_lines_mm) == 5 and abs(a.panels[-1].x1_mm - 600) < 1e-6
    r = roll_fold(600, 3, tuck_mm=3)
    assert len(r.panels) == 3 and abs(r.panels[-1].x1_mm - 600) < 1e-6
    g = gate_fold(400)
    assert g.fold_lines_mm == [100, 200, 300]
    c = cross_fold(400, 300)
    assert c["vertical_fold_mm"] == 200 and c["horizontal_fold_mm"] == 150


def test_die_library(tmp: Path):
    source = tmp / "knife.pdf"
    source.write_bytes(b"fake-die-file")
    lib = DieLibrary(tmp / "dies")
    a = lib.add(source, name="盒型A", customer="客户甲", product_code="BOX-A")
    b = lib.add(source, name="重复")
    assert a.id == b.id
    assert lib.list("BOX-A")[0].id == a.id
    assert lib.remove(a.id)
    assert not lib.list()


def test_erp_api():
    api = ERPApiServer()
    host, port = api.start(port=0, api_token="secret")
    try:
        health = json.loads(urllib.request.urlopen(f"http://{host}:{port}/health", timeout=2).read())
        assert health["ok"]
        payload = json.dumps({"order_id": "ERP-001", "customer": "客户", "quantities": [100]}).encode()
        req = urllib.request.Request(
            f"http://{host}:{port}/v1/jobs", data=payload, method="POST",
            headers={"Content-Type": "application/json", "Authorization": "Bearer secret"},
        )
        with urllib.request.urlopen(req, timeout=2) as response:
            assert response.status == 202
        accepted = api.bridge.queue.get(timeout=1)
        assert accepted.ticket.order_id == "ERP-001"
    finally:
        api.stop()


def main():
    with TemporaryDirectory() as td:
        tmp = Path(td)
        test_device_registry(tmp)
        test_jmf()
        test_cip3_zones()
        test_folding()
        test_die_library(tmp)
        test_erp_api()
    print("V1.3 PASS")


if __name__ == "__main__":
    main()
