from __future__ import annotations

import json
import sqlite3
import tempfile
from pathlib import Path

from access_control import AccessDenied, UserStore, require
from backup_restore import create_backup, inspect_backup, restore_backup
from branding import BrandConfig, load_brand, save_brand
from first_run import FirstRunState, load_first_run, save_first_run
from localization import Translator
from migration_manager import MigrationManager


def main():
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        dbp = root / "test.sqlite3"
        with sqlite3.connect(dbp) as db:
            db.executescript("""
            CREATE TABLE meta(key TEXT PRIMARY KEY,value TEXT NOT NULL);
            INSERT INTO meta VALUES('schema_version','2');
            CREATE TABLE audit_log(id INTEGER PRIMARY KEY,created_at TEXT,event TEXT,severity TEXT,details_json TEXT);
            CREATE TABLE production_jobs(id INTEGER PRIMARY KEY,created_at TEXT,updated_at TEXT,status TEXT,title TEXT,output_path TEXT,snapshot_json TEXT,summary_json TEXT,error TEXT,attempts INTEGER DEFAULT 0);
            """)
        mgr = MigrationManager(dbp)
        result = mgr.migrate(3)
        assert mgr.current_version() == 3
        assert result["backup"] and Path(result["backup"]).exists()

        users = UserStore(dbp)
        admin_id = users.create_user("admin", "StrongPass123!", "admin", "Administrator")
        admin = users.authenticate("admin", "StrongPass123!")
        assert admin and admin.can("anything")
        sales_id = users.create_user("sales01", "StrongPass123!", "sales", "Sales")
        sales = users.authenticate("sales01", "StrongPass123!")
        assert sales and sales.can("quote.manage") and not sales.can("mes.report")
        try:
            require(sales, "mes.report")
            raise AssertionError("permission should be denied")
        except AccessDenied:
            pass
        users.set_override(sales_id, "mes.report", True)
        sales2 = users.authenticate("sales01", "StrongPass123!")
        assert sales2 and sales2.can("mes.report")

        brand_path = root / "branding.json"
        cfg = BrandConfig(product_name="Imposer X", company_name="ACME Print", support_email="help@example.com")
        save_brand(cfg, brand_path)
        assert load_brand(brand_path).company_name == "ACME Print"

        fr_path = root / "first_run.json"
        save_first_run(FirstRunState(completed=True, locale="en_US", company_name="ACME Print", admin_created=True), fr_path)
        assert load_first_run(fr_path).completed
        assert Translator("en_US").tr("app.home") == "Workspace"

        # Backup/restore with isolated XDG dirs so no user data is touched.
        import app_paths, backup_restore
        data = root / "data"; config = root / "config"
        data.mkdir(); config.mkdir()
        (data / "sample.txt").write_text("hello", encoding="utf-8")
        (config / "config.json").write_text('{"ok":true}', encoding="utf-8")
        # Patch module functions for this test only.
        backup_restore.data_dir = lambda: data
        backup_restore.config_dir = lambda: config
        backup_restore.database_path = lambda: dbp
        backup_file = root / "backup.dibackup"
        info = create_backup(backup_file)
        assert info["files"] >= 3
        manifest = inspect_backup(backup_file)
        assert manifest["backup_format"] == 1
        restore_data = root / "restore_data"; restore_cfg = root / "restore_cfg"
        restored = restore_backup(backup_file, restore_data, restore_cfg)
        assert restored["restored"] >= 3
        assert (restore_data / "sample.txt").read_text(encoding="utf-8") == "hello"

    print("V2.0 PASS")

if __name__ == "__main__":
    main()
