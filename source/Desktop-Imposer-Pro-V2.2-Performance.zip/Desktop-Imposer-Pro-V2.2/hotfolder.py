from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
import json
import shutil
import time

from imposition import InputJob, ImpositionSettings
from preflight_provider import run_preflight
from production_service import atomic_production_export


SUPPORTED_EXTENSIONS = {".pdf", ".png", ".jpg", ".jpeg", ".tif", ".tiff", ".webp", ".bmp"}


def _safe_move(src: Path, dst_dir: Path) -> Path:
    dst_dir.mkdir(parents=True, exist_ok=True)
    dst = dst_dir / src.name
    if dst.exists():
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        dst = dst_dir / f"{src.stem}_{stamp}{src.suffix}"
        counter = 2
        while dst.exists():
            dst = dst_dir / f"{src.stem}_{stamp}_{counter}{src.suffix}"
            counter += 1
    shutil.move(str(src), str(dst))
    return dst


def _append_log(path: str | Path | None, payload: dict) -> None:
    if not path:
        return
    log_path = Path(path)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    record = {"time": datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds"), **payload}
    with log_path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False, default=str) + "\n")


@dataclass
class HotFolderProcessor:
    """Polling Hot Folder engine independent from Qt.

    Files are processed only after `settle_seconds`. Optional archive/failure folders
    make the workflow suitable for unattended production. JSONL task logging is
    intentionally append-only so it remains useful after a crash or restart.
    """

    settle_seconds: float = 5.0
    processed: dict[str, tuple[int, int]] = field(default_factory=dict)

    def reset(self) -> None:
        self.processed.clear()

    def scan_once(
        self,
        input_dir: str | Path,
        output_dir: str | Path,
        settings: ImpositionSettings,
        quantity: int = 1,
        *,
        archive_dir: str | Path | None = None,
        failed_dir: str | Path | None = None,
        log_path: str | Path | None = None,
        move_success: bool = False,
        move_failure: bool = False,
        db=None,
    ) -> dict:
        src_dir = Path(input_dir)
        dst_dir = Path(output_dir)
        if not src_dir.is_dir():
            raise ValueError(f"Hot Folder 输入目录不存在：{src_dir}")
        dst_dir.mkdir(parents=True, exist_ok=True)
        archive_path = Path(archive_dir) if archive_dir else dst_dir / "_archive"
        failed_path = Path(failed_dir) if failed_dir else dst_dir / "_failed"

        now = time.time()
        processed_now = []
        skipped = []
        errors = []

        for path in sorted(src_dir.iterdir(), key=lambda p: p.name.lower()):
            if not path.is_file() or path.suffix.lower() not in SUPPORTED_EXTENSIONS:
                continue
            if path.stem.endswith("_imposed"):
                continue
            try:
                stat = path.stat()
                signature = (int(stat.st_mtime_ns), int(stat.st_size))
                key = str(path.resolve())
                if self.processed.get(key) == signature:
                    skipped.append(path.name)
                    continue
                if now - stat.st_mtime < self.settle_seconds:
                    skipped.append(path.name)
                    continue

                out = dst_dir / f"{path.stem}_imposed.pdf"
                _append_log(log_path, {"event": "start", "input": str(path), "output": str(out)})
                job = InputJob(
                    path=path,
                    quantity=max(1, int(quantity)),
                    trim_width_mm=settings.trim_width_mm,
                    trim_height_mm=settings.trim_height_mm,
                    bleed_mm=settings.bleed_mm,
                    name=path.stem,
                )
                preflight = run_preflight([job], settings)
                if preflight.get("errors"):
                    raise ValueError("印前检查未通过：" + "；".join(preflight["errors"][:6]))
                manifest = atomic_production_export([job], out, settings, db=db, write_manifest=True, preflight_report=preflight)
                summary = manifest["summary"]
                archived_to = None
                if move_success and path.exists():
                    archived_to = _safe_move(path, archive_path)
                else:
                    self.processed[key] = signature
                result = {
                    "input": str(path), "output": str(out), "summary": summary,
                    "preflight": preflight, "archived_to": str(archived_to) if archived_to else "",
                }
                processed_now.append(result)
                _append_log(log_path, {
                    "event": "success", "input": str(path), "output": str(out),
                    "archive": str(archived_to) if archived_to else "",
                    "sheet_count": summary.get("sheet_count"), "items": summary.get("total_items"),
                    "warnings": preflight.get("warnings", []),
                })
            except Exception as exc:
                failed_to = None
                try:
                    if move_failure and path.exists():
                        failed_to = _safe_move(path, failed_path)
                except Exception as move_exc:
                    exc = RuntimeError(f"{exc}；失败文件移动失败：{move_exc}")
                err = {"input": str(path), "error": str(exc), "failed_to": str(failed_to) if failed_to else ""}
                errors.append(err)
                _append_log(log_path, {"event": "failure", **err})

        return {"processed": processed_now, "skipped": skipped, "errors": errors}
