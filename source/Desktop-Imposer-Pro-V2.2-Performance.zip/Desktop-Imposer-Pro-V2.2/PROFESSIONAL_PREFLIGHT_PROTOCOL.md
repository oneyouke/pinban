# Professional Preflight Provider Protocol

The built-in scanner detects many production risks but does not claim ISO PDF/X certification. A commercial PDF SDK or preflight product can be connected without changing the imposition UI.

## Configuration

Set environment variable:

```text
DESKTOP_IMPOSER_PREFLIGHT_CLI=C:\Program Files\Vendor\preflight-bridge.exe
```

The application invokes:

```text
preflight-bridge.exe request.json response.json
```

## Request

```json
{
  "schema_version": 1,
  "jobs": [
    {
      "path": "C:\\orders\\front-back.pdf",
      "quantity": 1000,
      "trim_width_mm": 90,
      "trim_height_mm": 54,
      "bleed_mm": 3,
      "name": "Business Card"
    }
  ],
  "settings": {"require_pdfx": true}
}
```

## Response

```json
{
  "provider": "Vendor SDK 2026",
  "certified": true,
  "standard_claim": "PDF/X-4 preflight profile PrintShop-v3",
  "errors": [],
  "warnings": ["Spot color CutContour retained"],
  "infos": ["OutputIntent: FOGRA51"]
}
```

Only set `certified=true` if the external product/license/profile really performed the claimed standard validation. A bridge failure is treated as a production-blocking error instead of silently falling back to the built-in scanner.
