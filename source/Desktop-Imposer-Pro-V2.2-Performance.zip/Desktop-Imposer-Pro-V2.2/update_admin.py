from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path

from licensing import sign_payload
from product import UPDATE_MANIFEST_SCHEMA_VERSION


def main() -> None:
    p = argparse.ArgumentParser(description="Create a signed update manifest. Keep the private key off client machines.")
    p.add_argument("--private", required=True)
    p.add_argument("--version", required=True)
    p.add_argument("--download-url", required=True)
    p.add_argument("--sha256", required=True)
    p.add_argument("--notes", default="")
    p.add_argument("--out", default="update-manifest.json")
    args = p.parse_args()
    if not args.download_url.lower().startswith("https://"):
        raise SystemExit("download URL must use HTTPS")
    payload = {
        "schema_version": UPDATE_MANIFEST_SCHEMA_VERSION,
        "version": args.version,
        "download_url": args.download_url,
        "sha256": args.sha256.lower(),
        "notes": args.notes,
        "published_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }
    private = Path(args.private).read_bytes()
    doc = {"payload": payload, "signature": sign_payload(payload, private)}
    Path(args.out).write_text(json.dumps(doc, ensure_ascii=False, indent=2), encoding="utf-8")
    print(args.out)


if __name__ == "__main__":
    main()
