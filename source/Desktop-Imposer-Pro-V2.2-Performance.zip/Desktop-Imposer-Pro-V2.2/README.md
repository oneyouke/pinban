# Desktop Imposer Pro V2.1

V2.1 是 V2.0 正式商业产品基线上的“发布强化版”。它保留完整的拼版、印前、Nesting、书刊、设备/JDF/JMF、RIP、MES/OEE、库存/工艺、ERP、报价与经营能力，并集中加强真实客户现场最容易出问题的升级、备份、恢复与运维环节。

## V2.1 新增

- 崩溃/断电运行标记，与项目自动恢复联动；
- SHA-256 哈希链安全审计；
- 定时 `.dibackup` 自动备份和轮换；
- 桌面自动备份策略设置；
- 数据库/磁盘/备份/审计链系统健康检查；
- 签名更新清单 + HTTPS 下载 + SHA-256 staging；
- 更新包不会静默自动执行；
- 支持包新增 health-check 与 audit-chain 诊断；
- Windows 打包前 Core → V2.1 全量回归闸门。

详见 `V21_RELEASE_HARDENING.md`。

## Windows 自动封装

在 Windows 10/11 x64 构建机中运行：

```bat
BUILD_WINDOWS_DESKTOP.bat
```

正式签名商业构建使用：

```bat
BUILD_SIGNED_COMMERCIAL_RELEASE.bat
```

构建链会先编译检查并运行 Core、Commercial、V1.1…V2.1 全量测试，再进入 PyInstaller、封装后 QtPdf 自检、Portable ZIP、NSIS 安装器和 SHA-256 发布清单步骤。

## 正式销售前仍必须完成

- 替换 `APP_ID / VENDOR_NAME / SUPPORT_EMAIL` 等占位品牌信息；
- 审核并替换正式 EULA；
- 配置公司 Windows Authenticode 代码签名证书；
- 在干净 Windows 10/11 机器完成安装/升级/卸载/高 DPI/中文路径测试；
- 用真实印刷设备完成 JDF/JMF/RIP/CIP3/热文件夹联调；
- 对 PDF/X、ICC、透明度扁平化等标准级认证使用经过验证的专业 PDF Provider。

V2.1 的经营财务仍是经营管理层，不代替法定总账、税务申报或电子发票系统。
