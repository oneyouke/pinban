# Privacy / Data Flow

Desktop Imposer Pro 1.0 is local-first and includes no telemetry uploader by default.

Local application data may include:

- project paths and imposition parameters;
- production queue metadata;
- audit events;
- output/input SHA-256 hashes;
- application logs;
- local license state.

Customer PDF/image bytes are not copied into the SQLite production database. Hot Folder archiving moves the original files only when the operator explicitly enables that option.

A support bundle contains runtime/version diagnostics and rotating application logs. It is designed not to include customer artwork or the production SQLite database. Operators should still review a support bundle before sending it outside the organization.
