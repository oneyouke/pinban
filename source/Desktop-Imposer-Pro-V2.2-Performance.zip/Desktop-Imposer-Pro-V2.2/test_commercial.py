from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from pathlib import Path
from tempfile import TemporaryDirectory

from reportlab.pdfgen import canvas

from imposition import InputJob, ImpositionSettings
from licensing import LicenseManager, generate_keypair, issue_license, machine_fingerprint
from production_service import atomic_production_export, sha256_file, validate_pdf_output
from project_file import build_project_snapshot, load_project, save_project
from queue_service import PersistentQueue
from storage import ProductionDB


def make_pdf(path: Path, w_mm: float = 90, h_mm: float = 54, label: str = "SAMPLE") -> None:
    pt = 72 / 25.4
    c = canvas.Canvas(str(path), pagesize=(w_mm * pt, h_mm * pt))
    c.setFont("Helvetica-Bold", 16)
    c.drawString(12, h_mm * pt / 2, label)
    c.rect(1, 1, w_mm * pt - 2, h_mm * pt - 2)
    c.showPage(); c.save()


def main() -> None:
    with TemporaryDirectory() as td:
        root = Path(td)
        src = root / "card.pdf"
        make_pdf(src)
        settings = ImpositionSettings(
            sheet_width_mm=450, sheet_height_mm=320,
            trim_width_mm=90, trim_height_mm=54,
            margin_x_mm=10, margin_y_mm=10,
            gap_x_mm=4, gap_y_mm=4,
            scale_mode="actual", crop_marks=True,
            copies_per_page=1,
        )
        jobs = [InputJob(src, 7, 90, 54, 0, "CARD")]

        # 1. Signed offline commercial license.
        private, public = generate_keypair()
        pub_path = root / "vendor_public_key.pem"
        pub_path.write_bytes(public)
        expires = (datetime.now(timezone.utc) + timedelta(days=365)).isoformat(timespec="seconds")
        doc = issue_license(private, license_id="LIC-TEST-001", customer="Test Print Co.",
                            expires_at=expires, machine=machine_fingerprint())
        manager = LicenseManager(pub_path)
        status = manager.validate_document(doc)
        assert status.valid and status.mode == "licensed" and status.customer == "Test Print Co."
        tampered = json.loads(json.dumps(doc))
        tampered["payload"]["customer"] = "Attacker"
        assert manager.validate_document(tampered).valid is False

        # 2. Project file survives save/load and keeps production settings/jobs.
        snapshot = build_project_snapshot(jobs, settings, layout_override=None, automation={"hot_input": "C:/in"})
        project_path = save_project(root / "sample.imposeproj", snapshot)
        loaded = load_project(project_path)
        assert loaded["jobs"][0]["quantity"] == 7
        assert loaded["settings"]["scale_mode"] == "actual"

        # 3. Atomic production export + reopen validation + hash + sidecar.
        out = root / "production.pdf"
        manifest = atomic_production_export(jobs, out, settings)
        assert out.exists() and Path(str(out) + ".production.json").exists()
        assert manifest["output_sha256"] == sha256_file(out)
        check = validate_pdf_output(out, manifest["output_pages"])
        assert check["page_count"] == manifest["output_pages"]

        # 4. Persistent database settings/audit.
        db = ProductionDB(root / "production.sqlite3")
        db.set_setting("ui.test", {"x": 1})
        assert db.get_setting("ui.test")["x"] == 1
        db.audit("test.event", {"ok": True})
        assert db.list_audit(5)[0]["event"] == "test.event"

        # 5. Persistent production queue survives enqueue/claim/process.
        queue_out = root / "queue-output.pdf"
        job_id = db.enqueue("Queue Test", queue_out, snapshot)
        queue = PersistentQueue(db)
        result = queue.process_next()
        assert result and result["job_id"] == job_id and result["status"] == "succeeded", result
        jobs_after = db.list_jobs(10)
        queued_row = next(x for x in jobs_after if x["id"] == job_id)
        assert queued_row["status"] == "succeeded"
        assert queue_out.exists() and Path(str(queue_out) + ".production.json").exists()

        # 6. Failed queue job is persisted and can be retried.
        bad_snapshot = json.loads(json.dumps(snapshot))
        bad_snapshot["jobs"][0]["path"] = str(root / "missing.pdf")
        bad_id = db.enqueue("Broken", root / "broken.pdf", bad_snapshot)
        failed = queue.process_next()
        assert failed and failed["job_id"] == bad_id and failed["status"] == "failed"
        db.retry_job(bad_id)
        row = next(x for x in db.list_jobs(20) if x["id"] == bad_id)
        assert row["status"] == "queued"
        db.cancel_job(bad_id)

        # 7. A process crash must not strand a job forever in running.
        crash_id = db.enqueue("Crash Recovery", root / "crash.pdf", snapshot)
        claimed = db.claim_next_job()
        assert claimed and claimed["id"] == crash_id
        db2 = ProductionDB(root / "production.sqlite3")
        recovered = next(x for x in db2.list_jobs(50) if x["id"] == crash_id)
        assert recovered["status"] == "queued" and "异常中断" in recovered["error"]

        # 8. Corrupt local metadata DB is quarantined rather than preventing startup.
        corrupt_db = root / "corrupt.sqlite3"
        corrupt_db.write_bytes(b"this is not sqlite")
        db3 = ProductionDB(corrupt_db)
        assert db3.recovered_corrupt_path and db3.recovered_corrupt_path.exists()
        assert db3.get_setting("fresh", "ok") == "ok"

        print("COMMERCIAL PASS")
        print({
            "license": status.mode,
            "project": str(project_path),
            "output_sha256": manifest["output_sha256"][:16],
            "queue_job": job_id,
            "audit_rows": len(db.list_audit(100)),
        })


if __name__ == "__main__":
    main()
