from __future__ import annotations
from dataclasses import dataclass
from telemetry import TelemetrySample, TelemetryService
from alerts import AlertManager

@dataclass(frozen=True)
class AutoReportResult:
    updated: bool
    completed_sheets: int
    good_count: int
    waste_count: int
    reason: str

class TelemetryMESBridge:
    """Translate trustworthy machine counters into MES progress reports."""
    def __init__(self, telemetry: TelemetryService, mes, alerts: AlertManager):
        self.telemetry, self.mes, self.alerts = telemetry, mes, alerts
        self._baseline: dict[tuple[str,int], TelemetrySample] = {}

    def process(self, run_id:int, sample:TelemetrySample) -> AutoReportResult:
        s=self.telemetry.ingest(sample)
        run=self.mes.get_run(run_id)
        if not run: raise ValueError('MES Run 不存在')
        if str(run.get('device_id') or '') != s.device_id:
            self.alerts.raise_alert('error',s.device_id,'设备采样与 MES Run 绑定设备不一致','DEVICE_MISMATCH')
            return AutoReportResult(False,int(run.get('completed_sheets') or 0),int(run.get('good_count') or 0),int(run.get('waste_count') or 0),'device mismatch')
        key=(s.device_id,int(run_id)); prev=self._baseline.get(key)
        self._baseline[key]=s
        if prev is None:
            return AutoReportResult(False,int(run.get('completed_sheets') or 0),int(run.get('good_count') or 0),int(run.get('waste_count') or 0),'baseline established')
        if s.total_counter < prev.total_counter or s.good_counter < prev.good_counter or s.waste_counter < prev.waste_counter:
            self.alerts.raise_alert('warning',s.device_id,'设备计数器回退，已停止自动报工','COUNTER_RESET')
            return AutoReportResult(False,int(run.get('completed_sheets') or 0),int(run.get('good_count') or 0),int(run.get('waste_count') or 0),'counter reset')
        dt=s.total_counter-prev.total_counter; dg=s.good_counter-prev.good_counter; dw=s.waste_counter-prev.waste_counter
        if dt>100000 or dg>100000 or dw>100000:
            self.alerts.raise_alert('warning',s.device_id,'设备计数器异常跳变，已停止自动报工','COUNTER_JUMP')
            return AutoReportResult(False,int(run.get('completed_sheets') or 0),int(run.get('good_count') or 0),int(run.get('waste_count') or 0),'counter jump')
        completed=int(run.get('completed_sheets') or 0)+dt
        good=int(run.get('good_count') or 0)+dg
        waste=int(run.get('waste_count') or 0)+dw
        if dt or dg or dw:
            self.mes.report_progress(run_id,completed_sheets=completed,good_count=good,waste_count=waste,operator='AUTO')
            return AutoReportResult(True,completed,good,waste,'telemetry counters applied')
        return AutoReportResult(False,completed,good,waste,'no counter change')
