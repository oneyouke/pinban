from __future__ import annotations

from PySide6.QtCore import QThread, Signal, QTimer
from PySide6.QtWidgets import (
    QAbstractItemView, QDialog, QHBoxLayout, QLabel, QPushButton, QTableWidget,
    QTableWidgetItem, QVBoxLayout, QMessageBox,
)

from queue_service import PersistentQueue
from storage import ProductionDB


class QueueWorker(QThread):
    finished_one = Signal(dict)

    def __init__(self, queue: PersistentQueue, parent=None, job_id: int | None = None):
        super().__init__(parent)
        self.queue = queue
        self.job_id = job_id

    def run(self):
        result = self.queue.process_next(self.job_id) or {"status": "empty"}
        self.finished_one.emit(result)


class ProductionQueueDialog(QDialog):
    def __init__(self, db: ProductionDB, parent=None, scheduler=None, registry=None):
        super().__init__(parent)
        self.db = db
        self.scheduler = scheduler
        self.queue = PersistentQueue(db, scheduler=scheduler, registry=registry)
        self.worker: QueueWorker | None = None
        self.setWindowTitle("生产队列")
        self.resize(980, 520)
        root = QVBoxLayout(self)
        root.addWidget(QLabel("队列持久化在本机 SQLite；软件异常退出后，未完成任务仍会保留。"))
        self.table = QTableWidget(0, 7)
        self.table.setHorizontalHeaderLabels(["ID", "状态", "任务", "输出", "创建时间", "尝试", "错误"])
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        root.addWidget(self.table, 1)
        buttons = QHBoxLayout()
        self.refresh_btn = QPushButton("刷新")
        self.run_btn = QPushButton("处理下一项")
        self.retry_btn = QPushButton("重试选中")
        self.cancel_btn = QPushButton("取消选中")
        buttons.addWidget(self.refresh_btn); buttons.addWidget(self.run_btn); buttons.addWidget(self.retry_btn); buttons.addWidget(self.cancel_btn); buttons.addStretch()
        root.addLayout(buttons)
        self.refresh_btn.clicked.connect(self.refresh)
        self.run_btn.clicked.connect(self.process_next)
        self.retry_btn.clicked.connect(self.retry_selected)
        self.cancel_btn.clicked.connect(self.cancel_selected)
        self.timer = QTimer(self); self.timer.setInterval(2000); self.timer.timeout.connect(self.refresh); self.timer.start()
        self.refresh()

    def refresh(self):
        rows = self.db.list_jobs(200)
        self.table.setRowCount(0)
        for row in rows:
            r = self.table.rowCount(); self.table.insertRow(r)
            values = [row.get("id"), row.get("status"), row.get("title"), row.get("output_path"), row.get("created_at"), row.get("attempts"), row.get("error") or ""]
            for c, value in enumerate(values):
                self.table.setItem(r, c, QTableWidgetItem(str(value)))
        self.table.resizeColumnsToContents()

    def _selected_id(self) -> int | None:
        row = self.table.currentRow()
        if row < 0 or not self.table.item(row, 0):
            return None
        return int(self.table.item(row, 0).text())

    def process_next(self):
        if self.worker and self.worker.isRunning():
            return
        self.run_btn.setEnabled(False)
        job_id = self.scheduler.next_scheduled_job_id() if self.scheduler else None
        self.worker = QueueWorker(self.queue, self, job_id=job_id)
        self.worker.finished_one.connect(self._done)
        self.worker.start()

    def _done(self, result: dict):
        self.run_btn.setEnabled(True)
        self.refresh()
        if result.get("status") == "failed":
            QMessageBox.warning(self, "生产任务失败", str(result.get("error") or "未知错误"))

    def retry_selected(self):
        job_id = self._selected_id()
        if job_id is not None:
            self.db.retry_job(job_id)
            if self.scheduler:
                try: self.scheduler.mark_schedule_state(job_id, "planned")
                except Exception: pass
            self.refresh()

    def cancel_selected(self):
        job_id = self._selected_id()
        if job_id is not None:
            self.db.cancel_job(job_id)
            if self.scheduler:
                try: self.scheduler.mark_schedule_state(job_id, "canceled")
                except Exception: pass
            self.refresh()
