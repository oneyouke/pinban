from __future__ import annotations

import argparse
import json
from pathlib import Path
from licensing import generate_keypair, issue_license


def main() -> None:
    p = argparse.ArgumentParser(description="Desktop Imposer commercial license utility. Keep private keys OFF production clients.")
    sub = p.add_subparsers(dest="cmd", required=True)
    g = sub.add_parser("generate-keypair")
    g.add_argument("--private", default="vendor_private_key.pem")
    g.add_argument("--public", default="vendor_public_key.pem")
    i = sub.add_parser("issue")
    i.add_argument("--private", required=True)
    i.add_argument("--out", required=True)
    i.add_argument("--license-id", required=True)
    i.add_argument("--customer", required=True)
    i.add_argument("--edition", default="Pro")
    i.add_argument("--expires", default="")
    i.add_argument("--machine", default="")
    args = p.parse_args()
    if args.cmd == "generate-keypair":
        private, public = generate_keypair()
        Path(args.private).write_bytes(private)
        Path(args.public).write_bytes(public)
        print(f"private: {args.private}\npublic: {args.public}")
    else:
        doc = issue_license(Path(args.private).read_bytes(), license_id=args.license_id, customer=args.customer,
                            edition=args.edition, expires_at=args.expires, machine=args.machine)
        Path(args.out).write_text(json.dumps(doc, ensure_ascii=False, indent=2), encoding="utf-8")
        print(args.out)


if __name__ == "__main__":
    main()
