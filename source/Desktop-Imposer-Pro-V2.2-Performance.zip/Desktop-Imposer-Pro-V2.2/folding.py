from __future__ import annotations

from dataclasses import dataclass, asdict


@dataclass(frozen=True)
class FoldPanel:
    panel: int
    x0_mm: float
    x1_mm: float
    face: str

    def to_dict(self):
        return asdict(self)


@dataclass(frozen=True)
class FoldTemplate:
    name: str
    folds: int
    style: str
    sheet_width_mm: float
    panels: list[FoldPanel]
    fold_lines_mm: list[float]
    notes: str = ""

    def to_dict(self):
        return {
            "name": self.name,
            "folds": self.folds,
            "style": self.style,
            "sheet_width_mm": self.sheet_width_mm,
            "panels": [p.to_dict() for p in self.panels],
            "fold_lines_mm": list(self.fold_lines_mm),
            "notes": self.notes,
        }


def accordion(width_mm: float, panels: int) -> FoldTemplate:
    if width_mm <= 0 or panels < 2:
        raise ValueError("风琴折需要有效宽度和至少 2 个面板")
    w = width_mm / panels
    items = [FoldPanel(i + 1, i * w, (i + 1) * w, "front" if i % 2 == 0 else "back") for i in range(panels)]
    return FoldTemplate("风琴折", panels - 1, "accordion", width_mm, items, [w * i for i in range(1, panels)])


def roll_fold(width_mm: float, panels: int, tuck_mm: float = 1.5) -> FoldTemplate:
    if width_mm <= 0 or panels < 3:
        raise ValueError("卷折需要至少 3 个面板")
    if tuck_mm < 0:
        raise ValueError("内折收缩量不能为负数")
    base = width_mm / panels
    widths = [base] * panels
    # Inner panels are slightly narrower to avoid buckle on real stock.
    for i in range(1, panels):
        widths[i] -= tuck_mm / max(1, panels - 1)
    widths[0] += tuck_mm
    x = 0.0
    items = []
    lines = []
    for i, w in enumerate(widths):
        items.append(FoldPanel(i + 1, x, x + w, "front"))
        x += w
        if i < panels - 1:
            lines.append(x)
    return FoldTemplate("卷折", panels - 1, "roll", width_mm, items, lines, f"内折总收缩 {tuck_mm:g} mm")


def gate_fold(width_mm: float) -> FoldTemplate:
    if width_mm <= 0:
        raise ValueError("宽度必须大于 0")
    quarter = width_mm / 4
    widths = [quarter, quarter, quarter, quarter]
    x = 0.0
    items=[]; lines=[]
    for i,w in enumerate(widths):
        items.append(FoldPanel(i+1,x,x+w,"front")); x += w
        if i<3: lines.append(x)
    return FoldTemplate("对门折", 3, "gate", width_mm, items, lines)


def cross_fold(width_mm: float, height_mm: float) -> dict:
    if width_mm <= 0 or height_mm <= 0:
        raise ValueError("尺寸必须大于 0")
    return {
        "name": "十字折",
        "style": "cross",
        "vertical_fold_mm": width_mm / 2,
        "horizontal_fold_mm": height_mm / 2,
        "panels": 4,
    }
