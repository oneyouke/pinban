from __future__ import annotations
from PySide6.QtWidgets import QDialog,QVBoxLayout,QTabWidget,QWidget,QTableWidget,QTableWidgetItem,QPushButton,QHBoxLayout,QLabel,QHeaderView
from inventory import InventoryManager
from routing import RoutingManager
from tooling import ToolLifeManager
from logistics import LogisticsManager

class SmartFactoryConsoleDialog(QDialog):
    def __init__(self, db, registry, parent=None):
        super().__init__(parent)
        self.setWindowTitle('智能工厂控制台 · V1.7')
        self.resize(1100,720)
        self.db=db; self.registry=registry
        self.inventory=InventoryManager(db); self.routing=RoutingManager(db,registry); self.tooling=ToolLifeManager(db); self.logistics=LogisticsManager(db)
        root=QVBoxLayout(self); root.addWidget(QLabel('库存 · 跨工序路线 · 刀模寿命 · 物流追踪'))
        self.tabs=QTabWidget(); root.addWidget(self.tabs,1)
        self.inv_table=self._tab('库存与补货',['SKU','名称','分类','在手','预留','可用','补货点'])
        self.route_table=self._tab('跨工序甘特',['任务','路线','顺序','工序','设备','状态','计划开始','计划结束'])
        self.tool_table=self._tab('刀模寿命',['刀模ID','名称','当前次数','寿命上限','状态'])
        self.log_table=self._tab('物流追踪',['单元码','订单','批次','托盘','数量','状态','位置'])
        bar=QHBoxLayout(); refresh=QPushButton('刷新'); refresh.clicked.connect(self.refresh_all); bar.addWidget(refresh); bar.addStretch(); root.addLayout(bar)
        self.refresh_all()
    def _tab(self,title,headers):
        w=QWidget(); lay=QVBoxLayout(w); table=QTableWidget(0,len(headers)); table.setHorizontalHeaderLabels(headers); table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents); lay.addWidget(table); self.tabs.addTab(w,title); return table
    @staticmethod
    def _fill(table, rows):
        table.setRowCount(len(rows))
        for r,row in enumerate(rows):
            for c,val in enumerate(row): table.setItem(r,c,QTableWidgetItem(str(val)))
    def refresh_all(self):
        with self.db.connect() as c:
            inv=c.execute('SELECT sku,name,category,on_hand,reserved,(on_hand-reserved) available,reorder_point FROM inventory_items ORDER BY category,sku').fetchall()
            routes=c.execute('SELECT queue_job_id,route_name,seq,operation,device_id,status,planned_start,planned_end FROM operation_runs ORDER BY queue_job_id,seq').fetchall()
            tools=c.execute('SELECT tool_id,name,current_cycles,max_cycles,status FROM tool_life ORDER BY tool_id').fetchall()
            logs=c.execute('SELECT unit_code,order_id,lot_no,pallet_no,qty,status,location FROM logistics_units ORDER BY id DESC').fetchall()
        self._fill(self.inv_table,[tuple(x) for x in inv]); self._fill(self.route_table,[tuple(x) for x in routes]); self._fill(self.tool_table,[tuple(x) for x in tools]); self._fill(self.log_table,[tuple(x) for x in logs])
