param(
  [string]$SignTool = "signtool.exe",
  [string]$CertThumbprint = "",
  [string]$InnoCompiler = "",
  [switch]$SkipInstaller
)
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

python -m pip install -r requirements.txt pyinstaller
python test_engine.py
python test_commercial.py
python release_gate.py --strict
pyinstaller --noconfirm --clean DesktopImposer.spec

$exe = Join-Path $PSScriptRoot "dist\DesktopImposerPro\DesktopImposerPro.exe"
if ($CertThumbprint) {
  & $SignTool sign /sha1 $CertThumbprint /fd SHA256 /tr http://timestamp.digicert.com /td SHA256 $exe
}

if (-not $SkipInstaller) {
  if (-not $InnoCompiler) {
    $candidates = @(
      "$env:ProgramFiles\Inno Setup 7\ISCC.exe",
      "${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe"
    )
    $InnoCompiler = $candidates | Where-Object { Test-Path $_ } | Select-Object -First 1
  }
  if (-not $InnoCompiler) { throw "Inno Setup compiler not found. Pass -InnoCompiler or use -SkipInstaller." }
  & $InnoCompiler "installer.iss"
  $installer = Get-ChildItem "$PSScriptRoot\release\*.exe" | Sort-Object LastWriteTime -Descending | Select-Object -First 1
  if ($CertThumbprint -and $installer) {
    & $SignTool sign /sha1 $CertThumbprint /fd SHA256 /tr http://timestamp.digicert.com /td SHA256 $installer.FullName
  }
}
Write-Host "Release build finished."
