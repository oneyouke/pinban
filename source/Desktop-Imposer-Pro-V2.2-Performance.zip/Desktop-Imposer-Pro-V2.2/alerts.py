from __future__ import annotations
from datetime import datetime, timezone

def utc_now(): return datetime.now(timezone.utc).isoformat(timespec='seconds')

class AlertManager:
    def __init__(self, db):
        self.db=db
        with db.connect() as c:
            c.executescript('''CREATE TABLE IF NOT EXISTS alerts(
              id INTEGER PRIMARY KEY AUTOINCREMENT, severity TEXT NOT NULL, source TEXT NOT NULL, code TEXT NOT NULL DEFAULT '',
              message TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'open', created_at TEXT NOT NULL, acknowledged_at TEXT NOT NULL DEFAULT '');''')
    def raise_alert(self,severity:str,source:str,message:str,code:str='')->int:
        with self.db.connect() as c:
            cur=c.execute('INSERT INTO alerts(severity,source,code,message,created_at) VALUES(?,?,?,?,?)',(severity,source,code,message,utc_now()))
            return int(cur.lastrowid)
    def acknowledge(self, alert_id:int):
        with self.db.connect() as c:
            c.execute("UPDATE alerts SET status='acknowledged',acknowledged_at=? WHERE id=?",(utc_now(),alert_id))
