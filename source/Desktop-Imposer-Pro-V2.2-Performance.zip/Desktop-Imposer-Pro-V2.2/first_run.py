from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path

from app_paths import config_dir

@dataclass
class FirstRunState:
    completed: bool = False
    locale: str = "zh_CN"
    company_name: str = ""
    admin_created: bool = False
    backup_reminder_enabled: bool = True


def first_run_path() -> Path:
    return config_dir() / "first_run.json"


def load_first_run(path: str | Path | None = None) -> FirstRunState:
    p = Path(path) if path else first_run_path()
    if not p.exists():
        return FirstRunState()
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
        return FirstRunState(**{k: v for k, v in data.items() if k in FirstRunState.__annotations__})
    except Exception:
        return FirstRunState()


def save_first_run(state: FirstRunState, path: str | Path | None = None) -> Path:
    p = Path(path) if path else first_run_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(asdict(state), ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(p)
    return p
