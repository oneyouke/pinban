# V1.5 车间 MES 说明

V1.5 把预印生产与印刷执行拆成两个持久状态层。`production_jobs` 负责拼版/生产 PDF；`mes_runs` 负责印刷现场执行。

## 状态闭环

ERP Accepted → Prepress Queued → Prepress Running → Prepress Completed → Press Scheduled → Press Running → Completed。

## OEE

- Availability = 实际运行分钟 / 计划生产分钟
- Performance = 理论印张时间 / 实际运行分钟
- Quality = 良品 / (良品 + 废品)
- OEE = Availability × Performance × Quality

数据只有在现场持续报工、停机登记和设备速度参数准确时才有管理意义。
