from __future__ import annotations

import json
import sqlite3
import threading
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator

from app_paths import database_path
from product import DATABASE_SCHEMA_VERSION


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class ProductionDB:
    """Small, local, crash-safe production database.

    The database never stores customer PDF bytes; only metadata, queue snapshots,
    hashes and audit events. WAL mode improves resilience when UI and worker
    threads access it concurrently.
    """

    def __init__(self, path: str | Path | None = None) -> None:
        self.path = Path(path) if path else database_path()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self.recovered_corrupt_path: Path | None = None
        try:
            self._init_schema()
        except sqlite3.DatabaseError:
            if not self.path.exists():
                raise
            stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
            corrupt = self.path.with_name(f"{self.path.stem}.corrupt-{stamp}{self.path.suffix}")
            self.path.replace(corrupt)
            for suffix in ("-wal", "-shm"):
                extra = Path(str(self.path) + suffix)
                if extra.exists():
                    try: extra.replace(Path(str(corrupt) + suffix))
                    except Exception: pass
            self.recovered_corrupt_path = corrupt
            self._init_schema()
            self.audit("database.recreated_after_corruption", {"corrupt_copy": str(corrupt)}, "warning")
        self.recover_interrupted_jobs()

    @contextmanager
    def connect(self) -> Iterator[sqlite3.Connection]:
        conn = sqlite3.connect(self.path, timeout=15, isolation_level=None)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=FULL")
        conn.execute("PRAGMA foreign_keys=ON")
        conn.execute("PRAGMA busy_timeout=15000")
        try:
            yield conn
        finally:
            conn.close()

    def _init_schema(self) -> None:
        with self._lock, self.connect() as db:
            db.executescript(
                """
                CREATE TABLE IF NOT EXISTS meta (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS settings (
                    key TEXT PRIMARY KEY,
                    value_json TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS recent_projects (
                    path TEXT PRIMARY KEY,
                    opened_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS production_jobs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    status TEXT NOT NULL,
                    title TEXT NOT NULL,
                    output_path TEXT NOT NULL,
                    snapshot_json TEXT NOT NULL,
                    summary_json TEXT,
                    error TEXT,
                    attempts INTEGER NOT NULL DEFAULT 0
                );
                CREATE INDEX IF NOT EXISTS idx_jobs_status_created
                    ON production_jobs(status, created_at);
                CREATE INDEX IF NOT EXISTS idx_jobs_updated ON production_jobs(updated_at);
                CREATE TABLE IF NOT EXISTS audit_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at TEXT NOT NULL,
                    event TEXT NOT NULL,
                    severity TEXT NOT NULL,
                    details_json TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_audit_event_created ON audit_log(event,created_at);
                """
            )
            db.execute(
                "INSERT INTO meta(key,value) VALUES('schema_version',?) "
                "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (str(DATABASE_SCHEMA_VERSION),),
            )

    def set_setting(self, key: str, value: Any) -> None:
        with self._lock, self.connect() as db:
            db.execute(
                "INSERT INTO settings(key,value_json,updated_at) VALUES(?,?,?) "
                "ON CONFLICT(key) DO UPDATE SET value_json=excluded.value_json, updated_at=excluded.updated_at",
                (key, json.dumps(value, ensure_ascii=False), utc_now()),
            )

    def get_setting(self, key: str, default: Any = None) -> Any:
        with self.connect() as db:
            row = db.execute("SELECT value_json FROM settings WHERE key=?", (key,)).fetchone()
        if not row:
            return default
        try:
            return json.loads(row[0])
        except Exception:
            return default

    def add_recent_project(self, path: str | Path) -> None:
        p = str(Path(path).resolve())
        with self._lock, self.connect() as db:
            db.execute(
                "INSERT INTO recent_projects(path,opened_at) VALUES(?,?) "
                "ON CONFLICT(path) DO UPDATE SET opened_at=excluded.opened_at",
                (p, utc_now()),
            )
            db.execute(
                "DELETE FROM recent_projects WHERE path NOT IN "
                "(SELECT path FROM recent_projects ORDER BY opened_at DESC LIMIT 12)"
            )

    def recent_projects(self, limit: int = 12) -> list[dict[str, str]]:
        with self.connect() as db:
            rows = db.execute(
                "SELECT path,opened_at FROM recent_projects ORDER BY opened_at DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return [dict(r) for r in rows]

    def audit(self, event: str, details: dict[str, Any], severity: str = "info") -> None:
        with self._lock, self.connect() as db:
            db.execute(
                "INSERT INTO audit_log(created_at,event,severity,details_json) VALUES(?,?,?,?)",
                (utc_now(), event, severity, json.dumps(details, ensure_ascii=False, default=str)),
            )

    def list_audit(self, limit: int = 200) -> list[dict[str, Any]]:
        with self.connect() as db:
            rows = db.execute(
                "SELECT id,created_at,event,severity,details_json FROM audit_log ORDER BY id DESC LIMIT ?",
                (limit,),
            ).fetchall()
        result = []
        for row in rows:
            item = dict(row)
            try:
                item["details"] = json.loads(item.pop("details_json"))
            except Exception:
                item["details"] = item.pop("details_json")
            result.append(item)
        return result

    def enqueue(self, title: str, output_path: str | Path, snapshot: dict[str, Any]) -> int:
        now = utc_now()
        with self._lock, self.connect() as db:
            cur = db.execute(
                "INSERT INTO production_jobs(created_at,updated_at,status,title,output_path,snapshot_json) "
                "VALUES(?,?,?,?,?,?)",
                (now, now, "queued", title, str(output_path), json.dumps(snapshot, ensure_ascii=False)),
            )
            job_id = int(cur.lastrowid)
        self.audit("queue.enqueue", {"job_id": job_id, "title": title, "output_path": str(output_path)})
        return job_id

    def claim_job(self, job_id: int) -> dict[str, Any] | None:
        """Atomically claim a specific queued job.

        V1.4 scheduling uses this to honor assigned-device priority without
        changing the durable production_jobs state model.
        """
        with self._lock, self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            row = db.execute(
                "SELECT * FROM production_jobs WHERE id=? AND status='queued'",
                (int(job_id),),
            ).fetchone()
            if not row:
                db.execute("COMMIT")
                return None
            now = utc_now()
            db.execute(
                "UPDATE production_jobs SET status='running',updated_at=?,attempts=attempts+1 WHERE id=? AND status='queued'",
                (now, int(job_id)),
            )
            db.execute("COMMIT")
        item = dict(row)
        item["status"] = "running"
        item["snapshot"] = json.loads(item.pop("snapshot_json"))
        return item

    def claim_next_job(self) -> dict[str, Any] | None:
        with self._lock, self.connect() as db:
            row = db.execute(
                "SELECT id FROM production_jobs WHERE status='queued' ORDER BY id LIMIT 1"
            ).fetchone()
        return self.claim_job(int(row["id"])) if row else None

    def finish_job(self, job_id: int, status: str, summary: dict[str, Any] | None = None, error: str = "") -> None:
        if status not in {"succeeded", "failed", "canceled", "queued"}:
            raise ValueError("invalid job status")
        with self._lock, self.connect() as db:
            db.execute(
                "UPDATE production_jobs SET status=?,updated_at=?,summary_json=?,error=? WHERE id=?",
                (status, utc_now(), json.dumps(summary, ensure_ascii=False, default=str) if summary else None, error, job_id),
            )
        self.audit(f"queue.{status}", {"job_id": job_id, "error": error}, "error" if status == "failed" else "info")

    def recover_interrupted_jobs(self) -> int:
        """Return jobs left 'running' by an interrupted process to the queue."""
        with self._lock, self.connect() as db:
            rows = db.execute("SELECT id FROM production_jobs WHERE status='running'").fetchall()
            if not rows:
                return 0
            now = utc_now()
            ids = [int(r[0]) for r in rows]
            db.execute(
                "UPDATE production_jobs SET status='queued',updated_at=?,error=? WHERE status='running'",
                (now, "检测到上次生产被异常中断，已自动恢复到队列"),
            )
            for job_id in ids:
                db.execute(
                    "INSERT INTO audit_log(created_at,event,severity,details_json) VALUES(?,?,?,?)",
                    (now, "queue.recovered_after_interrupt", "warning", json.dumps({"job_id": job_id}, ensure_ascii=False)),
                )
            return len(ids)

    def has_queued_job(self) -> bool:
        with self.connect() as db:
            return db.execute("SELECT 1 FROM production_jobs WHERE status='queued' LIMIT 1").fetchone() is not None

    def list_jobs(self, limit: int = 200) -> list[dict[str, Any]]:
        with self.connect() as db:
            rows = db.execute(
                "SELECT id,created_at,updated_at,status,title,output_path,summary_json,error,attempts "
                "FROM production_jobs ORDER BY id DESC LIMIT ?",
                (limit,),
            ).fetchall()
        result = []
        for row in rows:
            item = dict(row)
            if item.get("summary_json"):
                try:
                    item["summary"] = json.loads(item.pop("summary_json"))
                except Exception:
                    pass
            result.append(item)
        return result

    def retry_job(self, job_id: int) -> None:
        with self._lock, self.connect() as db:
            db.execute(
                "UPDATE production_jobs SET status='queued',updated_at=?,error='' WHERE id=? AND status IN ('failed','canceled')",
                (utc_now(), job_id),
            )

    def cancel_job(self, job_id: int) -> None:
        with self._lock, self.connect() as db:
            db.execute(
                "UPDATE production_jobs SET status='canceled',updated_at=? WHERE id=? AND status='queued'",
                (utc_now(), job_id),
            )
