@echo off
setlocal
cd /d "%~dp0"
echo Desktop Imposer Pro - Environment Diagnostic
echo ==============================================
echo OS:
ver
echo.
echo Python launcher:
where py 2>nul
py -0p 2>nul
echo.
echo Python:
where python 2>nul
python --version 2>nul
echo.
echo PowerShell:
powershell -NoProfile -Command "$PSVersionTable.PSVersion"
echo.
echo Disk free:
powershell -NoProfile -Command "Get-PSDrive -Name C | Select-Object Used,Free"
echo.
echo Writing diagnostic.txt ...
(
  echo DATE: %DATE% %TIME%
  ver
  where py
  py -0p
  where python
  python --version
) > diagnostic.txt 2>&1
echo Done: %CD%\diagnostic.txt
pause
endlocal
