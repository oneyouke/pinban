from __future__ import annotations

from dataclasses import fields
from pathlib import Path
from typing import Any

from imposition import InputJob, ImpositionSettings
from production_service import atomic_production_export
from storage import ProductionDB
from integration import ProductionTicket, send_to_rip_hotfolder
from jdf import JDFJob, save_jdf


def snapshot_to_runtime(snapshot: dict[str, Any]):
    jobs = [InputJob(**row) for row in snapshot.get("jobs", [])]
    allowed = {f.name for f in fields(ImpositionSettings)}
    settings_data = {k: v for k, v in (snapshot.get("settings") or {}).items() if k in allowed}
    settings = ImpositionSettings(**settings_data)
    layout = snapshot.get("layout")
    return jobs, settings, layout


class PersistentQueue:
    def __init__(self, db: ProductionDB | None = None, scheduler=None, registry=None) -> None:
        self.db = db or ProductionDB()
        self.scheduler = scheduler
        self.registry = registry

    def _dispatch_after_export(self, job_id: int, row: dict[str, Any], snapshot: dict[str, Any], manifest: dict[str, Any]) -> dict[str, Any]:
        if not self.scheduler or not self.registry:
            return {}
        assignment = self.scheduler.assignment_for_job(job_id)
        if not assignment or not assignment.get("device_id"):
            return {}
        device = self.registry.get(str(assignment["device_id"]))
        if not device:
            return {"warning": "已派机，但设备配置不存在"}

        output = Path(manifest["output"])
        settings = snapshot.get("settings") or {}
        jobs = snapshot.get("jobs") or []
        amount = sum(max(1, int(j.get("quantity") or 1)) for j in jobs)
        order_id = str(settings.get("order_no") or row.get("title") or f"JOB-{job_id}")
        customer = str(settings.get("customer_name") or "")
        ticket = ProductionTicket(
            order_id=order_id, customer=customer,
            input_files=[str(j.get("path")) for j in jobs],
            quantities=[int(j.get("quantity") or 1) for j in jobs],
            sheet_width_mm=float(settings.get("sheet_width_mm") or 0),
            sheet_height_mm=float(settings.get("sheet_height_mm") or 0),
            machine=device.id,
            metadata={"queue_job_id": job_id, "output_sha256": manifest.get("output_sha256", "")},
        )
        dispatch: dict[str, Any] = {"device_id": device.id, "device_name": device.name}
        try:
            if device.rip_hotfolder:
                dispatch["rip_output"] = send_to_rip_hotfolder(output, device.rip_hotfolder, ticket)
            if device.jdf_hotfolder:
                jdf_dir = Path(device.jdf_hotfolder); jdf_dir.mkdir(parents=True, exist_ok=True)
                jdf_path = jdf_dir / f"{output.stem}.jdf"
                save_jdf(JDFJob(
                    job_id=order_id, customer=customer, amount=amount,
                    sheet_width_mm=float(settings.get("sheet_width_mm") or 0),
                    sheet_height_mm=float(settings.get("sheet_height_mm") or 0),
                    output_pdf=str(output.resolve()), device_id=device.id,
                ), jdf_path)
                dispatch["jdf_output"] = str(jdf_path)
            self.db.audit("device.dispatch_succeeded", {"job_id": job_id, **dispatch})
        except Exception as exc:
            dispatch["warning"] = f"生产 PDF 已完成，但设备投递失败：{exc}"
            self.db.audit("device.dispatch_failed", {"job_id": job_id, "device_id": device.id, "error": str(exc)}, "warning")
        return dispatch

    def process_next(self, job_id: int | None = None) -> dict[str, Any] | None:
        row = self.db.claim_job(job_id) if job_id is not None else self.db.claim_next_job()
        if not row:
            return None
        job_id = int(row["id"])
        snapshot = row["snapshot"]
        try:
            jobs, settings, layout = snapshot_to_runtime(snapshot)
            manifest = atomic_production_export(jobs, row["output_path"], settings, layout, db=self.db)
            dispatch = self._dispatch_after_export(job_id, row, snapshot, manifest)
            if dispatch:
                manifest["device_dispatch"] = dispatch
            self.db.finish_job(job_id, "succeeded", summary=manifest.get("summary") or {})
            return {"job_id": job_id, "status": "succeeded", "manifest": manifest, "device_dispatch": dispatch}
        except Exception as exc:
            self.db.finish_job(job_id, "failed", error=str(exc))
            return {"job_id": job_id, "status": "failed", "error": str(exc)}
