from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
import hashlib
import json
import shutil


@dataclass
class DieAsset:
    id: str
    name: str
    source_file: str
    sha256: str
    width_mm: float = 0.0
    height_mm: float = 0.0
    spot_name: str = "CutContour"
    customer: str = ""
    product_code: str = ""
    notes: str = ""

    def to_dict(self):
        return asdict(self)


class DieLibrary:
    def __init__(self, root: str | Path):
        self.root = Path(root)
        self.files = self.root / "files"
        self.index = self.root / "index.json"
        self.files.mkdir(parents=True, exist_ok=True)
        if not self.index.exists():
            self._save([])

    def _load(self) -> list[DieAsset]:
        try:
            data = json.loads(self.index.read_text(encoding="utf-8"))
            return [DieAsset(**item) for item in data.get("items", [])]
        except Exception:
            return []

    def _save(self, assets: list[DieAsset]) -> None:
        tmp = self.index.with_suffix(".tmp")
        tmp.write_text(json.dumps({"schema": 1, "items": [a.to_dict() for a in assets]}, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(self.index)

    @staticmethod
    def _sha256(path: Path) -> str:
        h = hashlib.sha256()
        with path.open("rb") as f:
            for chunk in iter(lambda: f.read(1024 * 1024), b""):
                h.update(chunk)
        return h.hexdigest()

    def add(self, path: str | Path, name: str = "", **metadata) -> DieAsset:
        src = Path(path)
        if not src.is_file():
            raise FileNotFoundError(src)
        digest = self._sha256(src)
        existing = next((a for a in self._load() if a.sha256 == digest), None)
        if existing:
            return existing
        asset_id = digest[:16]
        dst = self.files / f"{asset_id}{src.suffix.lower()}"
        shutil.copy2(src, dst)
        asset = DieAsset(
            id=asset_id,
            name=name or src.stem,
            source_file=str(dst),
            sha256=digest,
            width_mm=float(metadata.get("width_mm", 0.0)),
            height_mm=float(metadata.get("height_mm", 0.0)),
            spot_name=str(metadata.get("spot_name", "CutContour")),
            customer=str(metadata.get("customer", "")),
            product_code=str(metadata.get("product_code", "")),
            notes=str(metadata.get("notes", "")),
        )
        assets = self._load(); assets.append(asset); self._save(assets)
        return asset

    def list(self, query: str = "") -> list[DieAsset]:
        assets = self._load()
        q = query.strip().lower()
        if not q:
            return assets
        return [a for a in assets if q in " ".join([a.name, a.customer, a.product_code, a.spot_name, a.notes]).lower()]

    def remove(self, asset_id: str) -> bool:
        assets = self._load(); match = next((a for a in assets if a.id == asset_id), None)
        if not match:
            return False
        try:
            Path(match.source_file).unlink(missing_ok=True)
        except Exception:
            pass
        self._save([a for a in assets if a.id != asset_id])
        return True
