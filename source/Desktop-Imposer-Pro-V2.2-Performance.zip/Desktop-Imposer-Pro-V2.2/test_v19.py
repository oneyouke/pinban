from datetime import date, timedelta
from pathlib import Path
from tempfile import TemporaryDirectory

from commercial import CommercialManager, QuoteLine
from sales_finance import SalesFinanceManager
from storage import ProductionDB


def main():
    with TemporaryDirectory() as td:
        db = ProductionDB(Path(td) / 'db.sqlite')
        cm = CommercialManager(db)
        sf = SalesFinanceManager(db)

        cm.upsert_customer('C1', '重点客户', credit_limit=1000, payment_terms_days=30)
        sf.set_price_rule('C1', '名片', 1000, 0.52, 0.25)
        sf.set_price_rule('C1', '名片', 5000, 0.45, 0.20)
        assert sf.resolve_price('C1', '名片', 6000)['unit_price'] == 0.45

        q = cm.create_quote('Q1', 'C1', [QuoteLine('名片', 1000, 0.40, 0.34, 0.0)])
        ap = sf.approval_required('Q1')
        assert ap['required'] and ap['threshold'] >= 0.25
        sf.request_quote_approval('Q1', 'sales-a', '毛利低于客户红线')
        assert cm.get_quote('Q1')['status'] == 'pending_approval'
        sf.approve_quote('Q1', 'manager-a', True, '战略客户特批')
        assert cm.get_quote('Q1')['status'] == 'approved'

        o = cm.accept_quote('Q1', 'SO1', (date.today()+timedelta(days=10)).isoformat())
        assert o['status'] == 'confirmed'
        d = sf.enforce_order_credit('SO1')
        assert d.approved

        cm.set_order_actual_costs('SO1', material_cost=100, press_cost=60, finishing_cost=30, labor_cost=20)
        cm.create_invoice('INV1', 'SO1', (date.today()+timedelta(days=20)).isoformat())
        cm.record_payment('INV1', 100)

        sf.upsert_salesperson('S1', '业务员A', 0.10)
        sf.assign_salesperson('SO1', 'S1')
        comm = sf.accrue_commission('SO1', 'gross_profit')
        assert comm['commission'] == 19.0

        stmt = sf.customer_statement('C1')
        assert stmt['balance'] == 300.0

        cm.create_purchase_order('PO1', '纸张供应商', [{'sku':'PAPER','qty':100,'unit_cost':2.0}], expected_at=(date.today()+timedelta(days=25)).isoformat())
        sf.record_supplier_payment('PO1', 50)
        sstmt = sf.supplier_statement('纸张供应商')
        assert sstmt['balance'] == 150.0

        cf = sf.cashflow_forecast(90, 30)
        assert round(sum(x['inflow'] for x in cf), 2) == 300.0
        assert round(sum(x['outflow'] for x in cf), 2) == 150.0

        # Create a second customer that must be credit-held.
        cm.upsert_customer('C2', '风险客户', credit_limit=100, payment_terms_days=30)
        cm.create_quote('Q2', 'C2', [QuoteLine('海报', 1, 150, 80)])
        cm.accept_quote('Q2', 'SO2')
        hold = sf.enforce_order_credit('SO2')
        assert not hold.approved and cm.get_order('SO2')['status'] == 'credit_hold'
        sf.release_credit_hold('SO2', 'finance-manager')
        assert cm.get_order('SO2')['status'] == 'confirmed'

        dash = sf.executive_dashboard()
        assert dash['revenue'] == 550.0
        assert dash['accounts_receivable'] == 300.0
        assert dash['accrued_commissions'] == 19.0
        assert len(sf.profit_ranking()) == 2
        print('V1.9 PASS')


if __name__ == '__main__':
    main()
