from __future__ import annotations
from dataclasses import dataclass
from shapely.geometry import Polygon
from shapely import affinity

@dataclass(frozen=True)
class NestItem:
    item_id:str
    points:list[tuple[float,float]]
    quantity:int=1
    rotations:tuple[int,...]=(0,90,180,270)

@dataclass(frozen=True)
class NestPlacement:
    item_id:str
    copy_index:int
    x_mm:float
    y_mm:float
    rotation:int
    sheet:int=1

@dataclass(frozen=True)
class NestPlan:
    placements:list[NestPlacement]
    sheet_count:int
    utilization:list[float]


def _norm(poly:Polygon)->Polygon:
    minx,miny,_,_=poly.bounds
    return affinity.translate(poly,xoff=-minx,yoff=-miny)


def _expand(items:list[NestItem]):
    expanded=[]
    for it in items:
        if it.quantity<1: continue
        p=_norm(Polygon(it.points))
        if not p.is_valid or p.area<=0: raise ValueError(f'轮廓无效: {it.item_id}')
        for i in range(it.quantity): expanded.append((it,i,p))
    expanded.sort(key=lambda t:t[2].area, reverse=True)
    return expanded


def _place_on_sheet(expanded, sheet_width_mm, sheet_height_mm, gap_mm, step_mm, sheet_no):
    placed_geoms=[]; placements=[]; remaining=[]; used_area=0.0
    for it,copy_idx,base in expanded:
        best=None
        for rot in it.rotations:
            g=_norm(affinity.rotate(base,rot,origin=(0,0)))
            _,_,w,h=g.bounds
            y=0.0
            while y+h<=sheet_height_mm+1e-9:
                x=0.0
                while x+w<=sheet_width_mm+1e-9:
                    cand=affinity.translate(g,xoff=x,yoff=y)
                    safe=cand.buffer(gap_mm/2,join_style=2) if gap_mm else cand
                    if all(not safe.intersects(pg) for pg in placed_geoms):
                        score=(y,x)
                        if best is None or score<best[0]: best=(score,x,y,rot,safe,cand)
                        break
                    x += step_mm
                if best and best[0][0]==y: break
                y += step_mm
        if best is None:
            remaining.append((it,copy_idx,base)); continue
        _,x,y,rot,safe,cand=best
        placed_geoms.append(safe); used_area += cand.area
        placements.append(NestPlacement(it.item_id,copy_idx,x,y,rot,sheet_no))
    return placements, remaining, used_area


def nest_polygons_multi_sheet(items:list[NestItem], sheet_width_mm:float, sheet_height_mm:float, gap_mm:float=2.0, step_mm:float=1.0, max_sheets:int=1000)->NestPlan:
    """True-polygon deterministic multi-sheet nesting baseline.

    Collision uses actual polygons. This is intentionally deterministic and
    auditable; a specialized optimizer can replace the strategy later without
    changing the plan format.
    """
    if sheet_width_mm<=0 or sheet_height_mm<=0: raise ValueError('纸张尺寸无效')
    if gap_mm<0 or step_mm<=0: raise ValueError('间距必须>=0且搜索步长必须>0')
    remaining=_expand(items)
    all_placements=[]; utils=[]; sheet=1
    while remaining:
        placements,new_remaining,area=_place_on_sheet(remaining,sheet_width_mm,sheet_height_mm,gap_mm,step_mm,sheet)
        if not placements:
            it,copy_idx,_=remaining[0]
            raise ValueError(f'轮廓无法放入单张纸：{it.item_id} #{copy_idx+1}')
        all_placements.extend(placements)
        utils.append(area/(sheet_width_mm*sheet_height_mm))
        remaining=new_remaining; sheet += 1
        if sheet>max_sheets+1: raise ValueError('套版超过最大纸张数量限制')
    return NestPlan(all_placements, len(utils), utils)


def nest_polygons(items:list[NestItem], sheet_width_mm:float, sheet_height_mm:float, gap_mm:float=2.0, step_mm:float=1.0)->list[NestPlacement]:
    plan=nest_polygons_multi_sheet(items,sheet_width_mm,sheet_height_mm,gap_mm,step_mm,max_sheets=1)
    if plan.sheet_count>1: raise ValueError('单张纸无法放下全部轮廓')
    return plan.placements
