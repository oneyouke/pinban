from __future__ import annotations

from dataclasses import asdict
from pathlib import Path
from typing import Any

from erp_server import ERPRequest
from imposition import InputJob, ImpositionSettings
from project_file import build_project_snapshot
from production_scheduler import ProductionScheduler
from storage import ProductionDB


class ERPProductionDispatcher:
    """Convert accepted ERP tickets into persistent production-queue jobs.

    ERP/MIS installations differ. This baseline accepts common ticket fields and
    preserves the original ERP payload inside the project snapshot for auditing.
    """

    def __init__(self, db: ProductionDB, scheduler: ProductionScheduler):
        self.db = db
        self.scheduler = scheduler

    def request_to_snapshot(self, request: ERPRequest) -> tuple[str, str, dict[str, Any]]:
        ticket = request.ticket
        raw = asdict(ticket)
        files = list(getattr(ticket, "input_files", []) or [])
        quantities = list(getattr(ticket, "quantities", []) or [])
        if not files:
            raise ValueError("ERP 工单缺少 files，无法创建拼版任务")

        jobs: list[InputJob] = []
        for i, file_path in enumerate(files):
            qty = int(quantities[i] if i < len(quantities) else (quantities[-1] if quantities else 1))
            jobs.append(InputJob(
                path=str(file_path), quantity=max(1, qty),
                trim_width_mm=float(raw["product_width_mm"]) if raw.get("product_width_mm") else None,
                trim_height_mm=float(raw["product_height_mm"]) if raw.get("product_height_mm") else None,
                name=Path(str(file_path)).stem,
            ))

        sheet_w = float(raw.get("sheet_width_mm") or 450)
        sheet_h = float(raw.get("sheet_height_mm") or 320)
        settings = ImpositionSettings(sheet_width_mm=sheet_w, sheet_height_mm=sheet_h)
        snapshot = build_project_snapshot(jobs, settings, None)
        snapshot["erp"] = {"request_id": request.request_id, "ticket": raw}
        if raw.get("device_kind"):
            snapshot["preferred_device_kind"] = raw["device_kind"]
        elif raw.get("machine"):
            snapshot["preferred_device_id"] = raw["machine"]
        if raw.get("required_colors"):
            snapshot["required_colors"] = raw["required_colors"]

        output_dir = Path(str(raw.get("output_dir") or Path(files[0]).parent))
        output_dir.mkdir(parents=True, exist_ok=True)
        order_id = str(ticket.order_id)
        output_path = str(output_dir / f"{order_id}_imposed.pdf")
        title = order_id + (f" · {ticket.customer}" if getattr(ticket, "customer", "") else "")
        return title, output_path, snapshot

    def enqueue(self, request: ERPRequest, auto_assign: bool = True) -> int:
        title, output_path, snapshot = self.request_to_snapshot(request)
        job_id = self.db.enqueue(title, output_path, snapshot)
        self.db.audit("erp.production_enqueued", {"request_id": request.request_id, "job_id": job_id, "order_id": request.ticket.order_id})
        if auto_assign:
            try:
                self.scheduler.auto_assign_job(job_id)
            except Exception as exc:
                self.db.audit("erp.auto_assign_failed", {"job_id": job_id, "error": str(exc)}, "warning")
        return job_id
