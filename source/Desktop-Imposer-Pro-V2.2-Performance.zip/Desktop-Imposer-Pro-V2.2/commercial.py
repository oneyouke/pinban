from __future__ import annotations

from dataclasses import dataclass, asdict
from datetime import date
from typing import Any
import json

from storage import ProductionDB, utc_now


@dataclass(frozen=True)
class QuoteLine:
    description: str
    qty: float
    unit_price: float
    unit_cost: float = 0.0
    tax_rate: float = 0.0

    @property
    def revenue(self) -> float:
        return round(self.qty * self.unit_price, 2)

    @property
    def estimated_cost(self) -> float:
        return round(self.qty * self.unit_cost, 2)

    @property
    def tax(self) -> float:
        return round(self.revenue * self.tax_rate, 2)


class CommercialManager:
    """Commercial layer for quote -> order -> purchasing -> AR -> margin.

    This manager stores financial metadata only. Production PDFs remain outside
    the database. Currency values are stored as decimal-like REAL for the MVP;
    deployments needing statutory accounting should integrate an accounting
    provider and integer minor-units/Decimal rules appropriate to the locale.
    """

    def __init__(self, db: ProductionDB):
        self.db = db
        self._init_schema()

    def _init_schema(self) -> None:
        with self.db.connect() as c:
            c.executescript(
                """
                CREATE TABLE IF NOT EXISTS customers(
                  customer_id TEXT PRIMARY KEY, name TEXT NOT NULL, contact TEXT,
                  phone TEXT, email TEXT, credit_limit REAL NOT NULL DEFAULT 0,
                  payment_terms_days INTEGER NOT NULL DEFAULT 30,
                  created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS quotes(
                  quote_id TEXT PRIMARY KEY, customer_id TEXT NOT NULL,
                  status TEXT NOT NULL, currency TEXT NOT NULL, valid_until TEXT,
                  lines_json TEXT NOT NULL, subtotal REAL NOT NULL, tax REAL NOT NULL,
                  total REAL NOT NULL, estimated_cost REAL NOT NULL,
                  estimated_margin REAL NOT NULL, created_at TEXT NOT NULL,
                  FOREIGN KEY(customer_id) REFERENCES customers(customer_id)
                );
                CREATE TABLE IF NOT EXISTS sales_orders(
                  order_id TEXT PRIMARY KEY, quote_id TEXT, customer_id TEXT NOT NULL,
                  status TEXT NOT NULL, currency TEXT NOT NULL, total REAL NOT NULL,
                  estimated_cost REAL NOT NULL, estimated_margin REAL NOT NULL,
                  due_at TEXT, production_job_id INTEGER, created_at TEXT NOT NULL,
                  completed_at TEXT,
                  FOREIGN KEY(customer_id) REFERENCES customers(customer_id)
                );
                CREATE TABLE IF NOT EXISTS purchase_orders(
                  po_id TEXT PRIMARY KEY, supplier TEXT NOT NULL, status TEXT NOT NULL,
                  currency TEXT NOT NULL, total REAL NOT NULL, expected_at TEXT,
                  lines_json TEXT NOT NULL, created_at TEXT NOT NULL, received_at TEXT
                );
                CREATE TABLE IF NOT EXISTS receivables(
                  invoice_id TEXT PRIMARY KEY, order_id TEXT NOT NULL,
                  customer_id TEXT NOT NULL, amount REAL NOT NULL, paid REAL NOT NULL DEFAULT 0,
                  due_date TEXT, status TEXT NOT NULL, created_at TEXT NOT NULL,
                  FOREIGN KEY(order_id) REFERENCES sales_orders(order_id)
                );
                CREATE TABLE IF NOT EXISTS payments(
                  id INTEGER PRIMARY KEY AUTOINCREMENT, invoice_id TEXT NOT NULL,
                  amount REAL NOT NULL, method TEXT, reference TEXT, paid_at TEXT NOT NULL,
                  FOREIGN KEY(invoice_id) REFERENCES receivables(invoice_id)
                );
                CREATE TABLE IF NOT EXISTS order_actual_costs(
                  order_id TEXT PRIMARY KEY, material_cost REAL NOT NULL DEFAULT 0,
                  press_cost REAL NOT NULL DEFAULT 0, finishing_cost REAL NOT NULL DEFAULT 0,
                  labor_cost REAL NOT NULL DEFAULT 0, logistics_cost REAL NOT NULL DEFAULT 0,
                  other_cost REAL NOT NULL DEFAULT 0, updated_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS material_batches(
                  batch_id TEXT PRIMARY KEY, sku TEXT NOT NULL, supplier TEXT,
                  qty_received REAL NOT NULL, qty_remaining REAL NOT NULL,
                  unit_cost REAL NOT NULL, received_at TEXT NOT NULL, reference TEXT
                );
                """
            )

    def upsert_customer(self, customer_id: str, name: str, **kwargs: Any) -> None:
        with self.db.connect() as c:
            c.execute(
                """INSERT INTO customers(customer_id,name,contact,phone,email,credit_limit,payment_terms_days,created_at)
                   VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(customer_id) DO UPDATE SET
                   name=excluded.name,contact=excluded.contact,phone=excluded.phone,email=excluded.email,
                   credit_limit=excluded.credit_limit,payment_terms_days=excluded.payment_terms_days""",
                (customer_id,name,kwargs.get('contact',''),kwargs.get('phone',''),kwargs.get('email',''),
                 float(kwargs.get('credit_limit',0)),int(kwargs.get('payment_terms_days',30)),utc_now())
            )

    def create_quote(self, quote_id: str, customer_id: str, lines: list[QuoteLine], currency='CNY', valid_until='') -> dict[str, Any]:
        if not lines: raise ValueError('报价至少需要一个项目')
        subtotal=round(sum(x.revenue for x in lines),2); tax=round(sum(x.tax for x in lines),2)
        cost=round(sum(x.estimated_cost for x in lines),2); total=round(subtotal+tax,2)
        margin=round((subtotal-cost)/subtotal if subtotal else 0,4)
        with self.db.connect() as c:
            c.execute("INSERT INTO quotes VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                      (quote_id,customer_id,'draft',currency,valid_until,json.dumps([asdict(x) for x in lines],ensure_ascii=False),subtotal,tax,total,cost,margin,utc_now()))
        self.db.audit('commercial.quote_created',{'quote_id':quote_id,'customer_id':customer_id,'total':total})
        return self.get_quote(quote_id)

    def get_quote(self, quote_id: str) -> dict[str, Any]:
        with self.db.connect() as c: r=c.execute('SELECT * FROM quotes WHERE quote_id=?',(quote_id,)).fetchone()
        if not r: raise KeyError(quote_id)
        d=dict(r); d['lines']=json.loads(d.pop('lines_json')); return d

    def accept_quote(self, quote_id: str, order_id: str, due_at: str='') -> dict[str, Any]:
        q=self.get_quote(quote_id)
        with self.db.connect() as c:
            c.execute("UPDATE quotes SET status='accepted' WHERE quote_id=?",(quote_id,))
            c.execute("INSERT INTO sales_orders(order_id,quote_id,customer_id,status,currency,total,estimated_cost,estimated_margin,due_at,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
                      (order_id,quote_id,q['customer_id'],'confirmed',q['currency'],q['total'],q['estimated_cost'],q['estimated_margin'],due_at,utc_now()))
        self.db.audit('commercial.order_created',{'order_id':order_id,'quote_id':quote_id})
        return self.get_order(order_id)

    def get_order(self, order_id: str) -> dict[str, Any]:
        with self.db.connect() as c:r=c.execute('SELECT * FROM sales_orders WHERE order_id=?',(order_id,)).fetchone()
        if not r: raise KeyError(order_id)
        return dict(r)

    def link_production_job(self, order_id: str, production_job_id: int) -> None:
        with self.db.connect() as c:c.execute('UPDATE sales_orders SET production_job_id=?,status=? WHERE order_id=?',(production_job_id,'in_production',order_id))

    def set_order_actual_costs(self, order_id: str, **costs: float) -> None:
        vals=[float(costs.get(k,0)) for k in ('material_cost','press_cost','finishing_cost','labor_cost','logistics_cost','other_cost')]
        with self.db.connect() as c:
            c.execute("""INSERT INTO order_actual_costs(order_id,material_cost,press_cost,finishing_cost,labor_cost,logistics_cost,other_cost,updated_at)
            VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(order_id) DO UPDATE SET material_cost=excluded.material_cost,press_cost=excluded.press_cost,
            finishing_cost=excluded.finishing_cost,labor_cost=excluded.labor_cost,logistics_cost=excluded.logistics_cost,other_cost=excluded.other_cost,updated_at=excluded.updated_at""",
                      (order_id,*vals,utc_now()))

    def complete_order(self, order_id: str) -> None:
        with self.db.connect() as c:c.execute("UPDATE sales_orders SET status='completed',completed_at=? WHERE order_id=?",(utc_now(),order_id))

    def create_invoice(self, invoice_id: str, order_id: str, due_date: str='') -> dict[str, Any]:
        o=self.get_order(order_id)
        with self.db.connect() as c:
            c.execute('INSERT INTO receivables(invoice_id,order_id,customer_id,amount,paid,due_date,status,created_at) VALUES(?,?,?,?,?,?,?,?)',
                      (invoice_id,order_id,o['customer_id'],o['total'],0,due_date,'open',utc_now()))
        return self.get_invoice(invoice_id)

    def get_invoice(self, invoice_id: str) -> dict[str, Any]:
        with self.db.connect() as c:r=c.execute('SELECT * FROM receivables WHERE invoice_id=?',(invoice_id,)).fetchone()
        if not r: raise KeyError(invoice_id)
        return dict(r)

    def record_payment(self, invoice_id: str, amount: float, method='bank', reference='') -> dict[str, Any]:
        if amount <= 0: raise ValueError('收款金额必须大于0')
        with self.db.connect() as c:
            inv=c.execute('SELECT * FROM receivables WHERE invoice_id=?',(invoice_id,)).fetchone()
            if not inv: raise KeyError(invoice_id)
            new_paid=min(float(inv['amount']),float(inv['paid'])+float(amount))
            status='paid' if new_paid >= float(inv['amount'])-0.005 else 'partial'
            c.execute('INSERT INTO payments(invoice_id,amount,method,reference,paid_at) VALUES(?,?,?,?,?)',(invoice_id,float(amount),method,reference,utc_now()))
            c.execute('UPDATE receivables SET paid=?,status=? WHERE invoice_id=?',(new_paid,status,invoice_id))
        return self.get_invoice(invoice_id)

    def create_purchase_order(self, po_id: str, supplier: str, lines: list[dict[str,Any]], currency='CNY', expected_at='') -> dict[str,Any]:
        total=round(sum(float(x.get('qty',0))*float(x.get('unit_cost',0)) for x in lines),2)
        with self.db.connect() as c:c.execute('INSERT INTO purchase_orders VALUES(?,?,?,?,?,?,?,?,?)',(po_id,supplier,'open',currency,total,expected_at,json.dumps(lines,ensure_ascii=False),utc_now(),None))
        return {'po_id':po_id,'supplier':supplier,'total':total,'status':'open'}

    def receive_material_batch(self, batch_id: str, sku: str, qty: float, unit_cost: float, supplier='', reference='') -> None:
        with self.db.connect() as c:c.execute('INSERT INTO material_batches VALUES(?,?,?,?,?,?,?,?)',(batch_id,sku,supplier,float(qty),float(qty),float(unit_cost),utc_now(),reference))

    def consume_material_fifo(self, sku: str, qty: float) -> float:
        remaining=float(qty); cost=0.0
        if remaining<=0:return 0.0
        with self.db.connect() as c:
            rows=c.execute('SELECT * FROM material_batches WHERE sku=? AND qty_remaining>0 ORDER BY received_at,batch_id',(sku,)).fetchall()
            for r in rows:
                take=min(remaining,float(r['qty_remaining']))
                c.execute('UPDATE material_batches SET qty_remaining=qty_remaining-? WHERE batch_id=?',(take,r['batch_id']))
                cost+=take*float(r['unit_cost']); remaining-=take
                if remaining<=1e-9:break
        if remaining>1e-9: raise ValueError(f'{sku} 批次库存不足，还缺 {remaining:.2f}')
        return round(cost,2)

    def order_profit(self, order_id: str) -> dict[str, Any]:
        o=self.get_order(order_id)
        with self.db.connect() as c:r=c.execute('SELECT * FROM order_actual_costs WHERE order_id=?',(order_id,)).fetchone()
        actual=sum(float(r[k]) for k in ('material_cost','press_cost','finishing_cost','labor_cost','logistics_cost','other_cost')) if r else float(o['estimated_cost'])
        revenue=float(o['total']); profit=round(revenue-actual,2); margin=round(profit/revenue if revenue else 0,4)
        return {'order_id':order_id,'revenue':round(revenue,2),'estimated_cost':round(float(o['estimated_cost']),2),'actual_cost':round(actual,2),'profit':profit,'margin':margin}

    def dashboard(self) -> dict[str, Any]:
        with self.db.connect() as c:
            revenue=float(c.execute("SELECT COALESCE(SUM(total),0) FROM sales_orders WHERE status IN ('confirmed','in_production','completed')").fetchone()[0])
            ar=float(c.execute("SELECT COALESCE(SUM(amount-paid),0) FROM receivables WHERE status!='paid'").fetchone()[0])
            overdue=float(c.execute("SELECT COALESCE(SUM(amount-paid),0) FROM receivables WHERE status!='paid' AND due_date!='' AND due_date<?",(date.today().isoformat(),)).fetchone()[0])
            open_po=float(c.execute("SELECT COALESCE(SUM(total),0) FROM purchase_orders WHERE status!='closed'").fetchone()[0])
            rows=c.execute("SELECT order_id FROM sales_orders WHERE status IN ('confirmed','in_production','completed')").fetchall()
        profits=[self.order_profit(r['order_id']) for r in rows]
        actual_profit=round(sum(x['profit'] for x in profits),2)
        actual_margin=round(actual_profit/revenue if revenue else 0,4)
        return {'revenue':round(revenue,2),'accounts_receivable':round(ar,2),'overdue_receivable':round(overdue,2),'open_purchase_orders':round(open_po,2),'actual_profit':actual_profit,'actual_margin':actual_margin,'order_count':len(rows)}
