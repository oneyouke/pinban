# V1.4 生产控制台说明

V1.4 在 V1.3 设备接入能力之上新增调度层，目标是把“能对接设备”推进到“能在车间安排生产”。

## 生产排程

`production_scheduler.py` 使用独立的 `production_schedule` 表保存派机信息，不修改原有 `production_jobs` 的事务式输出状态机。任务可设置：

- 设备 ID；
- 优先级（数值越小越先）；
- 计划状态；
- 自动/人工派机原因；
- 计划开始时间字段。

自动派机会检查纸张尺寸、色数、单双面能力、扩展能力、设备队列负载、设备速度、换单时间和小时成本。已通过 JMF 标记为 Offline/Error 的设备不会自动接单。

## 设备状态看板

生产控制台每 30 秒可轮询一次已配置 JMF URL 的设备，并持久化：

- DeviceStatus；
- 当前 JobID / JobPartID；
- JobStatus；
- PercentCompleted；
- 最近检查时间和错误信息。

不同厂商对 JMF/JDF 的扩展存在差异，因此本功能属于互操作基线，不宣称 CIP4 认证。

## 设备投递

已派机任务在本地生产 PDF 成功原子提交后：

1. 若设备配置了 RIP Hot Folder，自动以 `.partial -> rename` 方式投递 PDF；
2. 同步生成 `.ticket.json`；
3. 若配置了 JDF Hot Folder，生成对应 `.jdf`；
4. 投递异常单独记录到审计日志，不会把已经成功生成的生产 PDF 错报成“导出失败”。

## ERP 自动接单

生产控制台可启动本地 ERP 接口：

- `GET /health`
- `POST /v1/jobs`

收到订单后自动转换为持久生产队列任务，并尝试自动派机。默认监听 `127.0.0.1`，生产网络部署应使用 HTTPS 反向代理和 Bearer Token。

## CIP3 墨键看板

控制台可调用 Ghostscript 生成 CMYK 分色预览，并按配置的墨键区数量显示每色平均/最小/最大覆盖率及各区域数值。该数据必须按实际 RIP、ICC、印刷机墨键响应曲线校准后才能用于正式墨量预置。
