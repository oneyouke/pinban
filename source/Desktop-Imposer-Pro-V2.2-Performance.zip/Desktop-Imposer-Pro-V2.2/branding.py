from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path

from app_paths import config_dir
from product import APP_NAME, SUPPORT_EMAIL, VENDOR_NAME

@dataclass
class BrandConfig:
    product_name: str = APP_NAME
    company_name: str = VENDOR_NAME
    support_email: str = SUPPORT_EMAIL
    website: str = ""
    accent_color: str = "#1f6feb"
    logo_path: str = ""
    legal_name: str = ""
    copyright_text: str = ""

    def validate(self) -> None:
        if not self.product_name.strip():
            raise ValueError("product_name is required")
        if not self.company_name.strip():
            raise ValueError("company_name is required")
        if not self.accent_color.startswith("#") or len(self.accent_color) not in (4, 7, 9):
            raise ValueError("accent_color must be a CSS hex color")


def brand_path() -> Path:
    return config_dir() / "branding.json"


def load_brand(path: str | Path | None = None) -> BrandConfig:
    p = Path(path) if path else brand_path()
    if not p.exists():
        return BrandConfig()
    data = json.loads(p.read_text(encoding="utf-8"))
    cfg = BrandConfig(**{k: v for k, v in data.items() if k in BrandConfig.__annotations__})
    cfg.validate()
    return cfg


def save_brand(config: BrandConfig, path: str | Path | None = None) -> Path:
    config.validate()
    p = Path(path) if path else brand_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(json.dumps(asdict(config), ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(p)
    return p
